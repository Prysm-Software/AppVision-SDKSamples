import { VariableManager } from './managers/variableManager';
import { GroupManager } from './managers/groupManager';
import { OptionManager } from './managers/optionManager';
import { UserManager } from './managers/userManager';
import { FileManager } from './managers/fileManager';
import { EventManager } from './managers/eventManager';
import { AlarmManager } from './managers/alarmManager';
import { OperandManager } from './managers/operandManager';
import { RTManager } from './managers/rtManager';
import { ProtocolManager } from './managers/protocolManager';
import { Subject } from 'rxjs';
import { ScenarioManager } from './managers/scenarioManager';
import { AreaManager } from './managers/areaManager';
import { CommandManager } from './managers/commandManager';
import { VideoManager } from './managers/videoManager';
import { HttpService } from './services/httpService';
import { EnvironmentManager } from './managers/environmentManager';
import { CategoryManager } from './managers/categoryManager';
import { PeopleManager } from './managers/peopleManager';
import { DepartmentManager } from './managers/departmentManager';
import { AccessProfileManager } from './managers/accessProfileManager';
import { BadgeManager } from './managers/badgeManager';
import { RightManager } from './managers/rightManager';
import { BadgeTypeManager } from './managers/badgeTypeManager';
import { ZoneManager } from './managers/zoneManager';
import { PersonZoneManager } from './managers/personZoneManager';
import { ServerState } from './data/serverState';
import { HolidayManager } from './managers/holidayManager';
import { UserMessageManager } from './managers/userMessageManager';
import { VisitorManager } from './managers/visitorManager';
import { LicenseManager } from './managers/licenseManager';
import { ChatManager } from './managers/chatManager';
import { AppLoginOptions } from './appLoginOptions';
import { RowCustomColorManager } from './managers/rowCustomColorManager';
import { OverlayManager } from './managers/overlayManager';
import { MailingManager } from './managers/mailingManager';
import { ServerInfo } from './data/serverInfo';
import { UserProfileManager } from './managers/userProfileManager';
import { ControllerManager } from './managers/controllerManager';
import { InstructionManager } from './managers/instructionManager';
import { TextReportManager } from './managers/textReportManager';
import { KeepAliveInfo } from './data/KeepAliveInfo';
/**
 * Object to connect to an appvision server
 */
export declare class AppServer {
    private lastState;
    private lastKeepAliveInfo;
    private keepAliveId;
    private connected;
    private httpOData;
    private handleKeepAlive;
    private keepAliveTempo;
    private keepAliveFailRetryNb;
    private keepAliveFailRetryTempo;
    private notifFilter?;
    http: HttpService;
    /**
     * Error when parsing json response or when keepalive request failed
     */
    error: Subject<any>;
    /**
     * Connection with appserver lost
     */
    connectionLost: Subject<any>;
    /**
     * New server state event
     */
    newState: Subject<ServerState>;
    /**
     * When a keepalive succeed
     */
    keepAliveSucceed: Subject<KeepAliveInfo>;
    alarmManager: AlarmManager;
    optionManager: OptionManager;
    userManager: UserManager;
    userMessageManager: UserMessageManager;
    variableManager: VariableManager;
    groupManager: GroupManager;
    areaManager: AreaManager;
    fileManager: FileManager;
    eventManager: EventManager;
    rtManager: RTManager;
    operandManager: OperandManager;
    protocolManager: ProtocolManager;
    scenarioManager: ScenarioManager;
    commandManager: CommandManager;
    videoManager: VideoManager;
    environmentManager: EnvironmentManager;
    licenseManager: LicenseManager;
    chatManager: ChatManager;
    customColorManager: RowCustomColorManager;
    overlayManager: OverlayManager;
    mailingManager: MailingManager;
    userProfileManager: UserProfileManager;
    controllerManager: ControllerManager;
    instructionManager: InstructionManager;
    textReportManager: TextReportManager;
    private workflowManager;
    peopleManager: PeopleManager;
    visitorManager: VisitorManager;
    categoryManager: CategoryManager;
    departmentManager: DepartmentManager;
    accessProfileManager: AccessProfileManager;
    badgesManager: BadgeManager;
    rightManager: RightManager;
    badgeTypeManager: BadgeTypeManager;
    zoneManager: ZoneManager;
    personZoneManager: PersonZoneManager;
    holidayManager: HolidayManager;
    constructor();
    /**
     * Current state of the server
     */
    get state(): ServerState;
    /**
     * Tell if the appServer object is connected or not
     */
    get isConnected(): boolean;
    /**
     * Last keepalive info received
     */
    get keepAliveInfo(): KeepAliveInfo;
    /**
     * Update the number of retry when keep alive fails before being disconnected
     * @param val Number of retry
     */
    setKeepAliveRetryNb(val: number): void;
    /**
     * Update the tempo between each keep alive fails before being disconnected
     * @param val Tempo in ms
     */
    setKeepAliveRetryTempo(val: number): void;
    /**
     * Get information about the server. This request does not require authentification.
     * @param host Server url.
     * @returns A ServerInfo object.
     */
    hello(host: string): Promise<ServerInfo>;
    /**
     * Change pasword of an user
     * @param username Username
     * @param oldPassword Old password
     * @param newPassword New password
     */
    changeUserPassword(username: string, oldPassword: string, newPassword: string): Promise<void>;
    /**
     * Login informations
     * @param options
     */
    login(options: AppLoginOptions): Promise<void>;
    /**
     * Logout
     */
    logout(): Promise<void>;
    /**
     * Start loop to send keepalive
     * @param tempo Tempo in ms (Default: 2000)
     */
    startKeepAlive(tempo?: number): void;
    /**
     * Send keepalive to the server.
     * Warning: Use this method yourself only if you have set the handleKeepAliveManually parameter to true in the login method.
     * @returns Promise
     */
    sendKeepAlive(): Promise<any[]>;
    private keepAliveLoop;
    private handleNewEvents;
    private dispose;
}
