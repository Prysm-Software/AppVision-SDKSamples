/**
 * Login options
 */
export interface AppLoginOptions {
    /**
     * Server host
     */
    host: string;
    /**
     * Username
     */
    username: string;
    /**
     * Password
     */
    password: string;
    /**
     * Name of the product using the SDK
     */
    productName?: string;
    /**
     * Descrition of the product
     */
    productDescription?: string;
    /**
     * Company name
     */
    productCompany?: string;
    /**
     * Name of the process (ex: chrome, androidphone...)
     */
    productProcess?: string;
    /**
     * Application version
     */
    applicationVersion?: string;
    /**
     * Hostname of the client using the SDK (ex: Android of clem ...)
     */
    clientHostname?: string;
    /**
     * Client executing module
     */
    clientExecutingModule?: string;
    /**
    * Device Id
    */
    deviceId?: string;
    /**
     * Do not use cookie to store session (default: false)
     */
    noCookie?: boolean;
    /**
     * Any others data to post
     */
    datas?: any;
    /**
     * Notification filter
     * Default: All
     */
    notifFilter?: string;
    /**
     * Retry number when keepalive failed before being logged out
     * Default: 3
     */
    keepAliveFailRetryNb?: number;
    /**
     * Retry tempo in ms between each keepalive fail
     * Default: 5000 ms
     */
    keepAliveFailRetryTempo?: number;
}
