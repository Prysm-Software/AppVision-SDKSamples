"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextReportManager = void 0;
const textReportRow_1 = require("../data/textReportRow");
class TextReportManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all TextReportRow from the server
     * @returns Array of TextReportRow
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.getAsJson('AppVisionService.svc/GetReports');
            return resp.map(o => new textReportRow_1.TextReportRow(o));
        });
    }
    /**
     * Add a new TextReportRow
     * @param obj TextReportRow to add
     * @returns TextReportRow created
     */
    add(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.postAsJson('AppVisionService.svc/ReportManager/Add', JSON.stringify(row));
            return new textReportRow_1.TextReportRow(json);
        });
    }
    /**
     * Update an TextReportRow
     * @param obj TextReportRow to update
     * @returns TextReportRow updated
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.postAsJson('AppVisionService.svc/ReportManager/Update', JSON.stringify(row));
            return new textReportRow_1.TextReportRow(json);
        });
    }
    /**
     * Delete a TextReportRow
     * @param id TextReportRow Id
     */
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('AppVisionService.svc/DeleteReport', JSON.stringify({ Id: id }));
            if (resp === false)
                throw new Error("Failed to delete");
        });
    }
}
exports.TextReportManager = TextReportManager;
