"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileManager = void 0;
const fileInfoRow_1 = require("../data/fileInfoRow");
const rxjs_1 = require("rxjs");
const treeHelper_1 = require("../common/treeHelper");
class FileManager {
    constructor(http) {
        this.http = http;
        this.rowsUpdated = new rxjs_1.Subject();
    }
    /**
     * Build file tree
     * @param types FileType filter (FileType)
     * @returns Tree of FileInfoRow
     */
    getRowsTree(...types) {
        const rows = (types === null || types === void 0 ? void 0 : types.length) > 0 ?
            this.fileInfos
                .filter(f => f.TypeInt === 5 || types.indexOf(f.TypeInt) > -1) //  5=dossier + types demandés
                .map(a => new fileInfoRow_1.FileInfoRow(a)) :
            this.fileInfos.map(a => new fileInfoRow_1.FileInfoRow(a));
        rows.sort((a, b) => {
            let x = a.type.toLowerCase();
            let y = b.type.toLowerCase();
            if (x < y)
                return -1;
            if (x > y)
                return 1;
            return 0;
        });
        return treeHelper_1.TreeHelper.buildTreeRow(rows, '\\');
    }
    /**
     * Build file tree with filter
     * @param types FileType filter (FileType)
     * @returns Tree of FileInfoRow
     */
    getRowsTreeByFilter(filter) {
        const rows = filter ?
            this.fileInfos.filter(f => f.TypeInt === 5 || filter(f)).map(a => new fileInfoRow_1.FileInfoRow(a)) :
            this.fileInfos.map(a => new fileInfoRow_1.FileInfoRow(a));
        rows.sort((a, b) => {
            let x = a.type.toLowerCase();
            let y = b.type.toLowerCase();
            if (x < y)
                return -1;
            if (x > y)
                return 1;
            return 0;
        });
        return treeHelper_1.TreeHelper.buildTreeRow(rows, '\\');
    }
    /**
     * Get all files (flat)
     * @param types FileType filter (FileType)
     * @returns Array of FileInfoRow
     * @remark Get values from cache
     */
    getRows(...types) {
        const rows = (types === null || types === void 0 ? void 0 : types.length) > 0 ?
            this.fileInfos.filter(f => types.indexOf(f.TypeInt) > -1).map(f => new fileInfoRow_1.FileInfoRow(f)) :
            this.fileInfos.map(f => new fileInfoRow_1.FileInfoRow(f));
        return rows.sort((a, b) => {
            let x = a.type.toLowerCase();
            let y = b.type.toLowerCase();
            if (x < y)
                return -1;
            if (x > y)
                return 1;
            return 0;
        });
    }
    /**
     * Download file from server as string
     * @param url Url of the file
     * @returns File content as string
     *
     * @example
     * server.fileManager.getFile('Config/Client/MySuperFile.txt')
     */
    getFile(url) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(url);
            return yield resp.text();
        });
    }
    /**
     * Delete a file on the server
     * @param url Url of the file
     *
     * @example
     * server.fileManager.getFile('Config/Client/MySuperFile.txt')
     */
    deleteFile(url) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get(url + "?action=DELETE");
        });
    }
    /**
     * Update a file on the server
     * @param filePath Url of the file
     * @param file File content as Blob
     * @param header Http headers of the request
     */
    putFile(filePath, file, header) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.post(filePath, file, "PUT", header);
        });
    }
    /**
     * Request the server to get file names on disk
     * @param pattern search pattern (ex: *.png;*.jpg)
     * @returns Flat array of string (Flat)
     */
    getFileNames(pattern) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post("Config/Param/Client?pattern=" + pattern, null, "PROPFIND");
            const json = yield resp.json();
            return json;
        });
    }
    /**
     * Request the server to get file names on disk and return result as tree
     * @param pattern search pattern (ex: *.png;*.jpg), Default '*'
     * @returns Tree array of TreeRow
     */
    getFileTree(pattern = "*") {
        return __awaiter(this, void 0, void 0, function* () {
            const fileNames = yield this.getFileNames(pattern);
            return treeHelper_1.TreeHelper.buildTree(fileNames);
        });
    }
    /**
     * Get file url inside the config folder
     * @param filePath
     * @returns file path
     * @deprecated Use buildConfigFileUrl
     */
    getConfigFileUrl(filePath) {
        return this.buildConfigFileUrl(filePath);
    }
    /**
     * Get file url inside the Resources folder
     * @param filePath
     * @returns file path
     * @deprecated Use buildFileUrl
     */
    getResourceFileUrl(filePath) {
        return this.buildResourceFileUrl(filePath);
    }
    /**
     * Get file url from Config/Param/Client foler
     * @param filePath string
     * @returns file path
     * @deprecated Use buildFileUrl
     */
    getFileUrl(filePath) {
        return this.buildFileUrl(filePath);
    }
    /**
     * Get file url from Config/Param/AppControl/Photos/ folder
     * @param filePath
     * @returns File path
     * @deprecated Use buildAppControlPhotoUrl
     */
    getAppControlPhotoUrl(filePath) {
        return this.buildAppControlPhotoUrl(filePath);
    }
    /**
     * Build file url from Config/Param/AppControl/Photos/ folder
     * @param filePath
     * @returns
     */
    buildAppControlPhotoUrl(filePath) {
        return this.http.host + "Config/Param/AppControl/Photos/" + filePath;
    }
    /**
    * Build file url inside the config folder
    * @param filePath
    * @returns
    */
    buildConfigFileUrl(filePath) {
        return this.http.host + "config/" + filePath;
    }
    /**
     * Build file url inside the Resources folder
     * @param filePath
     * @returns
     */
    buildResourceFileUrl(filePath) {
        return this.http.host + "resources/" + filePath;
    }
    /**
     * Build file url from Config/Param/Client foler
     * @param filePath
     * @returns
     */
    buildFileUrl(filePath) {
        return this.http.host + "Config/Param/Client/" + filePath;
    }
    /**
     * Get the list of all log files
     * @returns String array of all files with their path
     */
    getLogFilesList() {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.getAsJson("AppVisionService.svc/logmanager/list");
            return json;
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetFileInfos');
            const json = yield resp.json();
            // this.fileInfos = (json as FileInfoRow[]).map(v => new FileInfoRow(v));
            this.fileInfos = json.filter(i => (i.ContextInt & 2) === 2);
        });
    }
    /** @internal */
    updateRowsInternal(infoRows) {
        // Rows to add or update
        for (const row of infoRows.filter(i => (i.ContextInt & 2) === 2)) {
            const index = this.fileInfos.findIndex(r => r.Id === row.Id);
            if (index >= 0) {
                // modified
                this.fileInfos[index] = row;
            }
            else {
                // new
                this.fileInfos.push(row);
            }
        }
        // The deleted rows have ContextInt to 0
        for (const row of infoRows.filter(i => i.Id < 0)) {
            const index = this.fileInfos.findIndex(r => r.Id === Math.abs(row.Id));
            if (index >= 0) {
                this.fileInfos.splice(index, 1);
            }
        }
        this.rowsUpdated.next(infoRows);
    }
}
exports.FileManager = FileManager;
