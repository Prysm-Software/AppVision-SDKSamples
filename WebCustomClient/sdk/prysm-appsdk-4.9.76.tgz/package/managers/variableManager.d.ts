import { VariableRow, VariableType } from "../data/variableRow";
import { VariableState } from "../data/variableState";
import { HttpService } from "../services/httpService";
import { ValueRow } from "../data/valueRow";
import { NameValue } from "../data/nameValue";
import { TreeRowManager } from "./base/treeRowManager";
export declare class VariableManager extends TreeRowManager<VariableRow, VariableState> {
    constructor(http: HttpService, odata: HttpService);
    /**
     * Set variable
     * @param varName Variable name
     * @param varValue Variable value
     * @param info Info field
     */
    set(varName: string, varValue: string, info?: string, params?: NameValue[]): Promise<void>;
    /**
     * Lock or unlock variable
     * @param varName VariableName
     * @param isLocked Lock or unlock
     * @param params NameValue parameters
     */
    lock(varName: string, isLocked: boolean, params: NameValue[]): Promise<void>;
    /**
     * Updates a VariableRow
     * @param row VariableRow to be updated.
     * @returns true if the variable has been successfully updated.
     */
    update(row: VariableRow): Promise<VariableRow[]>;
    /**
     * Add new VariableRow
     * @param row VariableRow to add
     * @returns VariableRow created
     */
    add(row: VariableRow): Promise<VariableRow>;
    /**
     * Add an array of rows
     * @param rows
     * @returns true ou false
     */
    adds(rows: VariableRow[]): Promise<boolean>;
    /**
     * Delete a row
     * @param row Row to delete
     */
    delete(row: VariableRow): Promise<void>;
    /**
     * Get all variable rows matching the given filter
     * @returns Tree of variable rows
     * @remark Get items from cache
     */
    getRowsTreeByFilter(filter: (row: VariableRow) => boolean): VariableRow[];
    /**
     * Get rows by type
     * @param rowType Variable row type
     * @returns Array of variables
     *
     * @remark
     * Get value from cache
     */
    getRowsByType(rowType: VariableType): VariableRow[];
    /**
     * Get variable states history
     * @param dateStart Filter date start
     * @param dateEnd  Filter date end
     * @param variableNames Filter variable names
     * @param maxCount Max count result. Default is 2500
     * @param start Result start index. Default is 0
     * @returns Array of variable rows
     */
    getHistoValues(dateStart: Date, dateEnd: Date, variableNames: string[], count?: number, start?: number): Promise<ValueRow[]>;
    /**
     * Request the full list of variable row.
     * This request includes excluded variables
     * @returns Array of VariableRow
     */
    getAll(): Promise<VariableRow[]>;
    /**
     * Request variables by filter
     * @param filter Filter text (ex: $A.Area1)
     * @returns Array of variable row
     * @example
     * server.variableManager.getRowsByFilter('$A.Area1|$G.Group1')
     */
    getRowsByFilter(filter: string): Promise<VariableRow[]>;
    /**
     * Request variables for a specific protocol
     * @param protocolName
     * @returns Array of VariableRow
     */
    getRowsByProtocol(protocolName: string): Promise<VariableRow[]>;
    protected constructRow(args: Partial<VariableRow>): VariableRow;
    protected constructState(args: Partial<VariableState>): VariableState;
    protected getState(id: number): Promise<VariableState>;
}
