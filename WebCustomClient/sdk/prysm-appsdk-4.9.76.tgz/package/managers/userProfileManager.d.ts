import { ProfileRow } from "../data/profileRow";
import { HttpService } from "../services/httpService";
import { RowManager } from "./base/rowManager";
export declare class UserProfileManager extends RowManager<ProfileRow> {
    constructor(http: HttpService, odata: HttpService);
    /**
     * Get profile from server
     * @returns Array of ProfileRow
     * @remark Request values from server
     */
    getAll(): Promise<ProfileRow[]>;
    /**
     * Delete profile
     * @param profile Profile to delete
     */
    delete(profile: ProfileRow): Promise<void>;
    /**
     * Add new profile
     * @param user Profile to add
     * @returns Id of the new profile
     */
    add(profile: ProfileRow): Promise<number>;
    /**
     * Update profile
     * @param profile ProfileRow to update
     */
    update(profile: ProfileRow): Promise<void>;
    protected constructRow(args: Partial<ProfileRow>): ProfileRow;
}
