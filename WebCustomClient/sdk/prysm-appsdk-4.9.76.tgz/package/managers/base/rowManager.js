"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RowManager = void 0;
const rxjs_1 = require("rxjs");
class RowManager {
    /**
     * Get the number of rows in cache
     */
    get count() { return this.rowsByName.size; }
    constructor(http, odata, options) {
        this.http = http;
        this.odata = odata;
        this.options = options;
        this.rowsUpdated = new rxjs_1.Subject();
        this.rowsAdded = new rxjs_1.Subject();
        this.rowsDeleted = new rxjs_1.Subject();
        this.rowsChanged = new rxjs_1.Subject();
    }
    /**
    * Get rows from cache
    * @returns Array of row rows
    * @remark Return value from cache
    */
    getRows() {
        return [...this.rowsById.values()].map(r => this.constructRow(r));
    }
    /**
     * Get row by id
     * @param id Row Id
     * @returns TRow
     * @remark Return value from cache
     */
    getRowById(id) {
        const row = this.rowsById.get(id);
        if (row)
            return this.constructRow(row);
        return null;
    }
    /**
     * Get row by name
     * @param name Row name
     * @returns TRow
     * @remark Return value from cache
     */
    getRowByName(name) {
        if (name.toLowerCase().startsWith('$' + this.options.letter.toLowerCase() + '.'))
            name = name.substring(3);
        const row = this.rowsByName.get(name);
        if (row)
            return this.constructRow(row);
        return null;
    }
    /** @internal */
    updateRowsInternal(rows) {
        return __awaiter(this, void 0, void 0, function* () {
            const added = [];
            const updated = [];
            let deleted = [];
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const originalRow = this.getRowById(row.Id);
                if (this.getRowByName(row.Name) == null && row.Id >= 0) {
                    const rowToDelete = this.getRows().find(v => v.Id === row.Id);
                    if (rowToDelete) {
                        // Si Name row non présent, Id présent et Id >=0 alors Name changed
                        // On supprime l'ancienne row
                        this.rowsByName.delete(rowToDelete.Name);
                        this.rowsById.delete(rowToDelete.Id);
                    }
                }
                // New
                if (originalRow == null && row.Id >= 0) {
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    added.push(row);
                }
                // Delete
                else if (row.Id < 0) {
                    const notifsRow = [row];
                    this.rowsByName.delete(row.Name);
                    this.rowsById.delete(Math.abs(row.Id));
                    const rowsByNameToDelete = [...this.rowsByName.keys()].filter(k => k.startsWith(row.Name + '.'));
                    rowsByNameToDelete.forEach(key => this.rowsByName.delete(key));
                    const rowsByIdToDelete = [...this.rowsById].filter(entry => entry[1].Name.startsWith(row.Name + '.'));
                    rowsByIdToDelete.forEach(entry => {
                        notifsRow.push(entry[1]);
                        this.rowsById.delete(entry[0]);
                    });
                    deleted = [...deleted, ...notifsRow];
                }
                // Update
                else {
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    updated.push(row);
                }
            }
            // On notifie les clients
            let notifs = [];
            if (added.length > 0) {
                this.rowsAdded.next(added);
                notifs = [...notifs, ...added.map(r => ({ row: r, type: "ADD" }))];
            }
            if (deleted.length > 0) {
                this.rowsDeleted.next(deleted);
                notifs = [...notifs, ...deleted.map(r => ({ row: r, type: "DELETE" }))];
            }
            if (updated.length > 0) {
                this.rowsUpdated.next(updated);
                notifs = [...notifs, ...updated.map(r => ({ row: r, type: "UPDATE" }))];
            }
            if (notifs.length > 0) {
                this.rowsChanged.next(notifs);
            }
        });
    }
}
exports.RowManager = RowManager;
