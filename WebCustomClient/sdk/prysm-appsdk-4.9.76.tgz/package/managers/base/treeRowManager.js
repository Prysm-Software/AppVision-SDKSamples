"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeRowManager = void 0;
const rxjs_1 = require("rxjs");
const treeHelper_1 = require("../../common/treeHelper");
const rowManager_1 = require("./rowManager");
class TreeRowManager extends rowManager_1.RowManager {
    constructor(http, odata, options) {
        super(http, odata, options);
        this.rowsUpdated = new rxjs_1.Subject();
        this.rowsAdded = new rxjs_1.Subject();
        this.rowsDeleted = new rxjs_1.Subject();
        this.rowsChanged = new rxjs_1.Subject();
        this.statesChanged = new rxjs_1.Subject();
    }
    /**
     * Build TRow tree
     * @returns Tree of TRow
     * @remark Return value from cache
     */
    getRowsTree() {
        return treeHelper_1.TreeHelper.buildTreeRow(this.getRows());
    }
    /**
     * Get row state by row name
     * @param name row name
     * @returns row state
     *
     * @remark
     * Get value from cache
     */
    getStateByName(name) {
        if (name.toLowerCase().startsWith('$' + this.options.letter.toLowerCase() + '.'))
            name = name.substring(3);
        const state = this.states.get(name);
        if (!state)
            return null;
        return this.constructState(state);
    }
    /**
     * Get row state by id
     * @param id Row id
     * @returns TState
     *
     * @remark
     * Get value from cache
     */
    getStateById(id) {
        const row = this.rowsById.get(id);
        if (row == null)
            return null;
        const state = this.getStateByName(row.Name);
        if (state == null)
            return null;
        return this.constructState(state);
    }
    /**
     * Get all states from cache
     * @returns
     */
    getStates() {
        return [...this.states.values()].map(r => this.constructState(r));
    }
    /** @internal */
    updateRowsInternal(rows) {
        return __awaiter(this, void 0, void 0, function* () {
            const added = [];
            const updated = [];
            let deleted = [];
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const originalRow = this.getRowById(row.Id);
                if (this.getStateByName(row.Name) == null && row.Id >= 0) {
                    const rowToDelete = this.getRows().find(v => v.Id === row.Id);
                    if (rowToDelete) {
                        // Si Name row non présent, Id présent et Id >=0 alors Name changed
                        // On supprime l'ancienne row
                        this.rowsByName.delete(rowToDelete.Name);
                        this.rowsById.delete(rowToDelete.Id);
                        this.states.delete(rowToDelete.Name);
                    }
                }
                // New
                if (originalRow == null && row.Id >= 0) {
                    const state = yield this.getState(row.Id);
                    if (state) {
                        row.State = state;
                        this.states.set(state.Name, state);
                    }
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    added.push(row);
                }
                // Delete
                else if (row.Id < 0) {
                    const notifsRow = [row];
                    this.rowsByName.delete(row.Name);
                    this.rowsById.delete(Math.abs(row.Id));
                    this.states.delete(row.Name);
                    const rowsByNameToDelete = [...this.rowsByName.keys()].filter(k => k.startsWith(row.Name + '.'));
                    rowsByNameToDelete.forEach(key => this.rowsByName.delete(key));
                    const statesByNameToDelete = [...this.states.keys()].filter(k => k.startsWith(row.Name + '.'));
                    statesByNameToDelete.forEach(key => this.states.delete(key));
                    const rowsByIdToDelete = [...this.rowsById].filter(entry => entry[1].Name.startsWith(row.Name + '.'));
                    rowsByIdToDelete.forEach(entry => {
                        notifsRow.push(entry[1]);
                        this.rowsById.delete(entry[0]);
                    });
                    deleted = [...deleted, ...notifsRow];
                }
                // Update
                else {
                    // WARNING : FullDescription is empty inside the notif object
                    const state = originalRow.State;
                    if (state) {
                        // Update the state if name changed
                        state.Name = row.Name;
                        this.states.set(state.Name, state);
                        row.State = state;
                    }
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    updated.push(row);
                }
            }
            // On reconstruit les relation parent enfants sur les rows qui ont changé
            const updateRelation = [...added, ...updated];
            if (updateRelation.length > 0)
                treeHelper_1.TreeHelper.buildTreeRow(updateRelation);
            // On notifie les clients
            let notifs = [];
            if (added.length > 0) {
                this.rowsAdded.next(added);
                notifs = [...notifs, ...added.map(r => ({ row: r, type: "ADD" }))];
            }
            if (deleted.length > 0) {
                this.rowsDeleted.next(deleted);
                notifs = [...notifs, ...deleted.map(r => ({ row: r, type: "DELETE" }))];
            }
            if (updated.length > 0) {
                this.rowsUpdated.next(updated);
                notifs = [...notifs, ...updated.map(r => ({ row: r, type: "UPDATE" }))];
            }
            if (notifs.length > 0) {
                this.rowsChanged.next(notifs);
            }
        });
    }
    /** @internal */
    updateStatesInternal(states) {
        const updatedStates = [];
        states.forEach(state => {
            const row = this.rowsByName.get(state.Name);
            if (row) {
                row.State = state;
                this.states.set(state.Name, state);
                updatedStates.push(state);
            }
        });
        if (updatedStates.length > 0) {
            this.statesChanged.next(updatedStates);
        }
    }
}
exports.TreeRowManager = TreeRowManager;
