import { Subject } from "rxjs";
import { HttpService } from "../../services/httpService";
import { TreeRow } from "../../data/treeRow";
import { ManagerOptions, RowManager } from "./rowManager";
export declare abstract class TreeRowManager<TRow extends TreeRow & {
    State: TState;
}, TState extends {
    Id: number;
    Name: string;
}> extends RowManager<TRow> {
    protected rowsByName: Map<string, TRow>;
    protected rowsById: Map<number, TRow>;
    protected states: Map<string, TState>;
    protected options: ManagerOptions;
    /**
     * Called when a state changed
     */
    statesChanged: Subject<TState[]>;
    constructor(http: HttpService, odata: HttpService, options: ManagerOptions);
    protected abstract constructState(args: Partial<TState>): TState;
    protected abstract getState(id: number): Promise<TState>;
    /**
     * Build TRow tree
     * @returns Tree of TRow
     * @remark Return value from cache
     */
    getRowsTree(): TRow[];
    /**
     * Get row state by row name
     * @param name row name
     * @returns row state
     *
     * @remark
     * Get value from cache
     */
    getStateByName(name: string): TState;
    /**
     * Get row state by id
     * @param id Row id
     * @returns TState
     *
     * @remark
     * Get value from cache
     */
    getStateById(id: number): TState;
    /**
     * Get all states from cache
     * @returns
     */
    getStates(): TState[];
}
