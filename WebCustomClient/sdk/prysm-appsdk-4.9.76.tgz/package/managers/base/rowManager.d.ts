import { Subject } from "rxjs";
import { HttpService } from "../../services/httpService";
import { RowNotif } from "../../data/rowNotif";
export interface ManagerOptions {
    letter: string;
}
type Entity = {
    Id: number;
    Name: string;
};
export declare abstract class RowManager<TRow extends Entity> {
    protected http: HttpService;
    protected odata: HttpService;
    protected rowsByName: Map<string, TRow>;
    protected rowsById: Map<number, TRow>;
    protected options: ManagerOptions;
    /**
     * Called when a row is added
     */
    rowsAdded: Subject<TRow[]>;
    /**
     * Called when a row is deleted
     */
    rowsDeleted: Subject<TRow[]>;
    /**
     * Called when a row is updated
     */
    rowsUpdated: Subject<TRow[]>;
    /**
     * Called when a row is added, updated or deleted
     */
    rowsChanged: Subject<RowNotif<TRow>[]>;
    /**
     * Get the number of rows in cache
     */
    get count(): number;
    constructor(http: HttpService, odata: HttpService, options: ManagerOptions);
    protected abstract constructRow(args: Partial<TRow>): TRow;
    /**
    * Get rows from cache
    * @returns Array of row rows
    * @remark Return value from cache
    */
    getRows(): TRow[];
    /**
     * Get row by id
     * @param id Row Id
     * @returns TRow
     * @remark Return value from cache
     */
    getRowById(id: number): TRow;
    /**
     * Get row by name
     * @param name Row name
     * @returns TRow
     * @remark Return value from cache
     */
    getRowByName(name: string): TRow;
}
export {};
