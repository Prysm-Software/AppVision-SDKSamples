"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AreaManager = void 0;
const helper_1 = require("../common/helper");
const treeHelper_1 = require("../common/treeHelper");
const areaRow_1 = require("../data/areaRow");
const areaState_1 = require("../data/areaState");
const treeRowManager_1 = require("./base/treeRowManager");
class AreaManager extends treeRowManager_1.TreeRowManager {
    constructor(http, odata) {
        super(http, odata, { letter: 'A' });
    }
    /**
     * Request the full list of areas row.
     * This request includes excluded entities
     * @returns Array of AreaRow
     * @remark Request values from the server
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.get('AppVisionDataService.svc/Areas');
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value.map(p => new areaRow_1.AreaRow(p));
        });
    }
    /**
     * Delete an area
     * @param row AreaRow
     */
    delete(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(row);
            const resp = yield this.http.post('AppVisionService.svc/DeleteArea', JSON.stringify(clone));
            const json = yield resp.json();
            return json;
        });
    }
    /**
     * Add new area
     * @param area AreaRow to add
     * @returns AreaRow added
     */
    add(area) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(area);
            const json = yield this.http.postAsJson('AppVisionService.svc/AreaManager/Add', JSON.stringify(clone));
            return new areaRow_1.AreaRow(json);
        });
    }
    /**
     * Update a area
     * @param area
     * @returns Array of AreaRow updated
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(row);
            const json = yield this.http.postAsJson('AppVisionService.svc/AreaManager/Update', JSON.stringify(clone));
            return json.map(r => new areaRow_1.AreaRow(r));
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            let resp = yield this.http.get('AppVisionService.svc/GetAreaStates');
            let json = yield resp.json();
            this.states = new Map();
            for (const s of json)
                this.states.set(s.Name, new areaState_1.AreaState(s));
            resp = yield this.http.get('AppVisionService.svc/GetAreas');
            json = yield resp.json();
            this.rowsByName = new Map();
            this.rowsById = new Map();
            for (const r of json) {
                const row = new areaRow_1.AreaRow(r);
                const state = this.states.get(r.Name);
                if (state) { // liaison row <-> state
                    row.State = state;
                }
                this.rowsByName.set(r.Name, row);
                this.rowsById.set(r.Id, row);
            }
            // liaison .parent .items
            treeHelper_1.TreeHelper.buildTreeRow([...this.rowsByName.values()]);
        });
    }
    constructRow(args) {
        return new areaRow_1.AreaRow(args);
    }
    constructState(args) {
        return new areaState_1.AreaState(args);
    }
    getState(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const resp = yield this.http.get('AppVisionService.svc/GetAreaStateById?id=' + id);
                const json = yield resp.json();
                return new areaState_1.AreaState(json);
            }
            catch (e) {
                return null;
            }
        });
    }
}
exports.AreaManager = AreaManager;
