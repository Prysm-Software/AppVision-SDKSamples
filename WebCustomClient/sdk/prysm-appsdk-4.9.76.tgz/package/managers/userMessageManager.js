"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserMessageManager = exports.XmlTags = void 0;
const dateHelper_1 = require("../common/dateHelper");
const xmlParser_1 = require("../common/xmlParser");
const userMessageRow_1 = require("../data/userMessageRow");
var XmlTags;
(function (XmlTags) {
    XmlTags["Xml"] = "<?xml version=\"1.0\" encoding=\"utf-16\"?>";
    XmlTags["ArrayOfUserMessageCategory"] = "ArrayOfUserMessageCategory";
    XmlTags["UserMessageCategory"] = "UserMessageCategory";
    XmlTags["Description"] = "Description";
    XmlTags["Icon"] = "Icon";
    XmlTags["Severity"] = "Severity";
    XmlTags["Properties"] = "Properties";
    XmlTags["UserMessageCategoryProperty"] = "UserMessageCategoryProperty";
    XmlTags["NameValue"] = "NameValue";
    XmlTags["IsRequired"] = "IsRequired";
    XmlTags["Values"] = "Values";
    XmlTags["Type"] = "Type";
    XmlTags["ArrayOfNameValue"] = "ArrayOfNameValue";
    XmlTags["Name"] = "Name";
    XmlTags["Value"] = "Value";
})(XmlTags = exports.XmlTags || (exports.XmlTags = {}));
class UserMessageManager {
    constructor(http, optionManager) {
        this.optionName = "App.Client.UserMessage.MessageObjects";
        /**
         * JSON.stringify() replacer function that transforms date fields into
         * WCF-compatible formats during serialization.
         *
         * Handles:
         *   - DateTimeOffset fields (e.g., DateCreate, DateClose)
         *     → converted to `{ DateTime: "/Date(ms)/", OffsetMinutes: X }`
         *   - DateTime fields (e.g., DateWrite)
         *     → converted to `/Date(ms)/`
         *
         * This ensures the final JSON payload matches the formats expected by WCF
         * services using DataContractJsonSerializer.
         *
         * @param key The property name currently being serialized.
         * @param value The value associated with the property.
         * @returns The transformed value (if a date field) or the original value.
         */
        this.wcfDateReplacer = (key, value) => {
            // ----- DateTimeOffset fields -----
            if (key === 'DateCreate' || key === 'DateClose') {
                if (value == null)
                    return value;
                // Case: already in shape { DateTime, OffsetMinutes }
                if (typeof value === 'object' &&
                    value !== null &&
                    'DateTime' in value &&
                    'OffsetMinutes' in value) {
                    const v = value;
                    const raw = v.DateTime;
                    // Already WCF string → normalize and return
                    if (dateHelper_1.DateHelper.isWcfDateString(raw)) {
                        return {
                            DateTime: raw,
                            OffsetMinutes: Number(v.OffsetMinutes),
                        };
                    }
                    // numeric, ISO, Date, or numeric string → normalize
                    return {
                        DateTime: dateHelper_1.DateHelper.toWcfDate(raw),
                        OffsetMinutes: Number(v.OffsetMinutes),
                    };
                }
                // Case: simple Date | ISO | timestamp
                return dateHelper_1.DateHelper.toWcfDateTimeOffset(value);
            }
            // ----- DateTime (simple) fields -----
            if (key === 'DateWrite') {
                if (value == null)
                    return value;
                // Idempotence: if already WCF string, return as-is
                if (dateHelper_1.DateHelper.isWcfDateString(value)) {
                    return value;
                }
                return dateHelper_1.DateHelper.toWcfDate(value);
            }
            return value;
        };
        this.http = http;
        this.optionManager = optionManager;
    }
    /**
     * Get user message categories
     * @returns Array of UserMessageCategory
     */
    getCategories() {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const categories = [];
        const xml = this.optionManager.get(this.optionName);
        if (xml) {
            const parser = new xmlParser_1.XmlParser();
            const doc = parser.parseFromString(xml);
            const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
            if (root) {
                const arr = root.getElementsByTagName(XmlTags.UserMessageCategory);
                if (arr) {
                    var categoryId = 0;
                    for (const cat of arr) {
                        const properties = [];
                        const propsRoot = cat.getElementsByTagName(XmlTags.Properties)[0];
                        if (propsRoot) {
                            const xmlProps = propsRoot.getElementsByTagName(XmlTags.UserMessageCategoryProperty);
                            if (xmlProps) {
                                var propertyId = 0;
                                for (const prop of xmlProps) {
                                    properties.push({
                                        Id: propertyId++,
                                        Name: prop.getElementsByTagName(XmlTags.Name)[0].value,
                                        Description: (_a = prop.getElementsByTagName(XmlTags.Description)[0]) === null || _a === void 0 ? void 0 : _a.value,
                                        IsRequired: ((_c = (_b = prop.getElementsByTagName(XmlTags.IsRequired)[0]) === null || _b === void 0 ? void 0 : _b.value) === null || _c === void 0 ? void 0 : _c.toLowerCase()) === 'true',
                                        Values: (_d = prop.getElementsByTagName(XmlTags.Values)[0]) === null || _d === void 0 ? void 0 : _d.value,
                                        CategoryType: (_e = prop.getElementsByTagName(XmlTags.Type)[0]) === null || _e === void 0 ? void 0 : _e.value
                                    });
                                }
                            }
                        }
                        categories.push({
                            Id: categoryId++,
                            Description: (_f = cat.getElementsByTagName(XmlTags.Description)[0]) === null || _f === void 0 ? void 0 : _f.value,
                            Icon: (_g = cat.getElementsByTagName(XmlTags.Icon)[0]) === null || _g === void 0 ? void 0 : _g.value,
                            Severity: Number.parseInt((_h = cat.getElementsByTagName(XmlTags.Severity)[0]) === null || _h === void 0 ? void 0 : _h.value),
                            Properties: properties
                        });
                    }
                }
            }
        }
        return categories;
    }
    /**
     * Get user message category by description
     * @param categoryDesc Description of the user message category
     * @param categoryPropCount Count of category properties
     * @returns The first UserMessageCategory found with the given description and the given properties count if specified
     */
    getCategoryByDesc(categoryDesc, categoryPropCount = 0) {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        const xml = this.optionManager.get(this.optionName);
        if (!xml)
            return null;
        const parser = new xmlParser_1.XmlParser();
        const doc = parser.parseFromString(xml);
        const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
        if (!root)
            return null;
        const arr = root.getElementsByTagName(XmlTags.UserMessageCategory);
        if (!arr)
            return null;
        var catId = 0;
        for (const cat of arr) {
            const desc = cat.getElementsByTagName(XmlTags.Description)[0].value;
            if (desc !== categoryDesc)
                continue;
            const properties = [];
            const propsRoot = cat.getElementsByTagName(XmlTags.Properties)[0];
            if (propsRoot) {
                const xmlProps = propsRoot.getElementsByTagName(XmlTags.UserMessageCategoryProperty);
                if (xmlProps) {
                    var propertyId = 0;
                    for (const prop of xmlProps) {
                        properties.push({
                            Id: propertyId++,
                            Name: prop.getElementsByTagName(XmlTags.Name)[0].value,
                            Description: (_a = prop.getElementsByTagName(XmlTags.Description)[0]) === null || _a === void 0 ? void 0 : _a.value,
                            IsRequired: ((_c = (_b = prop.getElementsByTagName(XmlTags.IsRequired)[0]) === null || _b === void 0 ? void 0 : _b.value) === null || _c === void 0 ? void 0 : _c.toLowerCase()) === 'true',
                            Values: (_d = prop.getElementsByTagName(XmlTags.Values)[0]) === null || _d === void 0 ? void 0 : _d.value,
                            CategoryType: (_e = prop.getElementsByTagName(XmlTags.Type)[0]) === null || _e === void 0 ? void 0 : _e.value
                        });
                    }
                }
            }
            if (!categoryPropCount || categoryPropCount === properties.length)
                return {
                    Id: catId,
                    Description: (_f = cat.getElementsByTagName(XmlTags.Description)[0]) === null || _f === void 0 ? void 0 : _f.value,
                    Icon: (_g = cat.getElementsByTagName(XmlTags.Icon)[0]) === null || _g === void 0 ? void 0 : _g.value,
                    Severity: Number.parseInt((_h = cat.getElementsByTagName(XmlTags.Severity)[0]) === null || _h === void 0 ? void 0 : _h.value),
                    Properties: properties
                };
            catId++;
        }
        return null;
    }
    /**
     * Get user messages from the server
     * @param dateStart Date start filter
     * @param dateEnd Date end filter
     * @param filters Filter operand
     * @param maxCount Max count result. Default is 2500
     * @returns Array of UserMessageRow
     */
    getUserMessages(dateStart, dateEnd, filters, maxCount = 2500) {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = `AppVisionService.svc/GetUserMessages?minId=0&maxCount=${maxCount}&dateStart=${dateStart.toISOString()}`;
            if (dateEnd) {
                uri += `&dateEnd=${dateEnd.toISOString()}`;
            }
            if (filters) {
                uri += `&filters=${filters}`;
            }
            const resp = yield this.http.get(uri);
            const json = yield resp.json();
            return json.map(e => new userMessageRow_1.UserMessageRow(e));
        });
    }
    /**
     * Retrieves a user message from the server by its identifier
     * @param id The unique identifier of the user message to retrieve
     * @returns A promise that resolves to a `UserMessageRow` representing the requested message
     */
    getUserMessageById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = `AppVisionService.svc/GetUserMessageById?umId=${id}`;
            const resp = yield this.http.get(uri);
            const json = yield resp.json();
            return new userMessageRow_1.UserMessageRow(json);
        });
    }
    /**
     * Call the API to add a new user message
     * @param userMessageRow User message to add
     * @returns The response of the API: the ID of the user message if successfully added
     */
    add(userMessageRow) {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = `AppVisionService.svc/UserMessageManager/Add`;
            let body = JSON.stringify(userMessageRow, this.wcfDateReplacer);
            const resp = yield this.http.post(uri, body, "POST", { "Content-Type": "application/json" });
            const json = yield resp.json();
            return new userMessageRow_1.UserMessageRow(json);
        });
    }
    /**
     * Call the API to update a new user message
     * @param userMessageRow User message to update
     */
    update(userMessageRow) {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = `AppVisionService.svc/UserMessageManager/update`;
            let body = JSON.stringify(userMessageRow, this.wcfDateReplacer);
            const resp = yield this.http.post(uri, body, "POST", { "Content-Type": "application/json" });
            const json = yield resp.json();
            return new userMessageRow_1.UserMessageRow(json);
        });
    }
    /**
     * Transform an array of UserMessageProperty into a xml string compatible with the UserMessageRow.ContentCategory property
     * @param properties Array of UserMessageProperty to transform
     * @returns The xml string
     */
    userMessagePropertiesToXml(properties) {
        const xmlParser = new xmlParser_1.XmlParser();
        const props = new xmlParser_1.XMLElement();
        props.name = XmlTags.ArrayOfNameValue;
        const propsChildren = [];
        properties.forEach(p => {
            const propNameValue = new xmlParser_1.XMLElement();
            propNameValue.name = XmlTags.NameValue;
            const propName = new xmlParser_1.XMLElement();
            propName.name = XmlTags.Name;
            propName.value = p.Name;
            const propValue = new xmlParser_1.XMLElement();
            propValue.name = XmlTags.Value;
            propValue.value = p.Value;
            propNameValue.children = [
                propName, propValue
            ];
            propsChildren.push(propNameValue);
        });
        props.children = propsChildren;
        return XmlTags.Xml + xmlParser.toString(props);
    }
    categoryToXml(category) {
        const newElem = new xmlParser_1.XMLElement();
        newElem.name = XmlTags.UserMessageCategory;
        const descElem = new xmlParser_1.XMLElement();
        descElem.name = XmlTags.Description;
        descElem.value = category.Description;
        const children = [
            descElem
        ];
        if (category.Icon) {
            const iconElem = new xmlParser_1.XMLElement();
            iconElem.name = XmlTags.Icon;
            iconElem.value = category.Icon;
            children.push(iconElem);
        }
        if (category.Severity) {
            const severityElem = new xmlParser_1.XMLElement();
            severityElem.name = XmlTags.Severity;
            severityElem.value = category.Severity.toString();
            children.push(severityElem);
        }
        if (category.Properties) {
            const propsElem = new xmlParser_1.XMLElement();
            propsElem.name = XmlTags.Properties;
            category.Properties.forEach(prop => {
                propsElem.children.push(this.categoryPropertyToXml(prop));
            });
            children.push(propsElem);
        }
        newElem.children = children;
        return newElem;
    }
    categoryPropertyToXml(prop) {
        const propElem = new xmlParser_1.XMLElement();
        propElem.name = XmlTags.UserMessageCategoryProperty;
        const propNameElem = new xmlParser_1.XMLElement();
        propNameElem.name = XmlTags.Name;
        propNameElem.value = prop.Name;
        const propDescElem = new xmlParser_1.XMLElement();
        propDescElem.name = XmlTags.Description;
        propDescElem.value = prop.Description;
        const propTypeElem = new xmlParser_1.XMLElement();
        propTypeElem.name = XmlTags.Type;
        propTypeElem.value = prop.CategoryType;
        const propsChildren = [
            propNameElem,
            propDescElem,
            propTypeElem
        ];
        if (prop.Values) {
            const propValuesElem = new xmlParser_1.XMLElement();
            propValuesElem.name = XmlTags.Values;
            propValuesElem.value = prop.Values;
            propsChildren.push(propValuesElem);
        }
        const propIsRequiredElem = new xmlParser_1.XMLElement();
        propIsRequiredElem.name = XmlTags.IsRequired;
        propIsRequiredElem.value = String(prop.IsRequired);
        propsChildren.push(propIsRequiredElem);
        propElem.children = propsChildren;
        return propElem;
    }
    /**
     * Add new user message category
     * @param category UserMessageCategory to add
     * @returns True if the operation has succeeded or an error message if not
     */
    addCategory(category) {
        const parser = new xmlParser_1.XmlParser();
        const xml = this.optionManager.get(this.optionName);
        // create an empty XML element
        let doc = new xmlParser_1.XMLElement(XmlTags.ArrayOfUserMessageCategory);
        if (xml) {
            doc = parser.parseFromString(xml);
        }
        const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
        root.children.push(this.categoryToXml(category));
        this.optionManager.set(this.optionName, XmlTags.Xml + parser.toString(doc));
    }
    /**
     * Update a user message category
     * @param category Category to update
     * @returns True if the operation has succeeded or an error message if not
     */
    updateCategory(category) {
        const xml = this.optionManager.get(this.optionName);
        const parser = new xmlParser_1.XmlParser();
        const doc = parser.parseFromString(xml);
        const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
        root.children[category.Id] = this.categoryToXml(category);
        this.optionManager.set(this.optionName, XmlTags.Xml + parser.toString(doc));
    }
    /**
     * Remove 1 user message category, based on its index
     * @param index Index of UserMessageCategory to remove
     */
    removeCategory(index) {
        const xml = this.optionManager.get(this.optionName);
        const parser = new xmlParser_1.XmlParser();
        const doc = parser.parseFromString(xml);
        const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
        root.children.splice(index, 1);
        this.optionManager.set(this.optionName, XmlTags.Xml + parser.toString(doc));
    }
    /**
     * Remove several user message categories, based on their indexes
     * @param indexes Array of indexes of UserMessageCategory to remove
     */
    removeCategories(indexes) {
        const xml = this.optionManager.get(this.optionName);
        const parser = new xmlParser_1.XmlParser();
        const doc = parser.parseFromString(xml);
        const root = doc.getElementsByTagName(XmlTags.ArrayOfUserMessageCategory)[0];
        indexes.sort((a, b) => (a > b ? -1 : 1)).forEach(value => {
            root.children.splice(value, 1);
        });
        this.optionManager.set(this.optionName, XmlTags.Xml + parser.toString(doc));
    }
}
exports.UserMessageManager = UserMessageManager;
