import { Subject } from "rxjs";
import { ProtocolRow } from "../data/protocolRow";
import { ProtocolState } from "../data/protocolState";
import { HttpService } from "../services/httpService";
export declare class ProtocolManager {
    private http;
    private odata;
    private rows;
    private states;
    statesChanged: Subject<ProtocolState[]>;
    constructor(http: HttpService, odata: HttpService);
    /**
     * Return protocol rows from cache
     * @returns Array of ProtocolRow
     */
    getRows(): ProtocolRow[];
    /**
     * Return protocol state from cache
     * @returns Array of ProtocolState
     */
    getStates(): ProtocolState[];
    /**
     * Start a protocol by name
     * @param protocolName Protocol name
     */
    start(protocolName: string): Promise<void>;
    /**
     * Stop a protocol by name
     * @param protocolName
     */
    stop(protocolName: string): Promise<void>;
    /**
     * Send a download request to protocols
     * @param rows Array of protocol names
     * @param parameters Parameters
     */
    sendDownload(rows: string[], parameters: string): Promise<void>;
    /**
     * Request the full list of protocols row.
     * This request includes excluded entities
     * @returns Array of GroupRow
     */
    getAll(): Promise<ProtocolRow[]>;
    /**
     * Get a protocol by his name
     * @returns ProtocolRow
     */
    getByName(name: string): Promise<ProtocolRow>;
    /**
    * Delete a protocol by it's Id
    * @param id
    */
    delete(id: number): Promise<void>;
    /**
     * Add new protocol
     * @param area ProtocolRow to add
     * @returns ProtocolRow added
     */
    add(obj: ProtocolRow): Promise<ProtocolRow>;
    /**
     * Update a protocol
     * @param protocol
     */
    update(p: ProtocolRow): Promise<void>;
}
