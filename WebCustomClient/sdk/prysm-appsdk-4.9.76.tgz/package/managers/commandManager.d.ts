import { Subject } from 'rxjs';
import { Command } from "../data/commands/command";
export declare class CommandManager {
    /**
     * Will trigger when a command is received : Open, load, close...
     */
    commandReceived: Subject<Command>;
    constructor();
    private processClientCommand;
    private processCloseCommand;
}
