"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserProfileManager = void 0;
const profileRow_1 = require("../data/profileRow");
const helper_1 = require("../common/helper");
const rowManager_1 = require("./base/rowManager");
class UserProfileManager extends rowManager_1.RowManager {
    constructor(http, odata) {
        super(http, odata, { letter: 'P' });
    }
    /**
     * Get profile from server
     * @returns Array of ProfileRow
     * @remark Request values from server
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetProfiles');
            const profileResp = yield resp.json();
            return profileResp.map(p => new profileRow_1.ProfileRow(p));
        });
    }
    /**
     * Delete profile
     * @param profile Profile to delete
     */
    delete(profile) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('AppVisionService.svc/DeleteProfile', JSON.stringify(profile));
            const json = yield resp.json();
            if (!json)
                throw new Error("Server returned false");
        });
    }
    /**
     * Add new profile
     * @param user Profile to add
     * @returns Id of the new profile
     */
    add(profile) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(profile);
            const resp = yield this.http.post('AppVisionService.svc/AddProfile', JSON.stringify(clone));
            const idResp = yield resp.text();
            return parseInt(idResp);
        });
    }
    /**
     * Update profile
     * @param profile ProfileRow to update
     */
    update(profile) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(profile);
            const resp = yield this.http.post('AppVisionService.svc/UpdateProfile', JSON.stringify(clone));
            const json = yield resp.json();
            if (!json)
                throw new Error("Server returned false");
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            // Load all profiles
            const all = yield this.getAll();
            this.rowsByName = new Map();
            this.rowsById = new Map();
            for (const r of all) {
                const row = new profileRow_1.ProfileRow(r);
                this.rowsByName.set(r.Name, row);
                this.rowsById.set(r.Id, row);
            }
        });
    }
    constructRow(args) {
        return new profileRow_1.ProfileRow(args);
    }
}
exports.UserProfileManager = UserProfileManager;
