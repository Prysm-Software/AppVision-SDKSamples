import { NameValue } from "../data/nameValue";
import { HttpService } from "../services/httpService";
export interface LicenseStatItem {
    name: string;
    value: number;
    max?: number;
}
export declare class LicenseManager {
    private http;
    private infos;
    constructor(http: HttpService);
    /**
     * Get licence field value
     * @param key Licence field name
     * @returns Value as string
     */
    get(key: string): string;
    /**
     * Get license infos
     * @returns Dictionnary
     */
    getInfos(): Promise<NameValue[]>;
    /**
     * Get license stat infos
     * @returns Array of AppStatItem
     */
    getStatInfos(): Promise<LicenseStatItem[]>;
}
