import { MailingRow } from "../data/mailingRow";
import { HttpService } from "../services/httpService";
export declare class MailingManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all mailings
     * @returns Array of MailingRow
     */
    getAll(): Promise<MailingRow[]>;
    /**
     * Add new mailing
     * @param row Mailing to add
     * @returns MailingRow created
     */
    add(row: MailingRow): Promise<MailingRow>;
    /**
     * Delete mailing
     * @param id Id to delete
     */
    delete(id: number): Promise<void>;
    /**
     * Update a mailing
     * @param row Row to update
     * @returns
     */
    update(row: MailingRow): Promise<void>;
}
