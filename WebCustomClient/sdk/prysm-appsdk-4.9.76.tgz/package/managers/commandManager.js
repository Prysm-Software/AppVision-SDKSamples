"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommandManager = void 0;
const rxjs_1 = require("rxjs");
const commandParser_1 = require("../data/commands/commandParser");
const closeCommand_1 = require("../data/commands/closeCommand");
class CommandManager {
    constructor() {
        this.commandReceived = new rxjs_1.Subject();
    }
    /** @internal */
    updateCommand(command) {
        if (command.startsWith("CommandClient;")) {
            this.processClientCommand(command);
        }
        else if (command === "Close;") {
            this.processCloseCommand();
        }
    }
    /** @internal */
    isCommand(command) {
        return command.startsWith("CommandClient;") ||
            command.startsWith("Close;");
    }
    processClientCommand(command) {
        const commandStr = command.replace("CommandClient;", "");
        const cmd = commandParser_1.CommandParser.parse(commandStr);
        if (command != null) {
            this.commandReceived.next(cmd);
        }
    }
    processCloseCommand() {
        this.commandReceived.next(new closeCommand_1.CloseCommand());
    }
}
exports.CommandManager = CommandManager;
