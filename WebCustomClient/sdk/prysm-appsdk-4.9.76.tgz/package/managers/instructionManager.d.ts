import { InstructionRow } from "../data/instructionRow";
import { HttpService } from "../services/httpService";
export declare class InstructionManager {
    private http;
    private odata;
    constructor(http: HttpService, odata: HttpService);
    /**
     * Get instructions from variable row
     * @param id Id of the variable
     * @returns Array of instructions
     */
    getByVariableId(id: number): Promise<InstructionRow[]>;
    /**
     * Get all instructionRow from the server
     * @returns Array of instructions
     */
    getAll(): Promise<InstructionRow[]>;
    /**
     * Add a new InstructionRow
     * @param obj InstructionRow to add
     * @returns InstructionRow created
     */
    add(row: InstructionRow): Promise<InstructionRow>;
    /**
     * Update an InstructionRow
     * @param obj InstructionRow to update
     * @returns InstructionRow updated
     */
    update(row: InstructionRow): Promise<InstructionRow>;
    /**
     * Delete an instruction
     * @param id InstructionRow Id
     */
    delete(id: number): Promise<void>;
}
