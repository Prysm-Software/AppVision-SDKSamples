import { WorkFlow } from "../data/workflow";
import { HttpService } from "../services/httpService";
import { FileManager } from "./fileManager";
export declare class WorkFlowManager {
    private http;
    private fileManager;
    constructor(http: HttpService, fileManager: FileManager);
    getByName(workflowName: string): Promise<WorkFlow>;
    private parseXML;
}
