import { FileManager } from "./fileManager";
import { EnvironmentModel } from "../data/environmentModels";
export declare class EnvironmentManager {
    private fileManager;
    constructor(fileManager: FileManager);
    /**
     * Create a new environment file on the server.
     * {filename}.webenv
     * @param filename Filename
     * @param env Environment object
     * @returns Filename created
     */
    createEnvironment(filename: string, env: EnvironmentModel): Promise<string>;
    /**
     * Download an environment from the server
     * @param filename Environment filename
     * @returns Environment object
     */
    getEnvironment(filename: string): Promise<EnvironmentModel>;
}
