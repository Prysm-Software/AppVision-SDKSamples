import { GroupRow } from "../data/groupRow";
import { GroupState } from "../data/groupState";
import { HttpService } from "../services/httpService";
import { TreeRowManager } from "./base/treeRowManager";
export declare class GroupManager extends TreeRowManager<GroupRow, GroupState> {
    constructor(http: HttpService, odata: HttpService);
    /**
     * Request the full list of areas row.
     * This request includes excluded entities
     * @returns Array of GroupRow
     * @remark Request value to the server
     */
    getAll(): Promise<GroupRow[]>;
    /**
     * Get groups of a variable
     * @param varId Id of the variable
     * @returns Array of group
     */
    getRowsByVariable(varId: number): Promise<GroupRow[]>;
    /**
     * Delete a group
     * @param row GroupRow
     */
    delete(row: GroupRow): Promise<boolean>;
    /**
     * Add new group
     * @param area GroupRow to add
     * @returns GroupRow added
     */
    add(row: GroupRow): Promise<GroupRow>;
    /**
     * Update a group
     * @param group
     * @returns Array of GroupRow updated
     */
    update(row: GroupRow): Promise<GroupRow[]>;
    protected constructRow(args: Partial<GroupRow>): GroupRow;
    protected constructState(args: Partial<GroupState>): GroupState;
    protected getState(id: number): Promise<GroupState>;
}
