"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GroupManager = void 0;
const helper_1 = require("../common/helper");
const treeHelper_1 = require("../common/treeHelper");
const groupRow_1 = require("../data/groupRow");
const groupState_1 = require("../data/groupState");
const treeRowManager_1 = require("./base/treeRowManager");
class GroupManager extends treeRowManager_1.TreeRowManager {
    constructor(http, odata) {
        super(http, odata, { letter: 'G' });
    }
    /**
     * Request the full list of areas row.
     * This request includes excluded entities
     * @returns Array of GroupRow
     * @remark Request value to the server
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.get('AppVisionDataService.svc/Groups');
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value.map(p => new groupRow_1.GroupRow(p));
        });
    }
    /**
     * Get groups of a variable
     * @param varId Id of the variable
     * @returns Array of group
     */
    getRowsByVariable(varId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.get("AppVisionDataService.svc/Variables(" + varId + ")/Groups");
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value.map(g => new groupRow_1.GroupRow(g));
        });
    }
    /**
     * Delete a group
     * @param row GroupRow
     */
    delete(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(row);
            const resp = yield this.http.post('AppVisionService.svc/DeleteGroup', JSON.stringify(clone));
            const json = yield resp.json();
            return json;
        });
    }
    /**
     * Add new group
     * @param area GroupRow to add
     * @returns GroupRow added
     */
    add(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(row);
            const json = yield this.http.postAsJson('AppVisionService.svc/GroupManager/Add', JSON.stringify(clone));
            return new groupRow_1.GroupRow(json);
        });
    }
    /**
     * Update a group
     * @param group
     * @returns Array of GroupRow updated
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(row);
            const json = yield this.http.postAsJson('AppVisionService.svc/GroupManager/Update', JSON.stringify(clone));
            return json.map(r => new groupRow_1.GroupRow(r));
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            let resp = yield this.http.get('AppVisionService.svc/GetGroupStates');
            let json = yield resp.json();
            this.states = new Map();
            for (const s of json)
                this.states.set(s.Name, new groupState_1.GroupState(s));
            resp = yield this.http.get('AppVisionService.svc/GetGroups');
            json = yield resp.json();
            this.rowsByName = new Map();
            this.rowsById = new Map();
            for (const r of json) {
                const row = new groupRow_1.GroupRow(r);
                const state = this.states.get(r.Name);
                if (state) { // liaison row <-> state
                    row.State = state;
                }
                this.rowsByName.set(r.Name, row);
                this.rowsById.set(r.Id, row);
            }
            // liaison .parent .items
            treeHelper_1.TreeHelper.buildTreeRow([...this.rowsByName.values()]);
        });
    }
    constructRow(args) {
        return new groupRow_1.GroupRow(args);
    }
    constructState(args) {
        return new groupState_1.GroupState(args);
    }
    getState(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const resp = yield this.http.get('AppVisionService.svc/GetGroupStateById?id=' + id);
                const json = yield resp.json();
                return new groupState_1.GroupState(json);
            }
            catch (e) {
                return null;
            }
        });
    }
}
exports.GroupManager = GroupManager;
