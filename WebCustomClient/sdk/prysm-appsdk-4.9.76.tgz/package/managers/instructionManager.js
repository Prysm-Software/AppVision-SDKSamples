"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstructionManager = void 0;
const instructionRow_1 = require("../data/instructionRow");
class InstructionManager {
    constructor(http, odata) {
        this.http = http;
        this.odata = odata;
    }
    /**
     * Get instructions from variable row
     * @param id Id of the variable
     * @returns Array of instructions
     */
    getByVariableId(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.getAsJson('AppVisionDataService.svc/Variables(' + id + ')/Instructions');
            return resp.value.map(o => new instructionRow_1.InstructionRow(o));
        });
    }
    /**
     * Get all instructionRow from the server
     * @returns Array of instructions
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.getAsJson('AppVisionService.svc/GetInstructions');
            return resp.map(o => new instructionRow_1.InstructionRow(o));
        });
    }
    /**
     * Add a new InstructionRow
     * @param obj InstructionRow to add
     * @returns InstructionRow created
     */
    add(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.postAsJson('AppVisionService.svc/InstructionManager/Add', JSON.stringify(row));
            return new instructionRow_1.InstructionRow(json);
        });
    }
    /**
     * Update an InstructionRow
     * @param obj InstructionRow to update
     * @returns InstructionRow updated
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.postAsJson('AppVisionService.svc/InstructionManager/Update', JSON.stringify(row));
            return new instructionRow_1.InstructionRow(json);
        });
    }
    /**
     * Delete an instruction
     * @param id InstructionRow Id
     */
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('AppVisionService.svc/DeleteInstruction', JSON.stringify({ Id: id }));
            if (resp === false)
                throw new Error("Failed to delete");
        });
    }
}
exports.InstructionManager = InstructionManager;
