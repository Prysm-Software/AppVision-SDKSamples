"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VideoManager = void 0;
const camera_1 = require("../data/camera");
class VideoManager {
    constructor(http, variableManager) {
        this.http = http;
        this.variableManager = variableManager;
    }
    createLiveCamera(cameraName, stream) {
        if (!cameraName.startsWith('$V.'))
            cameraName = '$V.' + cameraName;
        const cameraRow = this.variableManager.getRowByName(cameraName);
        if (!cameraRow)
            return null;
        return new camera_1.Camera(this.http, { row: cameraRow, stream });
    }
    createPlaybackCamera(cameraName, dateStart) {
        if (!cameraName.startsWith('$V.'))
            cameraName = '$V.' + cameraName;
        const cameraRow = this.variableManager.getRowByName(cameraName);
        if (!cameraRow)
            return null;
        return new camera_1.Camera(this.http, { row: cameraRow, start: dateStart, speed: 1 });
    }
}
exports.VideoManager = VideoManager;
