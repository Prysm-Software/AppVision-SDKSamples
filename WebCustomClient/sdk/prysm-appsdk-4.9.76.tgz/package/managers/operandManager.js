"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperandManager = void 0;
class OperandManager {
    constructor(variableManager, areaManager, alarmManager, groupManager, userManager, protocolManager, server, optionManager) {
        // pour utiliser la syntaxe $X.prop en lecture/écriture
        this.op = new Proxy(this, {
            get(target, property) { return target.read(property); },
            set(target, property, value) { target.write(property, value); return true; }
        });
        this.variableManager = variableManager;
        this.alarmManager = alarmManager;
        this.areaManager = areaManager;
        this.groupManager = groupManager;
        this.userManager = userManager;
        this.protocolManager = protocolManager;
        this.server = server;
        this.optionManager = optionManager;
    }
    write(operand, value) {
        if (!operand.startsWith('$V.'))
            throw new Error('Invalid operand');
        //todo on ne prend pas (encore) en compte l'affectation binaire .bn
        this.variableManager.set(operand.substring(3), value.toString());
    }
    read(operand) {
        if (operand.startsWith('$V.'))
            return this.readVariable(operand.substring(3));
        else if (operand.startsWith('$A.'))
            return this.readArea(operand.substring(3));
        else if (operand.startsWith('$G.'))
            return this.readGroup(operand.substring(3));
        else if (operand.startsWith('$U#'))
            return this.readUser(operand.substring(3));
        else if (operand.startsWith('$S#'))
            return this.readServer(operand.substring(3));
        else if (operand.startsWith('$P#'))
            return this.readProtocol(operand.substring(3));
        return operand;
    }
    readVariable(operand) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        let prop;
        let subProp;
        let bit = -1;
        // $V.var.b0
        const m = operand.match(/\.b[0-9]+$/);
        if (m) {
            operand = operand.slice(0, m.index);
            bit = parseInt(m[0].substring(2));
        }
        // $V.var#Prop
        const op = operand.split('#');
        if (op.length > 1) {
            operand = op[0];
            prop = op[1].split('.')[0];
            subProp = op[1].split('.')[1];
        }
        const row = this.variableManager.getRowByName(operand);
        if (!row)
            return null;
        switch (prop) {
            case 'Id':
                return row.Id;
            case 'Address':
                return row.FullAddress;
            case 'Name':
                return row.Name;
            case 'Desc':
                return row.FullDescription;
            case 'Parameters':
                return row.FullParameters;
            case 'Position':
                return row.Position;
            case 'Sound':
                return row.FullSound;
            case 'Symbol':
                return row.Symbol;
            case 'Synoptic':
                return row.FullSynoptic;
            case 'VideoLink':
                return row.FullVideoLink;
            case 'CustomField1':
                return row.CustomField1;
            case 'CustomField2':
                return row.CustomField2;
            case 'CustomField3':
                return row.CustomField3;
            case 'CustomField4':
                return row.CustomField4;
            case 'CustomField5':
                return row.CustomField5;
            case 'Alarm':
                return this.alarmManager.getAlarms().find(a => a.SourceId === row.Id) != null;
            case 'AlarmCount':
                return (_b = (_a = this.alarmManager.getAlarms().filter(a => a.SourceId === row.Id)) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0;
            case 'AlarmStatus':
                return (_c = this.alarmManager.getAlarms().find(a => a.SourceId === row.Id)) === null || _c === void 0 ? void 0 : _c.status;
            case 'AreaDesc':
                return (_d = this.areaManager.getRowById(row.AreaId)) === null || _d === void 0 ? void 0 : _d.FullDescription;
            case 'AreaName':
                return (_e = this.areaManager.getRowById(row.AreaId)) === null || _e === void 0 ? void 0 : _e.Name;
            case 'Date':
                return (_f = row.State) === null || _f === void 0 ? void 0 : _f.date.toLocaleString();
            case 'Info':
                return (_g = row.State) === null || _g === void 0 ? void 0 : _g.Info;
            case 'Instructions':
                return (_h = this.alarmManager.getAlarms().find(a => a.SourceId === row.Id)) === null || _h === void 0 ? void 0 : _h.Instructions;
            case 'IsAlarmMasked':
                return (_j = row.State) === null || _j === void 0 ? void 0 : _j.IsAlarmMasked;
            case 'IsLocked':
                return (_k = row.State) === null || _k === void 0 ? void 0 : _k.IsLocked;
            case 'MaxSeverity':
                {
                    const severities = this.alarmManager.getAlarms().filter(a => a.SourceId === row.Id).map(a => a.Severity);
                    return severities.length > 0 ? Math.max.apply(Math, severities) : 0;
                }
            case 'PreviousDate':
                return (_l = row.State) === null || _l === void 0 ? void 0 : _l.previousDate.toLocaleString();
            case 'PreviousValue':
                return (_m = row.State) === null || _m === void 0 ? void 0 : _m.PreviousValue;
            case 'Quality':
                return (_o = row.State) === null || _o === void 0 ? void 0 : _o.Quality;
            case 'Ack':
            case 'WaitAck':
                return this.alarmManager.getAlarms().find(a => a.SourceId === row.Id && a.WaitAcknowledge) ? true : false;
            case 'WaitEnd':
                return this.alarmManager.getAlarms().find(a => a.SourceId === row.Id && a.WaitEnd) ? true : false;
            case 'WaitReport':
                return this.alarmManager.getAlarms().find(a => a.SourceId === row.Id && a.WaitReport) ? true : false;
            case 'WaitProcess':
                return this.alarmManager.getAlarms().find(a => a.SourceId === row.Id && a.WaitProcess) ? true : false;
            case 'State':
                return (_p = row.State) === null || _p === void 0 ? void 0 : _p.valueDesc;
            case 'Server':
                return (_q = row.State) === null || _q === void 0 ? void 0 : _q.ServerName;
            case 'SParameters':
                {
                    const sParams = (_r = row.State) === null || _r === void 0 ? void 0 : _r.Parameters;
                    if ((sParams === null || sParams === void 0 ? void 0 : sParams.length) > 0) {
                        if (subProp) {
                            const sp = sParams.find(p => { var _a; return ((_a = p.Name) === null || _a === void 0 ? void 0 : _a.toLocaleLowerCase()) === subProp.toLocaleLowerCase(); });
                            if (sp) {
                                return sp.Value;
                            }
                            else {
                                return subProp + ' not found';
                            }
                        }
                        else {
                            return sParams.map(nv => nv.Name + '=' + nv.Value).join(', ');
                        }
                    }
                    return '';
                }
            case 'Photo':
                return (_s = row.State) === null || _s === void 0 ? void 0 : _s.photo;
            default:
                {
                    const value = row === null || row === void 0 ? void 0 : row.State.Value;
                    // si enum par bit
                    if (bit > -1)
                        return (parseInt(value) >> bit) & 1;
                    return value;
                }
        }
    }
    readArea(operand) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;
        let prop;
        // $A.var#Prop
        const op = operand.split('#');
        if (op.length > 1) {
            operand = op[0];
            prop = op[1];
        }
        const area = this.areaManager.getRowByName(operand);
        if (!area)
            return null;
        switch (prop) {
            case 'Id':
                return area.Id;
            case 'Name':
                return area.Name;
            case 'Desc':
                return area.FullDescription;
            case "Parameters":
                return area.FullParameters;
            case "Sound":
                return area.FullSound;
            case "Synoptic":
                return area.FullSynoptic;
            case 'Alarm':
                return (_a = area.State) === null || _a === void 0 ? void 0 : _a.isAlarm;
            case 'AlarmProcessing':
                return (_b = area.State) === null || _b === void 0 ? void 0 : _b.isAlarmProcessing;
            case 'AlarmWaiting':
                return (_c = area.State) === null || _c === void 0 ? void 0 : _c.isAlarmProcessWaiting;
            case 'AlarmClosed':
                return (_d = area.State) === null || _d === void 0 ? void 0 : _d.isAlarmClosed;
            case 'AlarmCount':
                return (_e = area.State) === null || _e === void 0 ? void 0 : _e.AlarmCount;
            case 'AlarmProcessingCount':
                return (_f = area.State) === null || _f === void 0 ? void 0 : _f.AlarmProcessingCount;
            case 'AlarmWaitingCount':
                return (_g = area.State) === null || _g === void 0 ? void 0 : _g.AlarmProcessWaitingCount;
            case 'AlarmClosedCount':
                return (_h = area.State) === null || _h === void 0 ? void 0 : _h.AlarmClosedCount;
            case 'LockedCount':
                return (_j = area.State) === null || _j === void 0 ? void 0 : _j.LockedCount;
            case 'MaskedCount':
                return (_k = area.State) === null || _k === void 0 ? void 0 : _k.MaskedCount;
            case 'MaxSeverity':
                return (_l = area.State) === null || _l === void 0 ? void 0 : _l.MaxSeverity;
            case 'OrValue':
                return (_m = area.State) === null || _m === void 0 ? void 0 : _m.OrValue;
            case 'AndValue':
                return (_o = area.State) === null || _o === void 0 ? void 0 : _o.AndValue;
            case 'Ack':
            case 'WaitAck':
                return (_p = area.State) === null || _p === void 0 ? void 0 : _p.isAlarmAcknowledgeWaiting;
            case 'WaitAckCount':
                return (_q = area.State) === null || _q === void 0 ? void 0 : _q.AlarmAcknowledgeWaitingCount;
            case "WaitEndCount":
                return (_r = area.State) === null || _r === void 0 ? void 0 : _r.WaitEndCount;
            case "WaitReport":
                return ((_s = area.State) === null || _s === void 0 ? void 0 : _s.WaitReportCount) > 0;
            case "WaitReportCount":
                return (_t = area.State) === null || _t === void 0 ? void 0 : _t.WaitReportCount;
            default:
                return "Unsupported prop: " + prop;
        }
    }
    readGroup(operand) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        let prop;
        // $A.var#Prop
        const op = operand.split('#');
        if (op.length > 1) {
            operand = op[0];
            prop = op[1];
        }
        const group = this.groupManager.getRowByName(operand);
        if (!group)
            return null;
        switch (prop) {
            case 'Id':
                return group.Id;
            case 'Name':
                return group.Name;
            case 'Desc':
                return group.FullDescription;
            case "Parameters":
                return group.FullParameters;
            case "Sound":
                return group.FullSound;
            case "Synoptic":
                return group.FullSynoptic;
            case 'Alarm':
                return (_a = group.State) === null || _a === void 0 ? void 0 : _a.isAlarm;
            case 'AlarmProcessing':
                return (_b = group.State) === null || _b === void 0 ? void 0 : _b.isAlarmProcessing;
            case 'AlarmWaiting':
                return (_c = group.State) === null || _c === void 0 ? void 0 : _c.isAlarmProcessWaiting;
            case 'AlarmClosed':
                return (_d = group.State) === null || _d === void 0 ? void 0 : _d.isAlarmClosed;
            case 'AlarmCount':
                return (_e = group.State) === null || _e === void 0 ? void 0 : _e.AlarmCount;
            case 'AlarmProcessingCount':
                return (_f = group.State) === null || _f === void 0 ? void 0 : _f.AlarmProcessingCount;
            case 'AlarmWaitingCount':
                return (_g = group.State) === null || _g === void 0 ? void 0 : _g.AlarmProcessWaitingCount;
            case 'AlarmClosedCount':
                return (_h = group.State) === null || _h === void 0 ? void 0 : _h.AlarmClosedCount;
            case 'LockedCount':
                return (_j = group.State) === null || _j === void 0 ? void 0 : _j.LockedCount;
            case 'MaskedCount':
                return (_k = group.State) === null || _k === void 0 ? void 0 : _k.MaskedCount;
            case 'MaxSeverity':
                return (_l = group.State) === null || _l === void 0 ? void 0 : _l.MaxSeverity;
            case 'OrValue':
                return (_m = group.State) === null || _m === void 0 ? void 0 : _m.OrValue;
            case 'AndValue':
                return (_o = group.State) === null || _o === void 0 ? void 0 : _o.AndValue;
            case 'Ack':
            case 'WaitAck':
                return (_p = group.State) === null || _p === void 0 ? void 0 : _p.isAlarmAcknowledgeWaiting;
            case 'WaitAckCount':
                return (_q = group.State) === null || _q === void 0 ? void 0 : _q.AlarmAcknowledgeWaitingCount;
            case "WaitReportCount":
                return (_r = group.State) === null || _r === void 0 ? void 0 : _r.WaitReportCount;
            case "WaitReport":
                return ((_s = group.State) === null || _s === void 0 ? void 0 : _s.WaitReportCount) > 0;
            default:
                return "Unsupported prop: " + prop;
        }
    }
    readUser(operand) {
        var _a, _b, _c, _d;
        const user = this.userManager.currentUser;
        if (!user)
            return null;
        if (operand.startsWith('Profile.')) {
            operand = operand.substring(8);
            if (user.profile.hasOwnProperty(operand))
                return user.profile[operand];
            console.warn(`$U#Profile.${operand} is not supported`);
            return null;
        }
        else if (operand.startsWith('Rights.')) {
            operand = operand.substring(7);
            return user.checkRight(operand);
        }
        else if (operand.startsWith('Areas.')) {
            operand = operand.substring(6);
            return (_b = (_a = user.profile) === null || _a === void 0 ? void 0 : _a.checkArea(operand)) !== null && _b !== void 0 ? _b : false;
        }
        else if (operand.startsWith('Groups.')) {
            operand = operand.substring(7);
            return (_d = (_c = user.profile) === null || _c === void 0 ? void 0 : _c.checkGroup(operand)) !== null && _d !== void 0 ? _d : false;
        }
        else if (operand.startsWith('Parameters.')) {
            operand = operand.substring(11);
            return operand == '' ? user.Parameters : user.getParameter(operand);
        }
        if (user.hasOwnProperty(operand))
            return user[operand];
        switch (operand) {
            case 'Fullname':
                return user.fullName;
            case 'Options':
                return user.options;
            case 'Name':
                return user.Name;
            case 'PriorityLevel':
                return user.profile.PriorityLevel;
            default:
                console.warn(`$U#${operand} is not supported`);
                return null;
        }
    }
    readServer(operand) {
        const serverState = this.server.state;
        switch (operand) {
            case 'CpuCounter':
                return serverState.CpuCounter;
            case 'RamAvailable':
                return serverState.RamAvailable;
            case 'Version':
                return serverState.Version;
            case "Debug":
                return serverState.DebugLevel;
            case "Project":
                return this.optionManager.get('App.Main.ProjectDescription');
            case "Hostname":
                return serverState.ServerName;
            case 'RedundantId':
                return serverState.RedundantId;
            case 'IsMirror':
                return serverState.IsMirror;
            case 'State':
                return serverState.State;
            default:
                return "Unsupported option: " + operand;
        }
    }
    readProtocol(operand) {
        var ss = operand.split('#');
        if (ss.length != 2) {
            console.warn(`Operand Incorrect : $P.${operand}`);
            return null;
        }
        var p = this.protocolManager.getRows().find(x => x.Name === ss[0]);
        if (p == null) {
            console.warn(`Unknown protocol : $P.${operand}`);
            return null;
        }
        var st = this.protocolManager.getStates().find(x => x.Name === ss[0]);
        if (st == null) {
            console.warn(`Unknown protocol state : $P.${operand}`);
            return null;
        }
        switch (ss[1]) {
            case "State": return st.Status;
            case "Desc": return p.Description;
            case "Id": return p.Id;
            case "Name": return p.Name;
        }
        console.warn(`Operand Incorrect : $P.${operand}`);
        return null;
    }
}
exports.OperandManager = OperandManager;
