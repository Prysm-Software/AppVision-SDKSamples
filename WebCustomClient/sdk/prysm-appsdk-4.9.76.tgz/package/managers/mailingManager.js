"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailingManager = void 0;
const helper_1 = require("../common/helper");
const mailingRow_1 = require("../data/mailingRow");
class MailingManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all mailings
     * @returns Array of MailingRow
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get("AppVisionDataService.svc/Mailings?$expand=FilterTimetable");
            const json = yield resp.json();
            return json.value.map(h => new mailingRow_1.MailingRow(h));
        });
    }
    /**
     * Add new mailing
     * @param row Mailing to add
     * @returns MailingRow created
     */
    add(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const odataRow = helper_1.Helper.lightCloneObject(row);
            odataRow["odata.type"] = "Prysm.AppVision.Data.MailingRow";
            const resp = yield this.http.post("AppVisionDataService.svc/Mailings", JSON.stringify(odataRow), 'POST');
            const json = yield resp.json();
            return new mailingRow_1.MailingRow(json);
        });
    }
    /**
     * Delete mailing
     * @param id Id to delete
     */
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.post('AppVisionDataService.svc/Mailings(' + id + ')', null, 'DELETE');
        });
    }
    /**
     * Update a mailing
     * @param row Row to update
     * @returns
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const odataRow = helper_1.Helper.lightCloneObject(row);
            odataRow["odata.type"] = "Prysm.AppVision.Data.MailingRow";
            yield this.http.post("AppVisionDataService.svc/Mailings(" + row.Id + ")", JSON.stringify(odataRow), 'MERGE');
        });
    }
}
exports.MailingManager = MailingManager;
