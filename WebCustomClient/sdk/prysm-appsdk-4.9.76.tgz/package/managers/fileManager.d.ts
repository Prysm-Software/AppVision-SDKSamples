import { FileInfoRow, FileInfoType } from "../data/fileInfoRow";
import { HttpService } from "../services/httpService";
import { Subject } from "rxjs";
import { TreeItem } from "../data/treeItem";
export declare class FileManager {
    private http;
    private fileInfos;
    rowsUpdated: Subject<FileInfoRow[]>;
    constructor(http: HttpService);
    /**
     * Build file tree
     * @param types FileType filter (FileType)
     * @returns Tree of FileInfoRow
     */
    getRowsTree(...types: FileInfoType[]): FileInfoRow[];
    /**
     * Build file tree with filter
     * @param types FileType filter (FileType)
     * @returns Tree of FileInfoRow
     */
    getRowsTreeByFilter(filter: (f: FileInfoRow) => boolean): FileInfoRow[];
    /**
     * Get all files (flat)
     * @param types FileType filter (FileType)
     * @returns Array of FileInfoRow
     * @remark Get values from cache
     */
    getRows(...types: FileInfoType[]): FileInfoRow[];
    /**
     * Download file from server as string
     * @param url Url of the file
     * @returns File content as string
     *
     * @example
     * server.fileManager.getFile('Config/Client/MySuperFile.txt')
     */
    getFile(url: string): Promise<string>;
    /**
     * Delete a file on the server
     * @param url Url of the file
     *
     * @example
     * server.fileManager.getFile('Config/Client/MySuperFile.txt')
     */
    deleteFile(url: string): Promise<void>;
    /**
     * Update a file on the server
     * @param filePath Url of the file
     * @param file File content as Blob
     * @param header Http headers of the request
     */
    putFile(filePath: string, file: Blob, header?: HeadersInit): Promise<void>;
    /**
     * Request the server to get file names on disk
     * @param pattern search pattern (ex: *.png;*.jpg)
     * @returns Flat array of string (Flat)
     */
    getFileNames(pattern: string): Promise<string[]>;
    /**
     * Request the server to get file names on disk and return result as tree
     * @param pattern search pattern (ex: *.png;*.jpg), Default '*'
     * @returns Tree array of TreeRow
     */
    getFileTree(pattern?: string): Promise<TreeItem[]>;
    /**
     * Get file url inside the config folder
     * @param filePath
     * @returns file path
     * @deprecated Use buildConfigFileUrl
     */
    getConfigFileUrl(filePath: string): string;
    /**
     * Get file url inside the Resources folder
     * @param filePath
     * @returns file path
     * @deprecated Use buildFileUrl
     */
    getResourceFileUrl(filePath: string): string;
    /**
     * Get file url from Config/Param/Client foler
     * @param filePath string
     * @returns file path
     * @deprecated Use buildFileUrl
     */
    getFileUrl(filePath: string): string;
    /**
     * Get file url from Config/Param/AppControl/Photos/ folder
     * @param filePath
     * @returns File path
     * @deprecated Use buildAppControlPhotoUrl
     */
    getAppControlPhotoUrl(filePath: string): string;
    /**
     * Build file url from Config/Param/AppControl/Photos/ folder
     * @param filePath
     * @returns
     */
    buildAppControlPhotoUrl(filePath: string): string;
    /**
    * Build file url inside the config folder
    * @param filePath
    * @returns
    */
    buildConfigFileUrl(filePath: string): string;
    /**
     * Build file url inside the Resources folder
     * @param filePath
     * @returns
     */
    buildResourceFileUrl(filePath: string): string;
    /**
     * Build file url from Config/Param/Client foler
     * @param filePath
     * @returns
     */
    buildFileUrl(filePath: string): string;
    /**
     * Get the list of all log files
     * @returns String array of all files with their path
     */
    getLogFilesList(): Promise<string[]>;
}
