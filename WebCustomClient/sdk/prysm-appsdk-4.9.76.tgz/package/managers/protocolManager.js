"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProtocolManager = void 0;
const rxjs_1 = require("rxjs");
const helper_1 = require("../common/helper");
const protocolRow_1 = require("../data/protocolRow");
const protocolState_1 = require("../data/protocolState");
class ProtocolManager {
    constructor(http, odata) {
        this.http = http;
        this.odata = odata;
        this.statesChanged = new rxjs_1.Subject();
    }
    /**
     * Return protocol rows from cache
     * @returns Array of ProtocolRow
     */
    getRows() {
        return [...this.rows.values()].map(p => new protocolRow_1.ProtocolRow(p));
    }
    /**
     * Return protocol state from cache
     * @returns Array of ProtocolState
     */
    getStates() {
        return [...this.states.values()].map(p => new protocolState_1.ProtocolState(p));
    }
    /**
     * Start a protocol by name
     * @param protocolName Protocol name
     */
    start(protocolName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get('AppVisionService.svc/StartProtocol?protocolName=' + protocolName);
        });
    }
    /**
     * Stop a protocol by name
     * @param protocolName
     */
    stop(protocolName) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get('AppVisionService.svc/StopProtocol?protocolName=' + protocolName);
        });
    }
    /**
     * Send a download request to protocols
     * @param rows Array of protocol names
     * @param parameters Parameters
     */
    sendDownload(rows, parameters) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get('AppVisionService.svc/SendDownloadToProtocol?varNames=' + rows.join() + '&parameter=' + parameters);
        });
    }
    /**
     * Request the full list of protocols row.
     * This request includes excluded entities
     * @returns Array of GroupRow
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.get('AppVisionDataService.svc/Protocols');
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value.map(p => new protocolRow_1.ProtocolRow(p));
        });
    }
    /**
     * Get a protocol by his name
     * @returns ProtocolRow
     */
    getByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.odata.get('AppVisionDataService.svc/Protocols');
            if (resp.status === 204)
                return null;
            const json = yield resp.json();
            return json.value.find(p => p.Name === name);
        });
    }
    /**
    * Delete a protocol by it's Id
    * @param id
    */
    delete(id) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.odata.post('AppVisionDataService.svc/Protocols(' + id + ')', null, 'DELETE');
        });
    }
    /**
     * Add new protocol
     * @param area ProtocolRow to add
     * @returns ProtocolRow added
     */
    add(obj) {
        return __awaiter(this, void 0, void 0, function* () {
            const odataRow = helper_1.Helper.lightCloneObject(obj);
            odataRow["odata.type"] = "Prysm.AppVision.Data.ProtocolRow";
            const resp = yield this.odata.post('AppVisionDataService.svc/Protocols', JSON.stringify(odataRow));
            const json = yield resp.json();
            return new protocolRow_1.ProtocolRow(json);
        });
    }
    /**
     * Update a protocol
     * @param protocol
     */
    update(p) {
        return __awaiter(this, void 0, void 0, function* () {
            const odataRow = helper_1.Helper.lightCloneObject(p);
            odataRow["odata.type"] = "Prysm.AppVision.Data.ProtocolRow";
            yield this.odata.post('AppVisionDataService.svc/Protocols(' + p.Id + ')', JSON.stringify(odataRow), 'MERGE');
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            let resp = yield this.http.get('AppVisionService.svc/GetProtocolStates');
            let json = yield resp.json();
            this.states = new Map();
            for (const s of json)
                this.states.set(s.Name, new protocolState_1.ProtocolState(s));
            resp = yield this.http.get('AppVisionService.svc/GetProtocols');
            json = yield resp.json();
            this.rows = new Map();
            for (const r of json) {
                const row = new protocolRow_1.ProtocolRow(r);
                const state = this.states.get(r.Name);
                if (state != null) { // liaison row <-> state
                    state.Row = row;
                    row.State = state;
                }
                this.rows.set(r.Name, row);
            }
        });
    }
    /** @internal */
    updateStatesInternal(states) {
        const updatedStates = [];
        states.forEach(state => {
            const row = this.rows.get(state.Name);
            if (row) {
                row.State = state;
                state.Row = row;
                this.states.set(state.Name, state);
                updatedStates.push(state);
            }
        });
        if (updatedStates.length > 0) {
            this.statesChanged.next(updatedStates);
        }
    }
}
exports.ProtocolManager = ProtocolManager;
