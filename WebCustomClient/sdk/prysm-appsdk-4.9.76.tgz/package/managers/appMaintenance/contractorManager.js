"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContractorManager = void 0;
const contractor_1 = require("../../data/appMaintenance/contractor");
class ContractorManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all Contractors
     * @returns Array of Contractors
     */
    getContractors() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Contractors()?$orderby=Name');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value.map(d => new contractor_1.Contractor(d));
        });
    }
    /**
        * Get a contractor by name
        * @param name Contractor name
        * @returns Contractor
        */
    getContractorByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/Contractors?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
    * Get a Contractor by id
    * @param id Contractor id
    * @returns Contractor
    */
    getContractorById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Contractors(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
    * Post a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    add(contractor) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/Contractors', JSON.stringify(contractor));
            return (yield resp.json());
        });
    }
    /**
    * Delete a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    delete(contractorId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Contractors(' + contractorId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    update(contractor) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Contractors(' + contractor.Id + ')', JSON.stringify(contractor), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.ContractorManager = ContractorManager;
