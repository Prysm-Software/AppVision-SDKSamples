import { Installation } from '../../data/appMaintenance/installation';
import { HttpService } from '../../services/httpService';
export declare class InstallationManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all Installations
     * @returns Array of Installations
     */
    getInstallations(): Promise<Installation[]>;
    /**
    * Get a Installation by name
    * @param name Installation name
    * @returns Installation
    */
    getInstallationByName(name: string): Promise<Installation>;
    /**
        * Get a Installation by id
        * @param id Installation id
        * @returns Installation
        */
    getInstallationById(id: number): Promise<Installation>;
    /**
 * Post a Installation
 * @param installation Installation
 * @returns Installation
 */
    add(installation: Installation): Promise<Installation>;
    /**
    * Delete a Installation
    * @param installationId InstallationId
    * @returns Bolean
    */
    delete(installationId: number): Promise<boolean>;
    /**
    * Update a Installation
    * @param installation Installation
    * @returns Installation
    */
    update(installation: Installation): Promise<boolean>;
}
