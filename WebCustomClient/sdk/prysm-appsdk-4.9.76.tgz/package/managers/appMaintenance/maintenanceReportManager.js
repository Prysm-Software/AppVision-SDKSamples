"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaintenanceReportManager = void 0;
class MaintenanceReportManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all MaintenanceReports
     * @returns Array of MaintenanceReports
     */
    getMaintenanceReports() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/MaintenanceReports()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new MaintenanceReport(d));
        });
    }
    /**
    * Get a MaintenanceReport by name
    * @param name MaintenanceReport name
    * @returns MaintenanceReport
    */
    getMaintenanceReportByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/MaintenanceReports?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
        * Get a MaintenanceReport by id
        * @param id MaintenanceReport id
        * @returns MaintenanceReport
        */
    getMaintenanceReportById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/MaintenanceReports(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a MaintenanceReport
 * @param maintenanceReport MaintenanceReport
 * @returns MaintenanceReport
 */
    add(maintenanceReport) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/MaintenanceReports', JSON.stringify(maintenanceReport));
            return resp;
        });
    }
    /**
    * Delete a MaintenanceReport
    * @param maintenanceReportId MaintenanceReportId
    * @returns Bolean
    */
    delete(maintenanceReportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/MaintenanceReports(' + maintenanceReportId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a MaintenanceReport
    * @param maintenanceReport MaintenanceReport
    * @returns MaintenanceReport
    */
    update(maintenanceReport) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/MaintenanceReports(' + maintenanceReport.Id + ')', JSON.stringify(maintenanceReport), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.MaintenanceReportManager = MaintenanceReportManager;
