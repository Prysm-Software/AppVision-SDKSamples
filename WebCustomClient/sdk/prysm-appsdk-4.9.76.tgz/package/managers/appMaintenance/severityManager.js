"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SeverityManager = void 0;
class SeverityManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all Severities
     * @returns Array of Severities
     */
    getSeverities() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Severities()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new Severity(d));
        });
    }
    /**
    * Get a Severity by name
    * @param name Severity name
    * @returns Severity
    */
    getSeverityByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/Severities?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
        * Get a Severity by id
        * @param id Severity id
        * @returns Severity
        */
    getSeverityById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Severities(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a Severity
 * @param Severity Severity
 * @returns Severity
 */
    add(severity) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/Severities', JSON.stringify(severity));
            return (yield resp.json());
        });
    }
    /**
    * Delete a Severity
    * @param Severity Severity
    * @returns Severity
    */
    delete(severityId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Severities(' + severityId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a Severity
    * @param severity Severity
    * @returns Severity
    */
    update(severity) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Severities(' + severity.Id + ')', JSON.stringify(severity), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.SeverityManager = SeverityManager;
