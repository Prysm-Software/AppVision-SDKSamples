"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplateRowManager = void 0;
class TemplateRowManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all TemplateRows
     * @returns Array of TemplateRows
     */
    getTemplateRows() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/TemplateRows()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new TemplateRow(d));
        });
    }
    /**
    * Get a TemplateRow by name
    * @param name TemplateRow name
    * @returns TemplateRow
    */
    getTemplateRowByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/TemplateRows?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all TemplateRowReports by filter
 * @returns Array of TemplateRowReports
 */
    getTemplateRowsByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/TemplateRows?$orderby=RowIndex&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new TemplateRowReport(d));
        });
    }
    /**
        * Get a TemplateRow by id
        * @param id TemplateRow id
        * @returns TemplateRow
        */
    getTemplateRowById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/TemplateRows(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a TemplateRow
 * @param TemplateRow TemplateRow
 * @returns TemplateRow
 */
    add(TemplateRow) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/TemplateRows', JSON.stringify(TemplateRow));
            return resp;
        });
    }
    /**
    * Delete a TemplateRow
    * @param TemplateRowId TemplateRowId
    * @returns Bolean
    */
    delete(TemplateRowId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/TemplateRows(' + TemplateRowId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a TemplateRow
    * @param TemplateRow TemplateRow
    * @returns TemplateRow
    */
    update(TemplateRow) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/TemplateRows(' + TemplateRow.RowId + ')', JSON.stringify(TemplateRow), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.TemplateRowManager = TemplateRowManager;
