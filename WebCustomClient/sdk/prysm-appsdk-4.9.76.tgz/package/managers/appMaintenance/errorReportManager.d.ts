import { ErrorReport, ErrorReportModel } from '../../data/appMaintenance/errorReport';
import { HttpService } from '../../services/httpService';
export declare class ErrorReportManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all ErrorReports
     * @returns Array of ErrorReports
     */
    getErrorReports(): Promise<ErrorReport[]>;
    /**
    * Get a ErrorReport by name
    * @param name ErrorReport name
    * @returns ErrorReport
    */
    getErrorReportByName(name: string): Promise<ErrorReport>;
    /**
        * Get a ErrorReport by id
        * @param id ErrorReport id
        * @returns ErrorReport
        */
    getErrorReportById(id: number): Promise<ErrorReport>;
    /**
 * Get all ErrorReports by filter
 * @returns Array of ErrorReports
 */
    getErrorReportsByFilter(filter: string, value: string): Promise<ErrorReport[]>;
    /**
 * Post a ErrorReport
 * @param errorReport ErrorReport
 * @returns ErrorReport
 */
    add(errorReport: ErrorReport, errorReportId?: number): Promise<ErrorReport>;
    /**
    * Delete a ErrorReport
    * @param errorReportId ErrorReportId
    * @returns Bolean
    */
    delete(errorReportId: number): Promise<boolean>;
    /**
    * Update a ErrorReport
    * @param errorReport ErrorReport
    * @returns ErrorReport
    */
    update(errorReport: ErrorReport): Promise<boolean>;
    assignErrorReportModel(errorReport: ErrorReport): ErrorReportModel;
}
