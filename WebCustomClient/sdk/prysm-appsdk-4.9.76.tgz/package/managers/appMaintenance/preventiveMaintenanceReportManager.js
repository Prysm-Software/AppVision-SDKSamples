"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreventiveMaintenanceReportManager = void 0;
class PreventiveMaintenanceReportManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all PrevMaintReports
     * @returns Array of PrevMaintReport
     */
    getPreventiveMaintenanceReports() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/PrevMaintReports()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new Battery(d));
        });
    }
    /**
    * Get a PrevMaintReport by name
    * @param name PrevMaintReport name
    * @returns PrevMaintReport
    */
    getPreventiveMaintenanceReportByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/PrevMaintReports?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all PrevMaintReports by filter
 * @returns Array of PrevMaintReports
 */
    getPreventiveMaintenanceReportsByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/PrevMaintReports?$orderby=Id&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
        * Get a PrevMaintReport by id
        * @param id PrevMaintReport id
        * @returns PrevMaintReport
        */
    getPreventiveMaintenanceReportById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/PrevMaintReports(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a PrevMaintReport
 * @param preventiveMaintenance PrevMaintReport
 * @returns PrevMaintReport
 */
    add(preventiveMaintenance) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/PrevMaintReports', JSON.stringify(preventiveMaintenance));
            return resp;
        });
    }
    /**
    * Delete a PrevMaintReport
    * @param batteryId PreventiveMaintenanceId
    * @returns Boolean
    */
    delete(preventiveMaintenanceId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/PrevMaintReports(' + preventiveMaintenanceId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a PrevMaintReport
    * @param preventiveMaintenance PrevMaintReport
    * @returns PrevMaintReport
    */
    update(preventiveMaintenance) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/PrevMaintReports(' + preventiveMaintenance.Id + ')', JSON.stringify(preventiveMaintenance), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.PreventiveMaintenanceReportManager = PreventiveMaintenanceReportManager;
