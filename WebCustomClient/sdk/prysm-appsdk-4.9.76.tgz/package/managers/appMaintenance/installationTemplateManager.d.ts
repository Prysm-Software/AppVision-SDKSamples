import { InstallationTemplate } from '../../data/appMaintenance/installationTemplate';
import { HttpService } from '../../services/httpService';
export declare class InstallationTemplateManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all InstallationTemplates
     * @returns Array of InstallationTemplates
     */
    getInstallationTemplates(): Promise<InstallationTemplate[]>;
    /**
    * Get a InstallationTemplate by name
    * @param name InstallationTemplate name
    * @returns InstallationTemplate
    */
    getInstallationTemplateByName(name: string): Promise<InstallationTemplate>;
    /**
 * Get all InstallationTemplateReports by filter
 * @returns Array of InstallationTemplateReports
 */
    getInstallationTemplatesByFilter(filter: string, value: string): Promise<InstallationTemplate[]>;
    /**
        * Get a InstallationTemplate by id
        * @param id InstallationTemplate id
        * @returns InstallationTemplate
        */
    getInstallationTemplateById(id: number): Promise<InstallationTemplate>;
    /**
 * Post a InstallationTemplate
 * @param InstallationTemplate InstallationTemplate
 * @returns InstallationTemplate
 */
    add(installationTemplate: InstallationTemplate): Promise<InstallationTemplate>;
    /**
    * Delete a InstallationTemplate
    * @param InstallationTemplateId InstallationTemplateId
    * @returns Bolean
    */
    delete(installationTemplateId: number): Promise<boolean>;
    /**
    * Update a InstallationTemplate
    * @param InstallationTemplate InstallationTemplate
    * @returns InstallationTemplate
    */
    update(installationTemplate: InstallationTemplate): Promise<boolean>;
}
