"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatteryManager = void 0;
class BatteryManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all Batteries
     * @returns Array of Batteries
     */
    getBatteries() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Batteries()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new Battery(d));
        });
    }
    /**
    * Get a Battery by name
    * @param name Battery name
    * @returns Battery
    */
    getBatteryByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/Batteries?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all BatteryReports by filter
 * @returns Array of BatteryReports
 */
    getBatteriesByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/Batteries?$orderby=Id&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
        * Get a Battery by id
        * @param id Battery id
        * @returns Battery
        */
    getBatteryById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Batteries(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a Battery
 * @param battery Battery
 * @returns Battery
 */
    add(battery) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/Batteries', JSON.stringify(battery));
            return (yield resp.json());
        });
    }
    /**
    * Delete a Battery
    * @param batteryId BatteryId
    * @returns Bolean
    */
    delete(batteryId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Batteries(' + batteryId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a Battery
    * @param battery Battery
    * @returns Battery
    */
    update(battery) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Batteries(' + battery.Id + ')', JSON.stringify(battery), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.BatteryManager = BatteryManager;
