import { MaintenanceReportRow } from '../../data/appMaintenance/maintenanceReportRow';
import { HttpService } from '../../services/httpService';
export declare class MaintenanceReportRowManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all MaintenanceReportRows
     * @returns Array of MaintenanceReportRows
     */
    getMaintenanceReportRows(): Promise<MaintenanceReportRow[]>;
    /**
    * Get a MaintenanceReportRow by name
    * @param name MaintenanceReportRow name
    * @returns MaintenanceReportRow
    */
    getMaintenanceReportRowByName(name: string): Promise<MaintenanceReportRow>;
    /**
 * Get all MaintenanceReportRowReports by filter
 * @returns Array of MaintenanceReportRowReports
 */
    getMaintenanceReportRowsByFilter(filter: string, value: string): Promise<MaintenanceReportRow[]>;
    /**
        * Get a MaintenanceReportRow by id
        * @param id MaintenanceReportRow id
        * @returns MaintenanceReportRow
        */
    getMaintenanceReportRowById(id: number): Promise<MaintenanceReportRow>;
    /**
 * Post a MaintenanceReportRow
 * @param MaintenanceReportRow MaintenanceReportRow
 * @returns MaintenanceReportRow
 */
    add(maintenanceReportRow: MaintenanceReportRow): Promise<MaintenanceReportRow>;
    /**
    * Delete a MaintenanceReportRow
    * @param MaintenanceReportRowId MaintenanceReportRowId
    * @returns Bolean
    */
    delete(maintenanceReportRowId: number): Promise<boolean>;
    /**
    * Update a MaintenanceReportRow
    * @param MaintenanceReportRow MaintenanceReportRow
    * @returns MaintenanceReportRow
    */
    update(maintenanceReportRow: MaintenanceReportRow): Promise<boolean>;
}
