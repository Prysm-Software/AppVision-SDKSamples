import { PrevMaintReport } from '../../data/appMaintenance/prevMaintReport';
import { HttpService } from '../../services/httpService';
export declare class PreventiveMaintenanceReportManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all PrevMaintReports
     * @returns Array of PrevMaintReport
     */
    getPreventiveMaintenanceReports(): Promise<PrevMaintReport[]>;
    /**
    * Get a PrevMaintReport by name
    * @param name PrevMaintReport name
    * @returns PrevMaintReport
    */
    getPreventiveMaintenanceReportByName(name: string): Promise<PrevMaintReport>;
    /**
 * Get all PrevMaintReports by filter
 * @returns Array of PrevMaintReports
 */
    getPreventiveMaintenanceReportsByFilter(filter: string, value: string): Promise<PrevMaintReport[]>;
    /**
        * Get a PrevMaintReport by id
        * @param id PrevMaintReport id
        * @returns PrevMaintReport
        */
    getPreventiveMaintenanceReportById(id: number): Promise<PrevMaintReport>;
    /**
 * Post a PrevMaintReport
 * @param preventiveMaintenance PrevMaintReport
 * @returns PrevMaintReport
 */
    add(preventiveMaintenance: PrevMaintReport): Promise<PrevMaintReport>;
    /**
    * Delete a PrevMaintReport
    * @param batteryId PreventiveMaintenanceId
    * @returns Boolean
    */
    delete(preventiveMaintenanceId: number): Promise<boolean>;
    /**
    * Update a PrevMaintReport
    * @param preventiveMaintenance PrevMaintReport
    * @returns PrevMaintReport
    */
    update(preventiveMaintenance: PrevMaintReport): Promise<boolean>;
}
