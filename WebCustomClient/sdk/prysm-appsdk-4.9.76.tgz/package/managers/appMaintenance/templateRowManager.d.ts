import { TemplateRow } from '../../data/appMaintenance/templateRow';
import { HttpService } from '../../services/httpService';
export declare class TemplateRowManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all TemplateRows
     * @returns Array of TemplateRows
     */
    getTemplateRows(): Promise<TemplateRow[]>;
    /**
    * Get a TemplateRow by name
    * @param name TemplateRow name
    * @returns TemplateRow
    */
    getTemplateRowByName(name: string): Promise<TemplateRow>;
    /**
 * Get all TemplateRowReports by filter
 * @returns Array of TemplateRowReports
 */
    getTemplateRowsByFilter(filter: string, value: string): Promise<TemplateRow[]>;
    /**
        * Get a TemplateRow by id
        * @param id TemplateRow id
        * @returns TemplateRow
        */
    getTemplateRowById(id: number): Promise<TemplateRow>;
    /**
 * Post a TemplateRow
 * @param TemplateRow TemplateRow
 * @returns TemplateRow
 */
    add(TemplateRow: TemplateRow): Promise<TemplateRow>;
    /**
    * Delete a TemplateRow
    * @param TemplateRowId TemplateRowId
    * @returns Bolean
    */
    delete(TemplateRowId: number): Promise<boolean>;
    /**
    * Update a TemplateRow
    * @param TemplateRow TemplateRow
    * @returns TemplateRow
    */
    update(TemplateRow: TemplateRow): Promise<boolean>;
}
