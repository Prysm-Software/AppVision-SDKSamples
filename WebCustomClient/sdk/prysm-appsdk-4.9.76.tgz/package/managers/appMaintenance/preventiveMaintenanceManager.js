"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PreventiveMaintenanceManager = void 0;
class PreventiveMaintenanceManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all PreventiveMaintenances
     * @returns Array of PreventiveMaintenances
     */
    getPreventiveMaintenances() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/PreventiveMaintenances()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new Battery(d));
        });
    }
    /**
    * Get a PreventiveMaintenance by name
    * @param name PreventiveMaintenance name
    * @returns PreventiveMaintenance
    */
    getPreventiveMaintenanceByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/PreventiveMaintenances?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all PreventiveMaintenances by filter
 * @returns Array of PreventiveMaintenances
 */
    getPreventiveMaintenancesByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/PreventiveMaintenances?$orderby=Id&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
        * Get a PreventiveMaintenance by id
        * @param id PreventiveMaintenance id
        * @returns PreventiveMaintenance
        */
    getPreventiveMaintenanceById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/PreventiveMaintenances(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a PreventiveMaintenance
 * @param preventiveMaintenance PreventiveMaintenance
 * @returns PreventiveMaintenance
 */
    add(preventiveMaintenance) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/PreventiveMaintenances', JSON.stringify(preventiveMaintenance));
            return resp;
        });
    }
    /**
    * Delete a PreventiveMaintenance
    * @param batteryId PreventiveMaintenanceId
    * @returns Boolean
    */
    delete(preventiveMaintenanceId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/PreventiveMaintenances(' + preventiveMaintenanceId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a PreventiveMaintenance
    * @param preventiveMaintenance PreventiveMaintenance
    * @returns PreventiveMaintenance
    */
    update(preventiveMaintenance) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/PreventiveMaintenances(' + preventiveMaintenance.Id + ')', JSON.stringify(preventiveMaintenance), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.PreventiveMaintenanceManager = PreventiveMaintenanceManager;
