"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorReportManager = void 0;
class ErrorReportManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all ErrorReports
     * @returns Array of ErrorReports
     */
    getErrorReports() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/ErrorReports()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new ErrorReport(d));
        });
    }
    /**
    * Get a ErrorReport by name
    * @param name ErrorReport name
    * @returns ErrorReport
    */
    getErrorReportByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/ErrorReports?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
        * Get a ErrorReport by id
        * @param id ErrorReport id
        * @returns ErrorReport
        */
    getErrorReportById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/ErrorReports(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all ErrorReports by filter
 * @returns Array of ErrorReports
 */
    getErrorReportsByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(filter, value);
            let url = 'MMDataService.svc/ErrorReports?$orderby=Id&$expand=Severity,ContractorExecutor,Installation&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
 * Post a ErrorReport
 * @param errorReport ErrorReport
 * @returns ErrorReport
 */
    add(errorReport, errorReportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const model = this.assignErrorReportModel(errorReport);
            if (errorReportId)
                model.Id = errorReportId;
            //console.log(model)
            const resp = yield this.http.postAsJson('MMDataService.svc/ErrorReports', JSON.stringify(model));
            return resp;
        });
    }
    /**
    * Delete a ErrorReport
    * @param errorReportId ErrorReportId
    * @returns Bolean
    */
    delete(errorReportId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/ErrorReports(' + errorReportId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a ErrorReport
    * @param errorReport ErrorReport
    * @returns ErrorReport
    */
    update(errorReport) {
        return __awaiter(this, void 0, void 0, function* () {
            const model = this.assignErrorReportModel(errorReport);
            const resp = yield this.http.post('MMDataService.svc/ErrorReports(' + errorReport.Id + ')', JSON.stringify(model), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    assignErrorReportModel(errorReport) {
        return {
            InstallationId: errorReport.InstallationId,
            Cause: errorReport.Cause,
            Coordinator: errorReport.Coordinator,
            ContactDetails: errorReport.ContactDetails,
            UserCreate: errorReport.UserCreate,
            ContractorCreateId: errorReport.ContractorCreateId,
            OrderId: errorReport.OrderId,
            DateCreation: errorReport.DateCreation,
            SeverityId: errorReport.SeverityId,
            ContractorExecutorId: errorReport.ContractorExecutorId,
            DateResponse: errorReport.DateResponse,
            UserComplete: errorReport.UserComplete,
            ContractorCompleteId: errorReport.ContractorCompleteId,
            PerformedAction: errorReport.PerformedAction,
            UsedMaterials: errorReport.UsedMaterials,
            Duration: errorReport.Duration,
            DateEnd: errorReport.DateEnd,
            Solved: errorReport.Solved,
            DateNotification: errorReport.DateNotification,
            NbReminder: errorReport.NbReminder,
            Document1: errorReport.Document1,
            Document2: errorReport.Document2,
            Document3: errorReport.Document3,
            VariableApp: errorReport.VariableApp,
            Count: errorReport.Count,
            Extension1: errorReport.Extension1,
            Extension2: errorReport.Extension2
        };
    }
}
exports.ErrorReportManager = ErrorReportManager;
