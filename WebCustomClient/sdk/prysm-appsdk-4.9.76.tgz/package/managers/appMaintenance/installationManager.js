"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstallationManager = void 0;
class InstallationManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all Installations
     * @returns Array of Installations
     */
    getInstallations() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Installations()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new Installation(d));
        });
    }
    /**
    * Get a Installation by name
    * @param name Installation name
    * @returns Installation
    */
    getInstallationByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/Installations?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
        * Get a Installation by id
        * @param id Installation id
        * @returns Installation
        */
    getInstallationById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/Installations(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a Installation
 * @param installation Installation
 * @returns Installation
 */
    add(installation) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/Installations', JSON.stringify(installation));
            return (yield resp.json());
        });
    }
    /**
    * Delete a Installation
    * @param installationId InstallationId
    * @returns Bolean
    */
    delete(installationId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Installations(' + installationId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a Installation
    * @param installation Installation
    * @returns Installation
    */
    update(installation) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/Installations(' + installation.Id + ')', JSON.stringify(installation), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.InstallationManager = InstallationManager;
