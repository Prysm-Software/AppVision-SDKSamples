import { PreventiveMaintenance } from '../../data/appMaintenance/preventiveMaintenance';
import { HttpService } from '../../services/httpService';
export declare class PreventiveMaintenanceManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all PreventiveMaintenances
     * @returns Array of PreventiveMaintenances
     */
    getPreventiveMaintenances(): Promise<PreventiveMaintenance[]>;
    /**
    * Get a PreventiveMaintenance by name
    * @param name PreventiveMaintenance name
    * @returns PreventiveMaintenance
    */
    getPreventiveMaintenanceByName(name: string): Promise<PreventiveMaintenance>;
    /**
 * Get all PreventiveMaintenances by filter
 * @returns Array of PreventiveMaintenances
 */
    getPreventiveMaintenancesByFilter(filter: string, value: string): Promise<PreventiveMaintenance[]>;
    /**
        * Get a PreventiveMaintenance by id
        * @param id PreventiveMaintenance id
        * @returns PreventiveMaintenance
        */
    getPreventiveMaintenanceById(id: number): Promise<PreventiveMaintenance>;
    /**
 * Post a PreventiveMaintenance
 * @param preventiveMaintenance PreventiveMaintenance
 * @returns PreventiveMaintenance
 */
    add(preventiveMaintenance: PreventiveMaintenance): Promise<PreventiveMaintenance>;
    /**
    * Delete a PreventiveMaintenance
    * @param batteryId PreventiveMaintenanceId
    * @returns Boolean
    */
    delete(preventiveMaintenanceId: number): Promise<boolean>;
    /**
    * Update a PreventiveMaintenance
    * @param preventiveMaintenance PreventiveMaintenance
    * @returns PreventiveMaintenance
    */
    update(preventiveMaintenance: PreventiveMaintenance): Promise<boolean>;
}
