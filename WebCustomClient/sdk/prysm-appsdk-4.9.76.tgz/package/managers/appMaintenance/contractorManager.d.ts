import { Contractor } from '../../data/appMaintenance/contractor';
import { HttpService } from '../../services/httpService';
export declare class ContractorManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all Contractors
     * @returns Array of Contractors
     */
    getContractors(): Promise<Contractor[]>;
    /**
        * Get a contractor by name
        * @param name Contractor name
        * @returns Contractor
        */
    getContractorByName(name: string): Promise<Contractor>;
    /**
    * Get a Contractor by id
    * @param id Contractor id
    * @returns Contractor
    */
    getContractorById(id: number): Promise<Contractor>;
    /**
    * Post a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    add(contractor: Contractor): Promise<Contractor>;
    /**
    * Delete a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    delete(contractorId: number): Promise<boolean>;
    /**
    * Update a Contractor
    * @param contractor Contractor
    * @returns Contractor
    */
    update(contractor: Contractor): Promise<boolean>;
}
