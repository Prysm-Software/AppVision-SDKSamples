import { Severity } from '../../data/appMaintenance/severity';
import { HttpService } from '../../services/httpService';
export declare class SeverityManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all Severities
     * @returns Array of Severities
     */
    getSeverities(): Promise<Severity[]>;
    /**
    * Get a Severity by name
    * @param name Severity name
    * @returns Severity
    */
    getSeverityByName(name: string): Promise<Severity>;
    /**
        * Get a Severity by id
        * @param id Severity id
        * @returns Severity
        */
    getSeverityById(id: number): Promise<Severity>;
    /**
 * Post a Severity
 * @param Severity Severity
 * @returns Severity
 */
    add(severity: Severity): Promise<Severity>;
    /**
    * Delete a Severity
    * @param Severity Severity
    * @returns Severity
    */
    delete(severityId: number): Promise<boolean>;
    /**
    * Update a Severity
    * @param severity Severity
    * @returns Severity
    */
    update(severity: Severity): Promise<boolean>;
}
