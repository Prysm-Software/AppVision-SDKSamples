"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaintenanceReportRowManager = void 0;
class MaintenanceReportRowManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all MaintenanceReportRows
     * @returns Array of MaintenanceReportRows
     */
    getMaintenanceReportRows() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/MaintenanceReportRows()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new MaintenanceReportRow(d));
        });
    }
    /**
    * Get a MaintenanceReportRow by name
    * @param name MaintenanceReportRow name
    * @returns MaintenanceReportRow
    */
    getMaintenanceReportRowByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/MaintenanceReportRows?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all MaintenanceReportRowReports by filter
 * @returns Array of MaintenanceReportRowReports
 */
    getMaintenanceReportRowsByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/MaintenanceReportRows?$orderby=Id&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new MaintenanceReportRowReport(d));
        });
    }
    /**
        * Get a MaintenanceReportRow by id
        * @param id MaintenanceReportRow id
        * @returns MaintenanceReportRow
        */
    getMaintenanceReportRowById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/MaintenanceReportRows(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a MaintenanceReportRow
 * @param MaintenanceReportRow MaintenanceReportRow
 * @returns MaintenanceReportRow
 */
    add(maintenanceReportRow) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(maintenanceReportRow);
            const resp = yield this.http.postAsJson('MMDataService.svc/MaintenanceReportRows', JSON.stringify(maintenanceReportRow));
            return resp;
        });
    }
    /**
    * Delete a MaintenanceReportRow
    * @param MaintenanceReportRowId MaintenanceReportRowId
    * @returns Bolean
    */
    delete(maintenanceReportRowId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/MaintenanceReportRows(' + maintenanceReportRowId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a MaintenanceReportRow
    * @param MaintenanceReportRow MaintenanceReportRow
    * @returns MaintenanceReportRow
    */
    update(maintenanceReportRow) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/MaintenanceReportRows(' + maintenanceReportRow.Id + ')', JSON.stringify(maintenanceReportRow), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.MaintenanceReportRowManager = MaintenanceReportRowManager;
