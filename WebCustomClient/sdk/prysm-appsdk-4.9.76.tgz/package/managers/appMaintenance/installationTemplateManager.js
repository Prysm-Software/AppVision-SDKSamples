"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstallationTemplateManager = void 0;
class InstallationTemplateManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all InstallationTemplates
     * @returns Array of InstallationTemplates
     */
    getInstallationTemplates() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/InstallationTemplates()?$orderby=Id');
            if (!resp.ok)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new InstallationTemplate(d));
        });
    }
    /**
    * Get a InstallationTemplate by name
    * @param name InstallationTemplate name
    * @returns InstallationTemplate
    */
    getInstallationTemplateByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/InstallationTemplates?$filter=Name eq '${name}'`);
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Get all InstallationTemplateReports by filter
 * @returns Array of InstallationTemplateReports
 */
    getInstallationTemplatesByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/InstallationTemplates?$orderby=Id&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new InstallationTemplateReport(d));
        });
    }
    /**
        * Get a InstallationTemplate by id
        * @param id InstallationTemplate id
        * @returns InstallationTemplate
        */
    getInstallationTemplateById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/InstallationTemplates(' + id + ')');
            if (!resp.ok)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a InstallationTemplate
 * @param InstallationTemplate InstallationTemplate
 * @returns InstallationTemplate
 */
    add(installationTemplate) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.postAsJson('MMDataService.svc/InstallationTemplates', JSON.stringify(installationTemplate));
            return resp;
        });
    }
    /**
    * Delete a InstallationTemplate
    * @param InstallationTemplateId InstallationTemplateId
    * @returns Bolean
    */
    delete(installationTemplateId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/InstallationTemplates(' + installationTemplateId + ')', '', 'DELETE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    /**
    * Update a InstallationTemplate
    * @param InstallationTemplate InstallationTemplate
    * @returns InstallationTemplate
    */
    update(installationTemplate) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/InstallationTemplates(' + installationTemplate.Id + ')', JSON.stringify(installationTemplate), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
}
exports.InstallationTemplateManager = InstallationTemplateManager;
