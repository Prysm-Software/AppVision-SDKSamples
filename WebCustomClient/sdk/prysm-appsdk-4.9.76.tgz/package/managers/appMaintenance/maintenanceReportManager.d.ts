import { MaintenanceReport } from '../../data/appMaintenance/maintenanceReport';
import { HttpService } from '../../services/httpService';
export declare class MaintenanceReportManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all MaintenanceReports
     * @returns Array of MaintenanceReports
     */
    getMaintenanceReports(): Promise<MaintenanceReport[]>;
    /**
    * Get a MaintenanceReport by name
    * @param name MaintenanceReport name
    * @returns MaintenanceReport
    */
    getMaintenanceReportByName(name: string): Promise<MaintenanceReport>;
    /**
        * Get a MaintenanceReport by id
        * @param id MaintenanceReport id
        * @returns MaintenanceReport
        */
    getMaintenanceReportById(id: number): Promise<MaintenanceReport>;
    /**
 * Post a MaintenanceReport
 * @param maintenanceReport MaintenanceReport
 * @returns MaintenanceReport
 */
    add(maintenanceReport: MaintenanceReport): Promise<MaintenanceReport>;
    /**
    * Delete a MaintenanceReport
    * @param maintenanceReportId MaintenanceReportId
    * @returns Bolean
    */
    delete(maintenanceReportId: number): Promise<boolean>;
    /**
    * Update a MaintenanceReport
    * @param maintenanceReport MaintenanceReport
    * @returns MaintenanceReport
    */
    update(maintenanceReport: MaintenanceReport): Promise<boolean>;
}
