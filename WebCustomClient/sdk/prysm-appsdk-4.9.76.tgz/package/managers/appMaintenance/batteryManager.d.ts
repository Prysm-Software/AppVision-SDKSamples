import { Battery } from '../../data/appMaintenance/battery';
import { HttpService } from '../../services/httpService';
export declare class BatteryManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all Batteries
     * @returns Array of Batteries
     */
    getBatteries(): Promise<Battery[]>;
    /**
    * Get a Battery by name
    * @param name Battery name
    * @returns Battery
    */
    getBatteryByName(name: string): Promise<Battery>;
    /**
 * Get all BatteryReports by filter
 * @returns Array of BatteryReports
 */
    getBatteriesByFilter(filter: string, value: string): Promise<Battery[]>;
    /**
        * Get a Battery by id
        * @param id Battery id
        * @returns Battery
        */
    getBatteryById(id: number): Promise<Battery>;
    /**
 * Post a Battery
 * @param battery Battery
 * @returns Battery
 */
    add(battery: Battery): Promise<Battery>;
    /**
    * Delete a Battery
    * @param batteryId BatteryId
    * @returns Bolean
    */
    delete(batteryId: number): Promise<boolean>;
    /**
    * Update a Battery
    * @param battery Battery
    * @returns Battery
    */
    update(battery: Battery): Promise<boolean>;
}
