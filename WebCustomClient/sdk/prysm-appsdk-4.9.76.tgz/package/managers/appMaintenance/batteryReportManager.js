"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatteryReportManager = void 0;
class BatteryReportManager {
    constructor(http) {
        this.http = http;
    }
    /**
     * Get all BatteryReports
     * @returns Array of BatteryReports
     */
    getBatteryReports() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/BatteryReports?$orderby=Id');
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
     * Get all BatteryReports by filter
     * @returns Array of BatteryReports
     */
    getBatteryReportsByFilter(filter, value) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = 'MMDataService.svc/BatteryReports?$orderby=Id&$expand=Severity,Contractor,ContractorExecutor,Installation&$filter= ' + filter + ' eq ' + value;
            const resp = yield this.http.get(url);
            if (resp.status === 204)
                return [];
            const json = yield resp.json();
            return json.value; //.map(d => new BatteryReport(d));
        });
    }
    /**
    * Get a BatteryReport by name
    * @param name BatteryReport name
    * @returns BatteryReport
    */
    getBatteryReportByName(name) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get(`MMDataService.svc/BatteryReports?$filter=Name eq '${name}'`);
            if (resp.status === 204)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
        * Get a BatteryReport by id
        * @param id BatteryReport id
        * @returns BatteryReport
        */
    getBatteryReportById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('MMDataService.svc/BatteryReports(' + id + ')');
            if (resp.status === 204)
                return null;
            const json = yield resp.json();
            return json;
        });
    }
    /**
 * Post a BatteryReport
 * @param batteryReport BatteryReport
 * @returns BatteryReport
 */
    add(batteryReport) {
        return __awaiter(this, void 0, void 0, function* () {
            let model = this.assignbatteryReportModel(batteryReport);
            if (batteryReport)
                model.Id = batteryReport.Id;
            const resp = yield this.http.postAsJson('MMDataService.svc/BatteryReports', JSON.stringify(model));
            return resp;
        });
    }
    /**
    * Delete a BatteryReport
    * @param batteryId BatteryReportId
    * @returns boolean
    */
    delete(batteryId) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post('MMDataService.svc/BatteryReports(' + batteryId + ')', '', 'DELETE');
            if (resp.status === 204)
                return false;
            return true;
        });
    }
    /**
    * Update a BatteryReport
    * @param batteryReport BatteryReport
    * @returns BatteryReport
    */
    update(batteryReport) {
        return __awaiter(this, void 0, void 0, function* () {
            let model = this.assignbatteryReportModel(batteryReport);
            const resp = yield this.http.post('MMDataService.svc/BatteryReports(' + batteryReport.Id + ')', JSON.stringify(model), 'MERGE');
            if (!resp.ok)
                return false;
            return true;
        });
    }
    assignbatteryReportModel(batteryReport) {
        return {
            InstallationId: batteryReport.InstallationId,
            BatteryDateMarking: batteryReport.BatteryDateMarking,
            TakeOldBattery: batteryReport.TakeOldBattery,
            ResetFault: batteryReport.ResetFault,
            ControlJournal: batteryReport.ControlJournal,
            DateCreation: batteryReport.DateCreation,
            SeverityId: batteryReport.SeverityId,
            DateResponse: batteryReport.DateResponse,
            User: batteryReport.User,
            ContractorId: batteryReport.ContractorId,
            ContractorExecutorId: batteryReport.ContractorExecutorId,
            UserComplete: batteryReport.UserComplete,
            Duration: batteryReport.Duration,
            DateComplete: batteryReport.DateComplete,
            Finished: batteryReport.Finished,
            DateNotification: batteryReport.DateNotification,
            NbReminder: batteryReport.NbReminder,
            Document1: batteryReport.Document1,
            Document2: batteryReport.Document2,
            Document3: batteryReport.Document3,
            Extension1: batteryReport.Extension1,
            Extension2: batteryReport.Extension2
        };
    }
}
exports.BatteryReportManager = BatteryReportManager;
