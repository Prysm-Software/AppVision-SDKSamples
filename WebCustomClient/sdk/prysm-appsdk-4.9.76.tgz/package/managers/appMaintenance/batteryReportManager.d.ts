import { BatteryReport, BatteryReportModel } from '../../data/appMaintenance/batteryReport';
import { HttpService } from '../../services/httpService';
export declare class BatteryReportManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all BatteryReports
     * @returns Array of BatteryReports
     */
    getBatteryReports(): Promise<BatteryReport[]>;
    /**
     * Get all BatteryReports by filter
     * @returns Array of BatteryReports
     */
    getBatteryReportsByFilter(filter: string, value: string): Promise<BatteryReport[]>;
    /**
    * Get a BatteryReport by name
    * @param name BatteryReport name
    * @returns BatteryReport
    */
    getBatteryReportByName(name: string): Promise<BatteryReport>;
    /**
        * Get a BatteryReport by id
        * @param id BatteryReport id
        * @returns BatteryReport
        */
    getBatteryReportById(id: number): Promise<BatteryReport>;
    /**
 * Post a BatteryReport
 * @param batteryReport BatteryReport
 * @returns BatteryReport
 */
    add(batteryReport: BatteryReport): Promise<BatteryReport>;
    /**
    * Delete a BatteryReport
    * @param batteryId BatteryReportId
    * @returns boolean
    */
    delete(batteryId: number): Promise<boolean>;
    /**
    * Update a BatteryReport
    * @param batteryReport BatteryReport
    * @returns BatteryReport
    */
    update(batteryReport: BatteryReport): Promise<boolean>;
    assignbatteryReportModel(batteryReport: BatteryReport): BatteryReportModel;
}
