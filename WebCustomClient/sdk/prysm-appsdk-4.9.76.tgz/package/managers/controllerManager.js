"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ControllerManager = void 0;
const helper_1 = require("../common/helper");
const stringHelper_1 = require("../common/stringHelper");
class ControllerManager {
    constructor(http, odata, fileManager) {
        this.fileManager = fileManager;
        this.http = http;
        this.odata = odata;
    }
    /**
     * Start the appserver
     */
    startSupervision() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get("AppVisionService.svc/StartSupervision");
        });
    }
    /**
     * Stop the appserver
     * @param restart Restart the server or not
     */
    stopSupervision(restart) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.get("AppVisionService.svc/StopSupervision?restart=" + restart.toString());
        });
    }
    /**
     * Export database table as a csv file
     * @param table Database table (Param.Areas, Param.Variables, AppControl.People...)
     * @param filename Filename to be saved on the server
     * @param clauseWhere Where filter
     * @returns Filepath of the export
     */
    exportTable(table, filename, clauseWhere) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!filename.endsWith(".csv"))
                filename += ".csv";
            yield this.http.get("AppVisionService.svc/ExportTable?table=" + table + "&filename=" + filename + "&clauseWhere=" + clauseWhere);
            return "Backup/" + filename;
            // const result = /^(\d+)/.exec(lines);
            // return Helper.parseInt(result[1], -1);
        });
    }
    /**
     * Import tables into the server
     * @param tables Tables to import (csv files)
     * @param resetTable Reset the table or not
     * @returns String result with number of lines imported and details
     */
    importTables(tables, resetTables) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const file of tables) {
                yield this.fileManager.putFile("Config/Import/" + file.filename, file.rawContent);
            }
            yield this.beginExecuteTask("ImportTables", resetTables + "," + tables.map(t => t.filename).join(','));
            const result = yield this.waitForExecuteTaskResult();
            return result;
        });
    }
    /**
     * Export the Param folder
     * @param filename ZIP filename of the export to create
     * @param password Password of the export (optional)
     * @returns Filepath of the export
     */
    exportConfig(filename, password) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!filename.endsWith(".zip"))
                filename = filename + ".zip";
            yield this.beginExecuteTask("SaveConfiguration", filename + (password ? ";" + password : ""));
            yield this.waitForExecuteTaskResult();
            return "Backup/" + filename;
        });
    }
    /**
     * Import zip config on the server
     * @param filename Filename of archive
     * @param zip Blob of zip archive
     * @param password Password for the archive
     */
    importConfig(filename, zip, password) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.fileManager.putFile("Config/Backup/" + filename, zip);
            yield this.beginExecuteTask("RestoreConfiguration", filename + (password ? ";" + password : ""));
            yield this.waitForExecuteTaskResult();
        });
    }
    /**
     * Export the Histo database
     * @param filename Filename of the export
     * @returns Filepath of the export
     */
    exportHisto(filename) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!filename.endsWith(".backup"))
                filename = filename + ".backup";
            yield this.beginExecuteTask("BackupDatabaseHisto", filename);
            yield this.waitForExecuteTaskResult();
            return "Backup/" + filename;
        });
    }
    /**
     * Import the Histo database
     * @param filename Filename of the histodatabase
     * @param rawExport Blob of the database file
     */
    importHisto(filename, rawExport) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.fileManager.putFile("Config/Backup/" + filename, rawExport);
            yield this.beginExecuteTask("RestoreDatabaseHisto", filename);
            yield this.waitForExecuteTaskResult();
        });
    }
    /**
     * Check the database
     * @param applyCorrection Fix anomalies or not
     */
    checkDatabase(applyCorrection) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.beginExecuteTask("CheckDatabase", applyCorrection.toString());
            const result = yield this.waitForExecuteTaskResult();
            return result;
        });
    }
    /**
     * Build server scripts
     * @param debug
     * @returns Array of errors. Empty if there is none
     */
    buildServerProject(debug = false) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.odata.getAsJson("AppVisionDataService.svc/BuildServerProject?debug=" + debug);
            const errors = json.value.split('\r\n').filter(r => !stringHelper_1.StringHelper.isNullOrEmpty(r));
            return errors;
        });
    }
    beginExecuteTask(taskname, content) {
        return __awaiter(this, void 0, void 0, function* () {
            const xml = '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">' +
                content +
                '</string>';
            yield this.http.post("AppVisionService.svc/BeginExecuteTask?taskname=" + taskname, xml, "POST", { "Content-Type": 'application/xml; charset=utf-8' });
        });
    }
    waitForExecuteTaskResult() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = "";
            do {
                yield helper_1.Helper.delay(2000);
                result = yield this.http.getAsJson("AppVisionService.svc/GetExecuteTaskResult");
                if (result.startsWith("NOK:")) {
                    const msg = result.split(':').slice(1).join(':');
                    throw new Error(msg);
                }
                else if (result === "NOK") {
                    throw new Error("Task failed");
                }
            } while (!result.startsWith("OK:") && result !== "OK");
            if (result.startsWith("OK:")) {
                const msg = result.split(':').slice(1).join(':');
                return msg;
            }
            return result;
        });
    }
}
exports.ControllerManager = ControllerManager;
