"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VariableManager = void 0;
const variableRow_1 = require("../data/variableRow");
const variableState_1 = require("../data/variableState");
const valueRow_1 = require("../data/valueRow");
const treeHelper_1 = require("../common/treeHelper");
const webServiceHelper_1 = require("../common/webServiceHelper");
const treeRowManager_1 = require("./base/treeRowManager");
class VariableManager extends treeRowManager_1.TreeRowManager {
    constructor(http, odata) {
        super(http, odata, { letter: 'V' });
    }
    /**
     * Set variable
     * @param varName Variable name
     * @param varValue Variable value
     * @param info Info field
     */
    set(varName, varValue, info = null, params = null) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!params)
                params = [];
            params.push({ Name: "@name", Value: varName });
            params.push({ Name: "@value", Value: varValue });
            if (info !== null)
                params.push({ Name: "@info", Value: info });
            yield this.http.post('AppVisionService.svc/SetVariableExt', JSON.stringify(params));
        });
    }
    /**
     * Lock or unlock variable
     * @param varName VariableName
     * @param isLocked Lock or unlock
     * @param params NameValue parameters
     */
    lock(varName, isLocked, params) {
        return __awaiter(this, void 0, void 0, function* () {
            const uri = `AppVisionService.svc/LockVariableExt?name=${varName}&isLocked=${isLocked}`;
            yield this.http.post(encodeURI(uri), JSON.stringify(params));
        });
    }
    /**
     * Updates a VariableRow
     * @param row VariableRow to be updated.
     * @returns true if the variable has been successfully updated.
     */
    update(row) {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = 'AppVisionService.svc/VariableManager/Update';
            const clone = webServiceHelper_1.WebServiceHelper.cloneVariable(row);
            const json = yield this.http.postAsJson(uri, JSON.stringify(clone));
            return json.map(r => new variableRow_1.VariableRow(r));
        });
    }
    /**
     * Add new VariableRow
     * @param row VariableRow to add
     * @returns VariableRow created
     */
    add(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post("AppVisionService.svc/AddVariable2", JSON.stringify(row), 'POST');
            const json = yield resp.json();
            return new variableRow_1.VariableRow(json);
        });
    }
    /**
     * Add an array of rows
     * @param rows
     * @returns true ou false
     */
    adds(rows) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.post("AppVisionService.svc/AddVariables", JSON.stringify(rows), 'POST');
            const json = yield resp.json();
            return json;
        });
    }
    /**
     * Delete a row
     * @param row Row to delete
     */
    delete(row) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = webServiceHelper_1.WebServiceHelper.cloneVariable(row);
            const json = yield this.http.postAsJson("AppVisionService.svc/DeleteVariable", JSON.stringify(clone), 'POST');
            if (json === false)
                throw new Error("Failed to delete");
        });
    }
    /**
     * Get all variable rows matching the given filter
     * @returns Tree of variable rows
     * @remark Get items from cache
     */
    getRowsTreeByFilter(filter) {
        const wanted = this.getRows().filter(filter);
        // On utilise un Map au lieu d'un array pour des questions de performances.
        const final = new Map();
        for (const r of wanted) {
            const arr = r.Name.split('.');
            let name = "";
            for (const rr of arr) {
                name += rr;
                if (!final.has(name)) {
                    const clone = this.getRowByName(name);
                    clone.parent = null;
                    clone.items = null;
                    final.set(name, clone);
                }
                name += '.';
            }
        }
        return treeHelper_1.TreeHelper.buildTreeRow([...final.values()]);
    }
    /**
     * Get rows by type
     * @param rowType Variable row type
     * @returns Array of variables
     *
     * @remark
     * Get value from cache
     */
    getRowsByType(rowType) {
        return this.getRows().filter(v => v.Type === rowType);
    }
    /**
     * Get variable states history
     * @param dateStart Filter date start
     * @param dateEnd  Filter date end
     * @param variableNames Filter variable names
     * @param maxCount Max count result. Default is 2500
     * @param start Result start index. Default is 0
     * @returns Array of variable rows
     */
    getHistoValues(dateStart, dateEnd, variableNames, count = 2500, start = 0) {
        return __awaiter(this, void 0, void 0, function* () {
            const uri = `AppVisionService.svc/GetHistoValues?` +
                `index=${start}` +
                `&count=${count}` +
                `&dateStart=${dateStart.toISOString()}` +
                `&dateEnd=${dateEnd.toISOString()}` +
                `&names=${variableNames.join(',')}`;
            const resp = yield this.http.get(uri);
            const json = yield resp.json();
            return json.map(a => new valueRow_1.ValueRow(a));
        });
    }
    /**
     * Request the full list of variable row.
     * This request includes excluded variables
     * @returns Array of VariableRow
     */
    getAll() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const count = 20000;
            let start = 0;
            let json;
            let resp;
            let rows = [];
            do {
                resp = yield this.odata.get('AppVisionDataService.svc/Variables?$skip=' + start + "&$top=" + count);
                if (resp.status === 204) {
                    json = [];
                }
                else {
                    json = (_a = (yield resp.json())) === null || _a === void 0 ? void 0 : _a.value;
                    rows.push(...json);
                }
                start += count;
            } while (json.length >= count);
            return rows.map(p => new variableRow_1.VariableRow(p));
        });
    }
    /**
     * Request variables by filter
     * @param filter Filter text (ex: $A.Area1)
     * @returns Array of variable row
     * @example
     * server.variableManager.getRowsByFilter('$A.Area1|$G.Group1')
     */
    getRowsByFilter(filter) {
        return __awaiter(this, void 0, void 0, function* () {
            // const resp = await this.http.get('AppVisionService.svc/GetVariablesByFilter?filters=' + filter + '&count=0&indexStart=0');
            // const json = await resp.json();
            // return (json as VariableRow[]).map(p => new VariableRow(p));
            const pageSize = 20000;
            let start = 0;
            let json = [];
            let resp;
            const rows = [];
            do {
                resp = yield this.http.get('AppVisionService.svc/GetVariablesByFilter?filters=' + filter + '&count=' + pageSize + '&indexStart=' + start);
                json = yield resp.json();
                rows.push(...json);
                start += pageSize;
            } while (json.length >= pageSize);
            return json.map(p => new variableRow_1.VariableRow(p));
        });
    }
    /**
     * Request variables for a specific protocol
     * @param protocolName
     * @returns Array of VariableRow
     */
    getRowsByProtocol(protocolName) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetVariablesByProtocol?protocolName=' + protocolName);
            const json = yield resp.json();
            return json.map(p => new variableRow_1.VariableRow(p));
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            const count = 20000;
            let start = 0;
            let json = [];
            let resp;
            this.states = new Map();
            this.rowsByName = new Map();
            this.rowsById = new Map();
            do {
                resp = yield this.http.get('AppVisionService.svc/GetVariableStates?indexStart=' + start + "&count=" + count);
                json = yield resp.json();
                for (const s of json)
                    this.states.set(s.Name, new variableState_1.VariableState(s));
                start += count;
            } while (json.length >= count);
            start = 0;
            let rows = [];
            do {
                resp = yield this.http.get('AppVisionService.svc/GetVariables?indexStart=' + start + "&count=" + count);
                json = yield resp.json();
                rows.push(...json);
                start += count;
            } while (json.length >= count);
            for (const r of rows) {
                const row = new variableRow_1.VariableRow(r);
                const state = this.states.get(r.Name);
                if (state) { // liaison row <-> state
                    state.Row = row;
                    row.State = state;
                }
                this.rowsByName.set(r.Name, row);
                this.rowsById.set(r.Id, row);
            }
            // liaison .parent .items
            treeHelper_1.TreeHelper.buildTreeRow([...this.rowsByName.values()]);
        });
    }
    /** @internal */
    updateRowsInternal(rows) {
        return __awaiter(this, void 0, void 0, function* () {
            const added = [];
            const updated = [];
            let deleted = [];
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const originalRow = this.getRowById(row.Id);
                // Name changed ?
                if (this.getStateByName(row.Name) == null) {
                    const rowToDelete = this.getRows().find(v => v.Id === row.Id);
                    if (rowToDelete) {
                        this.rowsByName.delete(rowToDelete.Name);
                        this.rowsById.delete(rowToDelete.Id);
                        this.states.delete(rowToDelete.Name);
                    }
                }
                // New variable
                if (originalRow == null) {
                    if (row.Type !== variableRow_1.VariableType.Node) {
                        const state = yield this.getState(row.Id);
                        if (state) {
                            row.State = state;
                            state.Row = row;
                            this.states.set(state.Name, state);
                        }
                    }
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    //todo set parent & items
                    added.push(row);
                }
                // Deleted variable
                else if (row.IsExclude === true) {
                    const notifsRow = [row];
                    this.rowsByName.delete(row.Name);
                    this.rowsById.delete(row.Id);
                    this.states.delete(row.Name);
                    //todo retire parent.items
                    if (row.Type === variableRow_1.VariableType.Node) {
                        const rowsByNameToDelete = [...this.rowsByName.keys()].filter(k => k.startsWith(row.Name + '.'));
                        rowsByNameToDelete.forEach(key => this.rowsByName.delete(key));
                        const statesByNameToDelete = [...this.states.keys()].filter(k => k.startsWith(row.Name + '.'));
                        statesByNameToDelete.forEach(key => this.states.delete(key));
                        const rowsByIdToDelete = [...this.rowsById].filter(entry => entry[1].Name.startsWith(row.Name + '.'));
                        rowsByIdToDelete.forEach(entry => {
                            notifsRow.push(entry[1]);
                            this.rowsById.delete(entry[0]);
                        });
                    }
                    deleted = [...deleted, ...notifsRow];
                }
                // Updated variable
                else {
                    // WARNING : FullDescription is empty inside the notif object
                    const state = originalRow.State;
                    if (state) {
                        // Update the state if name changed
                        state.Name = row.Name;
                        this.states.set(state.Name, state);
                        row.State = state;
                        state.Row = row;
                    }
                    this.rowsByName.set(row.Name, row);
                    this.rowsById.set(row.Id, row);
                    //todo set parent & items
                    updated.push(row);
                }
            }
            // On reconstruit les relation parent enfants sur les rows qui ont changé
            const updateRelation = [...added, ...updated];
            if (updateRelation.length > 0)
                treeHelper_1.TreeHelper.buildTreeRow(updateRelation);
            // On notifie les clients
            let notifs = [];
            if (added.length > 0) {
                this.rowsAdded.next(added);
                notifs = [...notifs, ...added.map(r => ({ row: r, type: "ADD" }))];
            }
            if (deleted.length > 0) {
                this.rowsDeleted.next(deleted);
                notifs = [...notifs, ...deleted.map(r => ({ row: r, type: "DELETE" }))];
            }
            if (updated.length > 0) {
                this.rowsUpdated.next(updated);
                notifs = [...notifs, ...updated.map(r => ({ row: r, type: "UPDATE" }))];
            }
            if (notifs.length > 0) {
                this.rowsChanged.next(notifs);
            }
        });
    }
    /** @internal */
    updateStatesInternal(states) {
        const statesChanged = [];
        states.forEach(state => {
            const row = this.rowsByName.get(state.Name);
            if (row) {
                row.State = state;
                state.Row = row;
                this.states.set(state.Name, state);
                statesChanged.push(state);
            }
        });
        if (statesChanged.length > 0) {
            this.statesChanged.next(statesChanged);
        }
    }
    constructRow(args) {
        return new variableRow_1.VariableRow(args);
    }
    constructState(args) {
        return new variableState_1.VariableState(args);
    }
    getState(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const resp = yield this.http.get('AppVisionService.svc/GetVariableStateById?id=' + id);
                const json = yield resp.json();
                return new variableState_1.VariableState(json);
            }
            catch (e) {
                return null;
            }
        });
    }
}
exports.VariableManager = VariableManager;
