import { UserRow } from "../data/userRow";
import { ClientInfo } from "../data/clientInfo";
import { HttpService } from "../services/httpService";
import { UserState } from "../data/userState";
import { Subject } from "rxjs";
import { RowManager } from "./base/rowManager";
export declare class UserManager extends RowManager<UserRow> {
    currentUser: UserRow;
    stateChanged: Subject<UserState>;
    constructor(http: HttpService, odata: HttpService);
    /**
     * Get users from server
     * @returns Array of UserRow
     * @remark Request values from server
     */
    getAll(): Promise<UserRow[]>;
    /**
     * Get connected users from cache
     * @returns Array of userRow
     */
    getConnectedUsers(): Promise<ClientInfo[]>;
    /**
     * Request all user from a profile
     * @param profileName Profile name
     * @returns Array of UserRow
     */
    getRowsByProfileName(profileName: string): Promise<UserRow[]>;
    /**
     * Delete user
     * @param user User to delete
     */
    delete(user: UserRow): Promise<void>;
    /**
     * Add new user
     * @param user User to add
     * @returns UserRow created
     */
    add(user: UserRow): Promise<UserRow>;
    /**
     * Update user
     * @param user UserRow to
     */
    update(user: UserRow): Promise<void>;
    /**
     * Check rights of the current connected user
     * @param right Right name
     * @returns True or false
     */
    checkRight(right: string): boolean;
    /**
     * Change pasword of an user
     * @param username Username
     * @param oldPassword Old password
     * @param newPassword New password
     */
    changePassword(username: string, oldPassword: string, newPassword: string): Promise<void>;
    protected constructRow(args: Partial<UserRow>): UserRow;
}
