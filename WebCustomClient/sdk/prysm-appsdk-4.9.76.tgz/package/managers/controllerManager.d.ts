import { HttpService } from "../services/httpService";
import { FileManager } from "./fileManager";
interface Table {
    rawContent: Blob;
    filename: string;
}
export declare class ControllerManager {
    private http;
    private odata;
    private fileManager;
    constructor(http: HttpService, odata: HttpService, fileManager: FileManager);
    /**
     * Start the appserver
     */
    startSupervision(): Promise<void>;
    /**
     * Stop the appserver
     * @param restart Restart the server or not
     */
    stopSupervision(restart: boolean): Promise<void>;
    /**
     * Export database table as a csv file
     * @param table Database table (Param.Areas, Param.Variables, AppControl.People...)
     * @param filename Filename to be saved on the server
     * @param clauseWhere Where filter
     * @returns Filepath of the export
     */
    exportTable(table: string, filename: string, clauseWhere: string): Promise<string>;
    /**
     * Import tables into the server
     * @param tables Tables to import (csv files)
     * @param resetTable Reset the table or not
     * @returns String result with number of lines imported and details
     */
    importTables(tables: Table[], resetTables: boolean): Promise<string>;
    /**
     * Export the Param folder
     * @param filename ZIP filename of the export to create
     * @param password Password of the export (optional)
     * @returns Filepath of the export
     */
    exportConfig(filename: string, password?: string): Promise<string>;
    /**
     * Import zip config on the server
     * @param filename Filename of archive
     * @param zip Blob of zip archive
     * @param password Password for the archive
     */
    importConfig(filename: string, zip: Blob, password?: string): Promise<void>;
    /**
     * Export the Histo database
     * @param filename Filename of the export
     * @returns Filepath of the export
     */
    exportHisto(filename: string): Promise<string>;
    /**
     * Import the Histo database
     * @param filename Filename of the histodatabase
     * @param rawExport Blob of the database file
     */
    importHisto(filename: string, rawExport: Blob): Promise<void>;
    /**
     * Check the database
     * @param applyCorrection Fix anomalies or not
     */
    checkDatabase(applyCorrection: boolean): Promise<string>;
    /**
     * Build server scripts
     * @param debug
     * @returns Array of errors. Empty if there is none
     */
    buildServerProject(debug?: boolean): Promise<string[]>;
    private beginExecuteTask;
    private waitForExecuteTaskResult;
}
export {};
