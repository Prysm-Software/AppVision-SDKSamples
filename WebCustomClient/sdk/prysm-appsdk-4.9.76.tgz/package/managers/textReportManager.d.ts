import { TextReportRow } from "../data/textReportRow";
import { HttpService } from "../services/httpService";
export declare class TextReportManager {
    private http;
    constructor(http: HttpService);
    /**
     * Get all TextReportRow from the server
     * @returns Array of TextReportRow
     */
    getAll(): Promise<TextReportRow[]>;
    /**
     * Add a new TextReportRow
     * @param obj TextReportRow to add
     * @returns TextReportRow created
     */
    add(row: TextReportRow): Promise<TextReportRow>;
    /**
     * Update an TextReportRow
     * @param obj TextReportRow to update
     * @returns TextReportRow updated
     */
    update(row: TextReportRow): Promise<TextReportRow>;
    /**
     * Delete a TextReportRow
     * @param id TextReportRow Id
     */
    delete(id: number): Promise<void>;
}
