import { Subject } from "rxjs";
import { OptionRow } from "../data/optionRow";
import { HttpService } from "../services/httpService";
import { NameValue } from "../data/nameValue";
export declare class OptionManager {
    private http;
    private options;
    rowsUpdated: Subject<OptionRow[]>;
    constructor(http: HttpService);
    /**
     * Get option value
     * @param optionName Option name
     * @returns Option value as string
     */
    get(optionName: string): string;
    /**
     * Request all option from server
     * @returns Array of NameValue
     */
    getAll(): Promise<NameValue[]>;
    /**
     * Set option value
     * @param optionName Option name
     * @param value Option value
     */
    set(optionName: string, value: string): Promise<void>;
    /**
     * Delete an option by it's name
     * @param optionName Option name
     * @returns Result of the request
     */
    delete(optionName: string): Promise<boolean>;
    /**
     * Get options by startname filter
     * @param startName Start name filter
     * @returns Array of option row
     * @remark Request object from the server
     */
    getRowsByName(startName: string): Promise<OptionRow[]>;
    private loadDefaultOptions;
}
