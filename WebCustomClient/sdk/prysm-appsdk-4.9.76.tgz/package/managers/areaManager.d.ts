import { AreaRow } from "../data/areaRow";
import { AreaState } from "../data/areaState";
import { HttpService } from "../services/httpService";
import { TreeRowManager } from "./base/treeRowManager";
export declare class AreaManager extends TreeRowManager<AreaRow, AreaState> {
    constructor(http: HttpService, odata: HttpService);
    /**
     * Request the full list of areas row.
     * This request includes excluded entities
     * @returns Array of AreaRow
     * @remark Request values from the server
     */
    getAll(): Promise<AreaRow[]>;
    /**
     * Delete an area
     * @param row AreaRow
     */
    delete(row: AreaRow): Promise<boolean>;
    /**
     * Add new area
     * @param area AreaRow to add
     * @returns AreaRow added
     */
    add(area: AreaRow): Promise<AreaRow>;
    /**
     * Update a area
     * @param area
     * @returns Array of AreaRow updated
     */
    update(row: AreaRow): Promise<AreaRow[]>;
    protected constructRow(args: Partial<AreaRow>): AreaRow;
    protected constructState(args: Partial<AreaState>): AreaState;
    protected getState(id: number): Promise<AreaState>;
}
