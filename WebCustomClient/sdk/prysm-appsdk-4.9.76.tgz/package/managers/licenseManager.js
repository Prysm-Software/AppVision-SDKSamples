"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseManager = void 0;
const helper_1 = require("../common/helper");
class LicenseManager {
    constructor(http) {
        this.infos = new Map(); // libellés dans la langue choisie
        this.http = http;
    }
    /**
     * Get licence field value
     * @param key Licence field name
     * @returns Value as string
     */
    get(key) {
        return this.infos.get(key) || null;
    }
    /**
     * Get license infos
     * @returns Dictionnary
     */
    getInfos() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetLicenseInfos');
            const json = yield resp.json();
            return json;
        });
    }
    /**
     * Get license stat infos
     * @returns Array of AppStatItem
     */
    getStatInfos() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetLicenseStatInfos');
            const json = yield resp.json();
            const stats = [];
            json.forEach(v => {
                const arr = v.split(':');
                stats.push({
                    name: arr[0],
                    value: helper_1.Helper.parseInt(arr[1]),
                    max: helper_1.Helper.parseInt(arr[2], undefined)
                });
            });
            return stats;
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            this.infos.clear();
            const resp = yield this.getInfos();
            const tmp = new Map();
            resp.forEach(nv => tmp.set(nv.Name, nv.Value));
            this.infos = tmp;
        });
    }
}
exports.LicenseManager = LicenseManager;
