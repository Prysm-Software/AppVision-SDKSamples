import { UserMessageCategory } from "../data/userMessageCategory";
import { UserMessageProperty, UserMessageRow } from "../data/userMessageRow";
import { HttpService } from "../services/httpService";
import { OptionManager } from "./optionManager";
export declare enum XmlTags {
    Xml = "<?xml version=\"1.0\" encoding=\"utf-16\"?>",
    ArrayOfUserMessageCategory = "ArrayOfUserMessageCategory",
    UserMessageCategory = "UserMessageCategory",
    Description = "Description",
    Icon = "Icon",
    Severity = "Severity",
    Properties = "Properties",
    UserMessageCategoryProperty = "UserMessageCategoryProperty",
    NameValue = "NameValue",
    IsRequired = "IsRequired",
    Values = "Values",
    Type = "Type",
    ArrayOfNameValue = "ArrayOfNameValue",
    Name = "Name",
    Value = "Value"
}
export declare class UserMessageManager {
    private http;
    private optionManager;
    private optionName;
    constructor(http: HttpService, optionManager: OptionManager);
    /**
     * Get user message categories
     * @returns Array of UserMessageCategory
     */
    getCategories(): UserMessageCategory[];
    /**
     * Get user message category by description
     * @param categoryDesc Description of the user message category
     * @param categoryPropCount Count of category properties
     * @returns The first UserMessageCategory found with the given description and the given properties count if specified
     */
    getCategoryByDesc(categoryDesc: string, categoryPropCount?: number): UserMessageCategory;
    /**
     * Get user messages from the server
     * @param dateStart Date start filter
     * @param dateEnd Date end filter
     * @param filters Filter operand
     * @param maxCount Max count result. Default is 2500
     * @returns Array of UserMessageRow
     */
    getUserMessages(dateStart: Date, dateEnd?: Date, filters?: string, maxCount?: number): Promise<UserMessageRow[]>;
    /**
     * Retrieves a user message from the server by its identifier
     * @param id The unique identifier of the user message to retrieve
     * @returns A promise that resolves to a `UserMessageRow` representing the requested message
     */
    getUserMessageById(id: number): Promise<UserMessageRow>;
    /**
     * Call the API to add a new user message
     * @param userMessageRow User message to add
     * @returns The response of the API: the ID of the user message if successfully added
     */
    add(userMessageRow: UserMessageRow): Promise<UserMessageRow>;
    /**
     * Call the API to update a new user message
     * @param userMessageRow User message to update
     */
    update(userMessageRow: UserMessageRow): Promise<UserMessageRow>;
    /**
     * JSON.stringify() replacer function that transforms date fields into
     * WCF-compatible formats during serialization.
     *
     * Handles:
     *   - DateTimeOffset fields (e.g., DateCreate, DateClose)
     *     → converted to `{ DateTime: "/Date(ms)/", OffsetMinutes: X }`
     *   - DateTime fields (e.g., DateWrite)
     *     → converted to `/Date(ms)/`
     *
     * This ensures the final JSON payload matches the formats expected by WCF
     * services using DataContractJsonSerializer.
     *
     * @param key The property name currently being serialized.
     * @param value The value associated with the property.
     * @returns The transformed value (if a date field) or the original value.
     */
    private wcfDateReplacer;
    /**
     * Transform an array of UserMessageProperty into a xml string compatible with the UserMessageRow.ContentCategory property
     * @param properties Array of UserMessageProperty to transform
     * @returns The xml string
     */
    userMessagePropertiesToXml(properties: UserMessageProperty[]): string;
    private categoryToXml;
    private categoryPropertyToXml;
    /**
     * Add new user message category
     * @param category UserMessageCategory to add
     * @returns True if the operation has succeeded or an error message if not
     */
    addCategory(category: UserMessageCategory): void;
    /**
     * Update a user message category
     * @param category Category to update
     * @returns True if the operation has succeeded or an error message if not
     */
    updateCategory(category: UserMessageCategory): void;
    /**
     * Remove 1 user message category, based on its index
     * @param index Index of UserMessageCategory to remove
     */
    removeCategory(index: number): void;
    /**
     * Remove several user message categories, based on their indexes
     * @param indexes Array of indexes of UserMessageCategory to remove
     */
    removeCategories(indexes: number[]): void;
}
