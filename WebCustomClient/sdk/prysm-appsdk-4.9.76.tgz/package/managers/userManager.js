"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserManager = void 0;
const userRow_1 = require("../data/userRow");
const clientInfo_1 = require("../data/clientInfo");
const profileRow_1 = require("../data/profileRow");
const rxjs_1 = require("rxjs");
const helper_1 = require("../common/helper");
const rowManager_1 = require("./base/rowManager");
class UserManager extends rowManager_1.RowManager {
    constructor(http, odata) {
        super(http, odata, { letter: 'U' });
        this.stateChanged = new rxjs_1.Subject();
    }
    /**
     * Get users from server
     * @returns Array of UserRow
     * @remark Request values from server
     */
    getAll() {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.getAsJson('AppVisionService.svc/GetUsers');
            return json.map(u => new userRow_1.UserRow(u));
        });
    }
    /**
     * Get connected users from cache
     * @returns Array of userRow
     */
    getConnectedUsers() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.http.get('AppVisionService.svc/GetUsersConnected');
            const clientInfoResp = yield resp.json();
            return clientInfoResp.map(u => new clientInfo_1.ClientInfo(u));
        });
    }
    /**
     * Request all user from a profile
     * @param profileName Profile name
     * @returns Array of UserRow
     */
    getRowsByProfileName(profileName) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.getAsJson('AppVisionService.svc/GetUsersByProfile?name=' + profileName);
            return json.map(u => new userRow_1.UserRow(u));
        });
    }
    /**
     * Delete user
     * @param user User to delete
     */
    delete(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield this.http.postAsJson('AppVisionService.svc/DeleteUser', JSON.stringify(user));
            if (!json)
                throw new Error("Server returned false");
        });
    }
    /**
     * Add new user
     * @param user User to add
     * @returns UserRow created
     */
    add(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(user);
            const json = yield this.http.postAsJson('AppVisionService.svc/UserManager/Add', JSON.stringify(clone));
            return new userRow_1.UserRow(json);
        });
    }
    /**
     * Update user
     * @param user UserRow to
     */
    update(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const clone = helper_1.Helper.lightCloneObject(user);
            const json = yield this.http.postAsJson('AppVisionService.svc/UpdateUser', JSON.stringify(clone));
            if (!json)
                throw new Error("Server returned false");
        });
    }
    /**
     * Check rights of the current connected user
     * @param right Right name
     * @returns True or false
     */
    checkRight(right) {
        if (!this.currentUser)
            return false;
        // cas particulier (copier sur le client lourd)
        switch (right) {
            case 'Display.Left':
                return this.currentUser.checkRight("Display.Left.Synoptic") ||
                    this.currentUser.checkRight("Display.Left.Area") ||
                    this.currentUser.checkRight("Display.Left.Group") ||
                    this.currentUser.checkRight("Display.Left.Layout") ||
                    this.currentUser.checkRight("Display.Left.Standard") ||
                    this.currentUser.checkRight("Display.Left.Cycle") ||
                    this.currentUser.checkRight("Display.Left.Video");
            case "Display.Right":
                return this.currentUser.checkRight("Display.Right.Video") || this.currentUser.checkRight("Display.Right.Audio");
            case "Display.Left.Synoptic":
                return this.currentUser.checkRight(right) && this.currentUser.checkRight("Display.Synoptic");
            case "Display.Left.Layout":
                return this.currentUser.checkRight(right) && this.currentUser.checkRight("Client.ChangeLayout");
            case "Display.Left.Cycle":
                return this.currentUser.checkRight(right) && this.currentUser.checkRight("Client.LoadCycle");
            case "Display.Left.Video":
                return this.currentUser.checkRight(right) && this.currentUser.checkRight("Video.Live");
            case "Video.PlaybackOnAlarm":
                return this.currentUser.checkRight("Video.PlaybackOnAlarm") || this.currentUser.checkRight("Video.Playback");
            case "Video.Ptz":
                return this.currentUser.checkRight("Video.PtzMove") || this.currentUser.checkRight("Video.PtzGotoPreset") || this.currentUser.checkRight("Video.PtzRunPattern");
            case "MenuAdministration":
                return this.currentUser.checkRight("Configure.User") || this.currentUser.checkRight("Server.Maintenance");
            default:
        }
        return this.currentUser.checkRight(right);
    }
    /**
     * Change pasword of an user
     * @param username Username
     * @param oldPassword Old password
     * @param newPassword New password
     */
    changePassword(username, oldPassword, newPassword) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.post('AppVisionService.svc/ChangePassword', JSON.stringify([
                { Name: "username", Value: username },
                { Name: "oldpassword", Value: oldPassword },
                { Name: "newpassword", Value: newPassword },
            ]), "POST", null);
        });
    }
    /** @internal */
    loadInternal() {
        return __awaiter(this, void 0, void 0, function* () {
            // Load current user
            const userJson = yield this.http.getAsJson('AppVisionService.svc/GetCurrentUser');
            this.currentUser = new userRow_1.UserRow(userJson);
            // Load current user profile
            const profileJson = yield this.http.getAsJson('AppVisionService.svc/GetProfileById?id=' + this.currentUser.ProfileId);
            this.currentUser.profile = new profileRow_1.ProfileRow(profileJson);
            // Load all users
            const all = yield this.getAll();
            this.rowsByName = new Map();
            this.rowsById = new Map();
            for (const r of all) {
                const row = new userRow_1.UserRow(r);
                this.rowsByName.set(r.Name, row);
                this.rowsById.set(r.Id, row);
            }
        });
    }
    /** @internal */
    updateStateInternal(state) {
        this.currentUser.State = state;
        this.stateChanged.next(state);
    }
    constructRow(args) {
        return new userRow_1.UserRow(args);
    }
}
exports.UserManager = UserManager;
