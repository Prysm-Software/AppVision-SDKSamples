export type AppHandler = () => void;
export type AppReturnHandler<E> = () => E;
export type AppEventHandler<E> = (event: E) => void;
export type AppEventReturnHandler<E, T> = (event: E) => T;
