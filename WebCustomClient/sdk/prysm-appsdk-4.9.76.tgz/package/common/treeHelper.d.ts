import { TreeItem } from "../data/treeItem";
import { TreeRow } from "../data/treeRow";
interface FieldOptions {
    nameField: string;
    childrenField: string;
    nameSeparator: string;
}
export declare class TreeHelper {
    /**
     * Build a tree from a list of string
     * @param rows flat array of string
     * @param separator separator in string (default: '\\')
     * @returns TreeItem array
     */
    static buildTree(paths: string[], separator?: string): TreeItem[];
    /**
     * Build tree from a flat array of treerow
     * @param rows flat array of tree row
     * @param separator separator in name (default: '.')
     * @returns Tree array
     */
    static buildTreeRow<T extends TreeRow>(rows: T[], separator?: string): T[];
    /**
     * Insert or update an item inside a tree
     * @param rows tree
     * @param newRow row to update/add
     * @param options fields on rows
     */
    static insertOrUpdateItemInTree(rows: any[], newRow: any, options: FieldOptions): void;
    /**
     * Search an item by it's id inside a tree
     * @param rows tree
     * @param searchValue search value
     * @param searchFieldName Name of the search field inside T object
     * @param childrenFieldName Name of the children field inside T object
     * @returns TreeRow or null
     */
    static searchItemInTree<T>(rows: T[], searchValue: any, searchFieldName: string, childrenFieldName: string): T;
    /**
     * Return a deep clone of a TreeRow array (Clone parent and items too)
     * @param rows
     * @param ctor
     * @returns Cloned array of TreeRow
     */
    static deepCloneTreeRow<T extends TreeRow>(rows: T[], ctor: (new (c: T) => T)): T[];
    private static insertOrUpdateItemInTreePrv;
}
export {};
