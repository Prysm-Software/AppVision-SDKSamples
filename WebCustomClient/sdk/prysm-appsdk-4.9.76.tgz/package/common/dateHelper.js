"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DateHelper = void 0;
class DateHelper {
    static toJSDate(date) {
        let str = date.DateTime.split(")").shift();
        str = str.split("Date(").pop();
        const newDate = new Date(parseInt(str));
        if (newDate > new Date(1900, 0, 2))
            return newDate;
        return null;
    }
    static strToJSDate(date) {
        if (!date)
            return null;
        let str = date.split("+").shift();
        str = str.split("Date(").pop();
        const newDate = new Date(parseInt(str));
        if (newDate > new Date(1900, 0, 2))
            return newDate;
        return null;
    }
    static stringToDate(dateStr) {
        return new Date(Date.parse(dateStr));
    }
    static toDateTimeString(date) {
        if (date == null)
            return "";
        let dd = date.getDate();
        let mm = date.getMonth() + 1; //January is 0!
        let yyyy = date.getFullYear();
        let h = date.getHours();
        let m = date.getMinutes();
        let s = date.getSeconds();
        if (dd < 10)
            dd = '0' + dd;
        if (mm < 10)
            mm = '0' + mm;
        if (h < 10)
            h = '0' + h;
        if (m < 10)
            m = '0' + m;
        if (s < 10)
            s = '0' + s;
        return yyyy + '-' + mm + '-' + dd + 'T' + h + ':' + m + ':' + s;
    }
    static toDateString(date) {
        if (date == null)
            return "";
        let dd = date.getDate();
        let mm = date.getMonth() + 1; //January is 0!
        let yyyy = date.getFullYear();
        if (dd < 10)
            dd = '0' + dd;
        if (mm < 10)
            mm = '0' + mm;
        return yyyy + '-' + mm + '-' + dd;
    }
    static today() {
        const now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    }
    /**
     * Converts a given datetime splited in a date part and an optional time part in the ecma date time string format
     * @param date Part of the datetime representing the date
     * @param time Part of the datetime representing the time
     * @param meridiem Value of the meridiem: "AM" or "PM" or undefined, default: undefined
     * @param dateSeparator Separator for the date part: "/" or "-" or anything, default: "/"
     * @param timeSeparator Separator for the time part: ":" or "-" or anything, default: ":"
     * @returns A datetime string formated in the ecma date time string format (a simplification of ISO 8601)
     */
    static toEcmaDateTimeStringFormat(date, time, meridiem = undefined, dateSeparator = "/", timeSeparator = ":") {
        const dateSplit = date.split(dateSeparator);
        if (dateSplit.length !== 3)
            throw new Error("Invalid date part or date separator");
        const timeSplit = time.split(timeSeparator);
        if (timeSplit.length !== 3)
            throw new Error("Invalid time part or time separator");
        const isMonthFirst = meridiem ? true : false;
        const pm = isMonthFirst && meridiem.trim().toLowerCase() === "pm" ? true : false;
        const am = isMonthFirst ? !pm : false;
        const year = dateSplit[2].length === 4 ? dateSplit[2] : "20" + dateSplit[2];
        var month = isMonthFirst ? dateSplit[0] : dateSplit[1];
        if (month.length === 1)
            month = "0" + month;
        var day = isMonthFirst ? dateSplit[1] : dateSplit[0];
        if (day.length === 1)
            day = "0" + day;
        if (!time)
            return year + "-" + month + "-" + day;
        var hour = (am || pm) ? (am ? timeSplit[0] : (parseInt(timeSplit[0]) + 12).toString()) : timeSplit[0];
        if (hour.length === 1)
            hour = "0" + hour;
        return year + "-" + month + "-" + day + "T" + hour + ":" + timeSplit[1] + ":" + timeSplit[2];
    }
    static isWcfDateString(value) {
        return typeof value === 'string' && /^\/Date\((\d+)([+-]\d{4})?\)\/$/.test(value);
    }
    static isNumericString(value) {
        return typeof value === 'string' && /^[0-9]+$/.test(value);
    }
}
exports.DateHelper = DateHelper;
_a = DateHelper;
/**
 * Converts a JavaScript Date, ISO date string, or timestamp (ms since epoch)
 * into the WCF-compatible JSON date format: `/Date(<milliseconds>)/`.
 *
 * This format is required by WCF servers using DataContractJsonSerializer.
 *
 * @param date The input value to convert. Can be a Date object,
 *             an ISO date string, or a numeric timestamp in milliseconds.
 * @returns A string formatted as `/Date(<milliseconds>)/`,
 *          ready to be serialized for a WCF JSON payload.
 */
DateHelper.toWcfDate = (date) => {
    // Idempotence: if already WCF string, return as-is.
    if (_a.isWcfDateString(date)) {
        return date;
    }
    let ms;
    if (typeof date === 'number') {
        ms = date;
    }
    else if (typeof date === 'string') {
        if (_a.isNumericString(date)) {
            ms = Number(date);
        }
        else {
            // ISO or other string that Date can parse
            ms = new Date(date).getTime();
        }
    }
    else if (date instanceof Date) {
        ms = date.getTime();
    }
    else {
        throw new Error(`[toWcfDate] unexpected value: ${String(date)}`);
    }
    if (!Number.isFinite(ms)) {
        throw new Error(`[toWcfDate] invalid date: ${String(date)}`);
    }
    return `/Date(${ms})/`;
};
/**
 * Converts a JavaScript Date into a WCF-compatible DateTimeOffset structure.
 *
 * The returned object includes:
 *   - `DateTime`: a `/Date(ms)/` string (WCF JSON date format)
 *   - `OffsetMinutes`: the local timezone offset relative to UTC,
 *     expressed in minutes (calculated as `-date.getTimezoneOffset()`).
 *
 * This format matches the expected JSON structure for .NET DateTimeOffset.
 *
 * @param date The JavaScript Date to convert.
 * @returns An object containing the WCF-formatted date and timezone offset.
 */
DateHelper.toWcfDateTimeOffset = (date) => {
    // Accept Date | string | number
    if (_a.isWcfDateString(date)) {
        // When a WCF string is already provided, we still need a consistent offset.
        // We cannot reconstruct the instant from "/Date(ms)/" without parsing ms.
        // Parse ms:
        const ms = Number(date.match(/\d+/)[0]);
        const d = new Date(ms);
        return {
            DateTime: date,
            OffsetMinutes: -d.getTimezoneOffset(),
        };
    }
    const d = date instanceof Date
        ? date
        : _a.isNumericString(date)
            ? new Date(Number(date))
            : new Date(date);
    if (!(d instanceof Date) || !Number.isFinite(d.getTime())) {
        throw new Error(`[toWcfDateTimeOffset] invalid date: ${String(date)}`);
    }
    return {
        DateTime: DateHelper.toWcfDate(d),
        OffsetMinutes: -d.getTimezoneOffset(),
    };
};
