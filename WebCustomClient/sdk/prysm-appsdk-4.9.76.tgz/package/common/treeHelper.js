"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeHelper = void 0;
const helper_1 = require("./helper");
const stringHelper_1 = require("./stringHelper");
class TreeHelper {
    /**
     * Build a tree from a list of string
     * @param rows flat array of string
     * @param separator separator in string (default: '\\')
     * @returns TreeItem array
     */
    static buildTree(paths, separator = '\\') {
        const result = [];
        paths.reduce((r, path) => {
            path.split(separator).reduce((o, name) => {
                let temp = (o.items = o.items || []).find((q) => q.name === name);
                if (!temp) {
                    temp = {
                        name,
                        fullName: o.fullName ? o.fullName + separator + name : name,
                        items: []
                    };
                    o.items.push(temp);
                }
                return temp;
            }, r);
            return r;
        }, { items: result });
        return result;
    }
    /**
     * Build tree from a flat array of treerow
     * @param rows flat array of tree row
     * @param separator separator in name (default: '.')
     * @returns Tree array
     */
    static buildTreeRow(rows, separator = '.') {
        const map = new Map();
        rows.forEach(row => {
            map.set(row.Name, row);
            // clear relationship
            row.items = [];
            row.parent = null;
        });
        rows.filter(row => row.Name.includes(separator))
            .forEach(row => {
            const parentName = stringHelper_1.StringHelper.getParentName(row.Name, separator);
            const parent = map.get(parentName);
            if (parent) {
                row.parent = parent;
                if (!parent.items)
                    parent.items = [];
                parent.items.push(row);
            }
        });
        return rows.filter(a => a.parent == null);
    }
    /**
     * Insert or update an item inside a tree
     * @param rows tree
     * @param newRow row to update/add
     * @param options fields on rows
     */
    static insertOrUpdateItemInTree(rows, newRow, options) {
        this.insertOrUpdateItemInTreePrv(rows, newRow, options);
    }
    /**
     * Search an item by it's id inside a tree
     * @param rows tree
     * @param searchValue search value
     * @param searchFieldName Name of the search field inside T object
     * @param childrenFieldName Name of the children field inside T object
     * @returns TreeRow or null
     */
    static searchItemInTree(rows, searchValue, searchFieldName, childrenFieldName) {
        let row = rows.find(r => helper_1.Helper.getObjectPropValue(r, searchFieldName) === searchValue);
        if (row)
            return row;
        for (let i = 0; i < rows.length; i++) {
            const children = helper_1.Helper.getObjectPropValue(rows[i], childrenFieldName);
            if (children && children.length > 0) {
                row = this.searchItemInTree(children, searchValue, searchFieldName, childrenFieldName);
                if (row)
                    return row;
            }
        }
    }
    /**
     * Return a deep clone of a TreeRow array (Clone parent and items too)
     * @param rows
     * @param ctor
     * @returns Cloned array of TreeRow
     */
    static deepCloneTreeRow(rows, ctor) {
        const tmp = [];
        rows.forEach((a) => {
            const tmpArea = new ctor(a);
            tmp.push(tmpArea);
            if (a.parent) {
                tmpArea.parent = new ctor(a);
            }
            if (a.items && a.items.length > 0) {
                tmpArea.items = this.deepCloneTreeRow(a.items, ctor);
            }
        });
        return tmp;
    }
    static insertOrUpdateItemInTreePrv(rows, newRow, options, currentLevel = 1) {
        const newRowName = helper_1.Helper.getObjectPropValue(newRow, options.nameField).toLowerCase();
        const level = newRowName.split(options.nameSeparator).length;
        if (currentLevel === level) {
            const i = rows.findIndex(r => helper_1.Helper.getObjectPropValue(r, options.nameField).toLowerCase() === newRowName);
            if (i >= 0) {
                rows[i] = newRow;
            }
            else {
                rows.push(newRow);
            }
            return true;
        }
        else {
            const currentLevelName = newRowName.split(options.nameSeparator).slice(0, currentLevel).join(options.nameSeparator);
            const parent = rows.find(r => currentLevelName === helper_1.Helper.getObjectPropValue(r, options.nameField).toLowerCase());
            if (parent) {
                const nextLevel = helper_1.Helper.getObjectPropValue(parent, options.nameField).split(options.nameSeparator).length + 1;
                let children = helper_1.Helper.getObjectPropValue(parent, options.childrenField);
                if (children == null) {
                    helper_1.Helper.setObjectPropValue(parent, options.childrenField, []);
                    children = parent[options.childrenField];
                }
                return this.insertOrUpdateItemInTreePrv(children, newRow, options, nextLevel);
            }
        }
        return false;
    }
}
exports.TreeHelper = TreeHelper;
