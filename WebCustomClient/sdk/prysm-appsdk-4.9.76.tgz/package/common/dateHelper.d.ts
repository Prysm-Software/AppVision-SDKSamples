import { DateTimeOffset } from "../data/dateTimeOffset";
export declare abstract class DateHelper {
    static toJSDate(date: DateTimeOffset): Date;
    static strToJSDate(date: string): Date;
    static stringToDate(dateStr: string): Date;
    static toDateTimeString(date: Date): string;
    static toDateString(date: Date): string;
    static today(): Date;
    /**
     * Converts a given datetime splited in a date part and an optional time part in the ecma date time string format
     * @param date Part of the datetime representing the date
     * @param time Part of the datetime representing the time
     * @param meridiem Value of the meridiem: "AM" or "PM" or undefined, default: undefined
     * @param dateSeparator Separator for the date part: "/" or "-" or anything, default: "/"
     * @param timeSeparator Separator for the time part: ":" or "-" or anything, default: ":"
     * @returns A datetime string formated in the ecma date time string format (a simplification of ISO 8601)
     */
    static toEcmaDateTimeStringFormat(date: string, time?: string, meridiem?: string, dateSeparator?: string, timeSeparator?: string): string;
    static isWcfDateString(value: unknown): value is string;
    static isNumericString(value: unknown): value is string;
    /**
     * Converts a JavaScript Date, ISO date string, or timestamp (ms since epoch)
     * into the WCF-compatible JSON date format: `/Date(<milliseconds>)/`.
     *
     * This format is required by WCF servers using DataContractJsonSerializer.
     *
     * @param date The input value to convert. Can be a Date object,
     *             an ISO date string, or a numeric timestamp in milliseconds.
     * @returns A string formatted as `/Date(<milliseconds>)/`,
     *          ready to be serialized for a WCF JSON payload.
     */
    static toWcfDate: (date: Date | string | number) => string;
    /**
     * Converts a JavaScript Date into a WCF-compatible DateTimeOffset structure.
     *
     * The returned object includes:
     *   - `DateTime`: a `/Date(ms)/` string (WCF JSON date format)
     *   - `OffsetMinutes`: the local timezone offset relative to UTC,
     *     expressed in minutes (calculated as `-date.getTimezoneOffset()`).
     *
     * This format matches the expected JSON structure for .NET DateTimeOffset.
     *
     * @param date The JavaScript Date to convert.
     * @returns An object containing the WCF-formatted date and timezone offset.
     */
    static toWcfDateTimeOffset: (date: Date | string | number) => {
        DateTime: string;
        OffsetMinutes: number;
    };
}
