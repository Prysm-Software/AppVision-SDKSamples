export declare const DEFAULT_HTTP_TIMEOUT = 20000;
export declare abstract class HttpHelper {
    static fetchWithTimeout(uri: string, timeoutMs?: number, options?: RequestInit): Promise<Response>;
}
