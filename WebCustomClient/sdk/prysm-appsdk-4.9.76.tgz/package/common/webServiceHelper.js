"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebServiceHelper = void 0;
const helper_1 = require("./helper");
class WebServiceHelper {
    static cloneVariable(row) {
        const clone = helper_1.Helper.lightCloneObject(row);
        clone.GroupNames = row.GroupNames;
        return clone;
    }
}
exports.WebServiceHelper = WebServiceHelper;
