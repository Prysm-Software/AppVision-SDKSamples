import { VariableRow } from "../data/variableRow";
export declare class WebServiceHelper {
    static cloneVariable(row: VariableRow): VariableRow;
}
