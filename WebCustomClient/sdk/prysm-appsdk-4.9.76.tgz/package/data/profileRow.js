"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfileExtension = exports.ProfileRow = void 0;
const helper_1 = require("../common/helper");
const xmlParser_1 = require("../common/xmlParser");
class ProfileRow {
    constructor(user) {
        Object.assign(this, user);
        this.options = {};
        if (this.DbOptions) {
            this.DbOptions
                .split(/[\r\n]/)
                .filter(a => a)
                .map(l => l.split('='))
                .forEach(i => this.options[i[0]] = i[1]);
        }
    }
    get filters() { return this.Filters ? this.Filters.split(',') : []; }
    get rights() { return this.DbRoles ? this.DbRoles.split(',') : []; }
    get filterGroups() { return this.Filters.split(',').filter(s => s.startsWith("$G.")).map(s => s.substring(3)); }
    get filterAreas() { return this.Filters.split(',').filter(s => s.startsWith("$A.")).map(s => s.substring(3)); }
    checkArea(areaName) {
        return this.checkFilterByName(this.filterAreas, areaName);
    }
    checkGroup(groupName) {
        return this.checkFilterByName(this.filterGroups, groupName);
    }
    /**
     * Check if the profile has filter on an area or a group
     * @param filters Area or group name starting with $A. or $G.
     * @returns Boolean
     */
    checkFilter(filter) {
        if (filter.startsWith("$A."))
            return this.checkArea(filter.substring(3));
        if (filter.startsWith("$G."))
            return this.checkGroup(filter.substring(3));
        // ne prend pas en compte le filtre sur la gravité et les filtres fonctionnels dans la notion d'infériorité de profil
        return true;
    }
    checkRight(right) {
        return this.IsAdmin || this.rights.indexOf(right) > -1;
    }
    checkCommandException(command) {
        if (!command || !this.CommandExceptions)
            return false;
        const ss = command.split('=');
        const operand = ss[0];
        const commands = this.CommandExceptions.replace(" ", "").replace("=*", "").split(/\n|\r/).filter(s => s);
        // test sur la correspondance exact, quand l'autorisation a été faite sur un état
        if (commands.indexOf(command) > -1)
            return true;
        // test sur la variable
        if (commands.indexOf(operand) > -1)
            return true;
        // cas des exceptions avec caractères génériques
        for (const c of commands) {
            if (c.indexOf('*') > -1) {
                const reg = new RegExp(helper_1.Helper.convertRegExpPattern(c));
                // test sur la variable et l'état
                if (reg.test(command))
                    return true;
                // test sur la variable
                if (reg.test(operand))
                    return true;
            }
        }
        return false;
    }
    addRight(rightName) {
        if (this.rights.indexOf(rightName) < 0) {
            const copy = [...this.rights, rightName];
            this.DbRoles = copy.join(',');
        }
    }
    removeRight(rightName) {
        const index = this.rights.indexOf(rightName);
        if (index >= 0) {
            const copy = [...this.rights];
            copy.splice(index, 1);
            this.DbRoles = copy.join(',');
        }
    }
    addFilter(filter) {
        if (this.filters.indexOf(filter) < 0) {
            const copy = [...this.filters, filter];
            this.Filters = copy.join(',');
        }
    }
    removeFilter(filter) {
        const index = this.filters.indexOf(filter);
        if (index >= 0) {
            const copy = [...this.filters];
            copy.splice(index, 1);
            this.Filters = copy.join(',');
        }
    }
    getFilterValue(filter) {
        const f = this.filters.find(f => f.startsWith(filter + "="));
        return f ? f.split('=').pop() : null;
    }
    /**
     * Get Extension field as ProfileExtension object
     * @returns ProfileExtension
     */
    getExtension() {
        var _a, _b, _c, _d;
        if (!this.Extension)
            return new ProfileExtension({});
        const parser = new xmlParser_1.XmlParser();
        const xml = parser.parseFromString(this.Extension);
        return new ProfileExtension({
            CommandExceptions: (_a = xml.getElementsByTagName("CommandExceptions")[0]) === null || _a === void 0 ? void 0 : _a.value,
            ServerName: (_b = xml.getElementsByTagName("ServerName")[0]) === null || _b === void 0 ? void 0 : _b.value,
            UserId: helper_1.Helper.parseInt((_c = xml.getElementsByTagName('UserId')[0]) === null || _c === void 0 ? void 0 : _c.value),
            UserName: (_d = xml.getElementsByTagName("UserName")[0]) === null || _d === void 0 ? void 0 : _d.value
        });
    }
    /**
     * Save the given profile extension into Extension field
     * @param ext ProfileExtension
     */
    setExtension(ext) {
        const xml = '<ProfileExtension xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
            '<ServerName>' + (ext.ServerName || '') + '</ServerName>' +
            '<UserId>' + (ext.UserId || '') + '</UserId>' +
            '<UserName>' + (ext.UserName || '') + '</UserName>' +
            '<CommandExceptions>' + (ext.CommandExceptions || '') + '</CommandExceptions>' +
            '</ProfileExtension>';
        this.Extension = xml;
    }
    checkFilterByName(filters, name) {
        if (filters.length == 0 || filters.some(x => x === name))
            return true;
        filters.forEach(element => {
            if (name.startsWith(element + "."))
                return true;
        });
        return false;
    }
}
exports.ProfileRow = ProfileRow;
class ProfileExtension {
    constructor(row) {
        Object.assign(this, row);
    }
}
exports.ProfileExtension = ProfileExtension;
