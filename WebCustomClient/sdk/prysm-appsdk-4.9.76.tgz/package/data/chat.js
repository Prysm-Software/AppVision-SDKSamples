"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Talk = exports.ChatMessage = void 0;
const dateHelper_1 = require("../common/dateHelper");
class ChatMessage {
    get date() {
        return dateHelper_1.DateHelper.toJSDate(this.Date);
    }
    constructor(msg) {
        Object.assign(this, msg);
    }
}
exports.ChatMessage = ChatMessage;
class Talk {
    get createdDate() {
        return dateHelper_1.DateHelper.toJSDate(this.CreatedDate);
    }
    constructor(talk) {
        Object.assign(this, talk);
        if (talk.LastMessage) {
            this.LastMessage = new ChatMessage(talk.LastMessage);
        }
    }
}
exports.Talk = Talk;
