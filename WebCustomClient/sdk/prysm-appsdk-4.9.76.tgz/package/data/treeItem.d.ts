export declare class TreeItem {
    name: string;
    fullName: string;
    items: TreeItem[];
}
