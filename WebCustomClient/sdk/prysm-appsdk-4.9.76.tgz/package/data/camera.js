"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Camera = exports.CameraMode = void 0;
const dateHelper_1 = require("../common/dateHelper");
const httpService_1 = require("../services/httpService");
const helper_1 = require("../common/helper");
var CameraMode;
(function (CameraMode) {
    CameraMode[CameraMode["Live"] = 0] = "Live";
    CameraMode[CameraMode["Playback"] = 1] = "Playback";
})(CameraMode = exports.CameraMode || (exports.CameraMode = {}));
class Camera {
    /**
     * Uri of the camera streamer
     */
    get streamerUri() { return this.streamerHttp.host; }
    /**
     * Current stream quality. Can be Low or High.
     */
    get streamQuality() { return this.stream; }
    constructor(http, options) {
        var _a;
        this.http = http;
        this.sessionId = helper_1.Helper.guid();
        this.mode = CameraMode.Live;
        this.row = options.row;
        this.playbackSpeed = (_a = options === null || options === void 0 ? void 0 : options.speed) !== null && _a !== void 0 ? _a : 1;
        this.stream = options === null || options === void 0 ? void 0 : options.stream;
        if ((options === null || options === void 0 ? void 0 : options.start) != null) {
            this.dateStart = options.start;
            this.mode = CameraMode.Playback;
        }
    }
    /**
     * Connect to the video gateway and get the source infos: (videoFormat, protocols supported for video streaming, ptz caps, playback caps) on this camera
     * @returns CameraSourceInfos
     */
    connect() {
        return __awaiter(this, void 0, void 0, function* () {
            let uri = 'videogateway/streaming?video=' + this.row.Name + '&id=' + this.sessionId;
            if (this.dateStart) {
                uri += '&date=' + dateHelper_1.DateHelper.toDateTimeString(this.dateStart);
            }
            if (this.stream != null) {
                uri += "&stream=" + this.stream;
            }
            let resp = yield this.http.get(uri);
            let json = yield resp.json();
            // If the server is not the same as the gateway, we need to use the server uri to build the streamer uri
            const streamerBaseUrl = json.server.id > 0 ? json.server.uri : resp.url;
            this.streamerHttp = new httpService_1.HttpService(new URL(json.streamer, streamerBaseUrl).href, this.http.getHeaders());
            // On met un long timeout car la connexion entre la gateway et la caméra peut prendre du temps
            resp = yield this.streamerHttp.get('sourceinfo', null, true, 60000);
            json = yield resp.json();
            this.sourceInfos = json;
            return this.sourceInfos;
        });
    }
    /**
     * Build stream uri and returns it
     * @param options Options of the uri
     * @returns Uri
     */
    getStreamingUri(options = null) {
        if (options) {
            let parameters = "";
            const host = options.protocol === "WebSocket" ? this.streamerHttp.host.replace("http", 'ws') : this.streamerHttp.host;
            if (options.httpMultipartType != null)
                parameters += "&multipart_content_type=" + options.httpMultipartType;
            if (options.sendFrameExtraData)
                parameters += "&sendFrameExtraData=" + options.sendFrameExtraData;
            return host + "video?id=" + this.sessionId + parameters;
        }
        return this.streamerHttp.host + "video?id=" + this.sessionId;
    }
    /**
     * Get current info of the stream (current time, status...)
     * @returns CameraStreamInfo
     */
    getStreamInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.streamerHttp.get('streaminfo/?id=' + this.sessionId + '&rnd=' + new Date().getTime());
            const json = yield resp.json();
            return json;
        });
    }
    continuousMove(x, y) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=continuousmove&x=" + x + "&y=" + y);
        });
    }
    continuousZoom(z) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=continuouszoom&z=" + z);
        });
    }
    getPresets() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=getpresets");
            const json = yield resp.json();
            return json;
        });
    }
    getPatterns() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=getpatterns");
            const json = yield resp.json();
            return json;
        });
    }
    gotoPreset(preset) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=gotopreset&preset=" + preset);
        });
    }
    runPattern(pattern) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=runpattern&pattern=" + pattern);
        });
    }
    goToHome() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('ptz/?id=' + this.sessionId + "&command=gotohomeposition");
        });
    }
    setPlaybackPosition(date) {
        return __awaiter(this, void 0, void 0, function* () {
            this.dateStart = date;
            yield this.streamerHttp.get('playback/?id=' + this.sessionId + "&command=playbackposition&date=" + dateHelper_1.DateHelper.toDateTimeString(this.dateStart));
        });
    }
    setPlaybackSpeed(speed) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('playback/?id=' + this.sessionId + "&command=playbackspeed&speed=" + speed);
            this.playbackSpeed = speed;
        });
    }
    resume() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('video/?id=' + this.sessionId + "&command=resume");
        });
    }
    pause() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('video/?id=' + this.sessionId + "&command=pause");
        });
    }
    stepBackward() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('playback/?id=' + this.sessionId + "&command=stepBackward");
        });
    }
    stepForward() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.streamerHttp.get('playback/?id=' + this.sessionId + "&command=stepForward");
        });
    }
    snapshot() {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield this.streamerHttp.get('video/?id=' + this.sessionId + "&command=snapshot");
            const blob = yield resp.blob();
            return blob;
        });
    }
}
exports.Camera = Camera;
