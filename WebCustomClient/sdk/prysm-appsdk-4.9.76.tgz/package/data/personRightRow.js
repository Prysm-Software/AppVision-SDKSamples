"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonRightRow = void 0;
const dateHelper_1 = require("../common/dateHelper");
class PersonRightRow {
    get validityStart() {
        return dateHelper_1.DateHelper.stringToDate(this.ValidityStart);
    }
    get validityEnd() {
        return dateHelper_1.DateHelper.stringToDate(this.ValidityEnd);
    }
    constructor(p) {
        this.ValidityStart = '';
        this.ValidityEnd = '';
        this.ValidityInfo = '';
        Object.assign(this, p);
    }
}
exports.PersonRightRow = PersonRightRow;
