"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstructionRow = void 0;
class InstructionRow {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.InstructionRow = InstructionRow;
