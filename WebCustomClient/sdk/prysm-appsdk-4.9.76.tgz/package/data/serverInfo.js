"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerInfo = void 0;
class ServerInfo {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.ServerInfo = ServerInfo;
