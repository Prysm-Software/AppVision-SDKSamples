"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BadgeRow = void 0;
const helper_1 = require("../common/helper");
const personRow_1 = require("./personRow");
class BadgeRow {
    constructor(b) {
        var _a, _b, _c, _d, _e, _f;
        this.Code = (_a = b === null || b === void 0 ? void 0 : b.Code) !== null && _a !== void 0 ? _a : '';
        this.Format = (_b = b === null || b === void 0 ? void 0 : b.Format) !== null && _b !== void 0 ? _b : '';
        this.Info = (_c = b === null || b === void 0 ? void 0 : b.Info) !== null && _c !== void 0 ? _c : '';
        this.Status = (_d = b === null || b === void 0 ? void 0 : b.Status) !== null && _d !== void 0 ? _d : 0;
        this.BadgeTypeId = (_e = b === null || b === void 0 ? void 0 : b.BadgeTypeId) !== null && _e !== void 0 ? _e : 0;
        this.PersonId = (_f = b === null || b === void 0 ? void 0 : b.PersonId) !== null && _f !== void 0 ? _f : null;
        if (b.Person)
            this.Person = new personRow_1.PersonRow(b.Person);
    }
    /**
     * Set the status of the BadgeRow instance
     * @param status New status
     */
    setStatus(status) {
        var _a, _b;
        this.Status = status;
        if (status === 0) {
            // badge actif
            const personId = helper_1.Helper.parseInt((_b = (_a = this.Info) === null || _a === void 0 ? void 0 : _a.match(/\((\d+)\)/)) === null || _b === void 0 ? void 0 : _b[1], null); // "lastname firstname (id)"
            if (personId)
                this.PersonId = personId;
        }
        else {
            // retire la personne des badges volés, perdus...
            if (this.Person)
                this.Info = `${this.Person.LastName} ${this.Person.FirstName} (${this.Person.Id})`;
            this.PersonId = null;
        }
    }
}
exports.BadgeRow = BadgeRow;
