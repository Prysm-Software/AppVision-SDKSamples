"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserExtension = exports.UserRow = void 0;
const dateHelper_1 = require("../common/dateHelper");
const helper_1 = require("../common/helper");
const xmlParser_1 = require("../common/xmlParser");
const userState_1 = require("./userState");
class UserRow {
    constructor(user) {
        Object.assign(this, user);
        if (user.State)
            this.State = new userState_1.UserState(user.State);
        this.options = {};
        if (this.DbOptions)
            this.DbOptions
                .split(/[\r\n]/)
                .filter(a => a)
                .map(l => l.split('='))
                .forEach(i => this.options[i[0]] = i[1]);
    }
    get rights() {
        return this.DbRoles ? this.DbRoles.split(',') : [];
    }
    get fullName() {
        return (this.FirstName ? this.FirstName + ' ' : '') + this.LastName;
    }
    set passwordDate(d) {
        this.PasswordDate = "/Date(" + d.getTime() + ")/";
    }
    get passwordDate() {
        return dateHelper_1.DateHelper.strToJSDate(this.PasswordDate);
    }
    get createDate() {
        return dateHelper_1.DateHelper.strToJSDate(this.CreateDate);
    }
    get validityStart() {
        return dateHelper_1.DateHelper.strToJSDate(this.ValidityStart);
    }
    set validityStart(d) {
        this.ValidityStart = "/Date(" + d.getTime() + ")/";
    }
    get validityEnd() {
        return dateHelper_1.DateHelper.strToJSDate(this.ValidityEnd);
    }
    set validityEnd(d) {
        this.ValidityEnd = "/Date(" + d.getTime() + ")/";
    }
    getParameter(paramName) {
        return helper_1.Helper.getParameter(paramName, this.Parameters);
    }
    checkRight(right, commandException = "") {
        if (this.rights.indexOf(right) > -1)
            return true;
        if (this.profile) {
            if (this.profile.checkRight(right))
                return true;
            if (this.profile.checkCommandException(commandException))
                return true;
        }
        return false;
    }
    /**
     * Get Extension field as UserExtension object
     * @returns UserExtension
     */
    getExtension() {
        var _a, _b, _c, _d;
        if (!this.Extension)
            return new UserExtension({});
        const parser = new xmlParser_1.XmlParser();
        const xml = parser.parseFromString(this.Extension);
        return new UserExtension({
            UserType: helper_1.Helper.parseInt((_a = xml.getElementsByTagName("UserType")[0]) === null || _a === void 0 ? void 0 : _a.value),
            ServerName: (_b = xml.getElementsByTagName("ServerName")[0]) === null || _b === void 0 ? void 0 : _b.value,
            UserId: helper_1.Helper.parseInt((_c = xml.getElementsByTagName('UserId')[0]) === null || _c === void 0 ? void 0 : _c.value),
            UserName: (_d = xml.getElementsByTagName("UserName")[0]) === null || _d === void 0 ? void 0 : _d.value
        });
    }
    /**
     * Save the given profile extension into Extension field
     * @param ext UserExtension
     */
    setExtension(ext) {
        const xml = '<UserExtension xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
            '<ServerName>' + (ext.ServerName || '') + '</ServerName>' +
            '<UserId>' + (ext.UserId || 0) + '</UserId>' +
            '<UserName>' + (ext.UserName || '') + '</UserName>' +
            '<UserType>' + (ext.UserType || '') + '</UserType>' +
            '</UserExtension>';
        this.Extension = xml;
    }
}
exports.UserRow = UserRow;
class UserExtension {
    constructor(row) {
        Object.assign(this, row);
    }
}
exports.UserExtension = UserExtension;
