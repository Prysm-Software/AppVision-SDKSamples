"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AreaExtension = exports.AreaRow = void 0;
const treeRow_1 = require("./treeRow");
const areaState_1 = require("./areaState");
const xmlParser_1 = require("../common/xmlParser");
const helper_1 = require("../common/helper");
class AreaRow extends treeRow_1.TreeRow {
    constructor(row) {
        super(row);
        this.Icon = row.Icon;
        this.Parameters = row.Parameters;
        this.Extension = row.Extension;
        this.Url = row.Url;
        this.CustomExtension = row.CustomExtension;
        this.CustomField1 = row.CustomField1;
        this.CustomField2 = row.CustomField2;
        this.CustomField3 = row.CustomField3;
        this.CustomField4 = row.CustomField4;
        this.CustomField5 = row.CustomField5;
        this.Synoptic = row.Synoptic;
        this.Sound = row.Sound;
        this.SiteInfo = row.SiteInfo;
        this.ColorInfo = row.ColorInfo;
        this.FullSynoptic = row.FullSynoptic;
        this.FullParameters = row.FullParameters;
        this.FullSound = row.FullSound;
        this.State = row.State || new areaState_1.AreaState({ Id: this.Id });
    }
    /**
     * Get Extension field as AreaExtension object
     * @returns AreaExtension
     */
    getExtension() {
        var _a, _b, _c, _d;
        if (!this.Extension)
            return new AreaExtension({});
        const parser = new xmlParser_1.XmlParser();
        const xml = parser.parseFromString(this.Extension);
        return new AreaExtension({
            NotifyAndOrValue: helper_1.Helper.parseBool((_a = xml.getElementsByTagName("NotifyAndOrValue")[0]) === null || _a === void 0 ? void 0 : _a.value),
            ServerName: (_b = xml.getElementsByTagName("ServerName")[0]) === null || _b === void 0 ? void 0 : _b.value,
            UserId: helper_1.Helper.parseInt((_c = xml.getElementsByTagName('UserId')[0]) === null || _c === void 0 ? void 0 : _c.value),
            UserName: (_d = xml.getElementsByTagName("UserName")[0]) === null || _d === void 0 ? void 0 : _d.value
        });
    }
    /**
     * Save the given area extension into Extension field
     * @param ext AreaExtension
     */
    setExtension(ext) {
        const xml = '<AreaExtension xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
            '<ServerName>' + (ext.ServerName || '') + '</ServerName>' +
            '<UserId>' + (ext.UserId || '') + '</UserId>' +
            '<UserName>' + (ext.UserName || '') + '</UserName>' +
            '<NotifyAndOrValue>' + (ext.NotifyAndOrValue || '') + '</NotifyAndOrValue>' +
            '</AreaExtension>';
        this.Extension = xml;
    }
}
exports.AreaRow = AreaRow;
class AreaExtension {
    constructor(row) {
        Object.assign(this, row);
    }
}
exports.AreaExtension = AreaExtension;
