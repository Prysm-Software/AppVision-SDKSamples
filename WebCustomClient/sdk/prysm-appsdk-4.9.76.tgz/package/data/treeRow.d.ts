export declare class TreeRow {
    Id: number;
    Name: string;
    Description: string;
    FullDescription: string;
    parent: TreeRow;
    items: TreeRow[];
    constructor(row: Partial<TreeRow>);
    /**
     * Return the name of the parent
     */
    get parentName(): string;
    /**
     * Return true if id is a child of this
     * @param id
     * @returns bool
     */
    hasChild(id: number): boolean;
    /**
     * Build tree from a flat array of treerow
     * @param rows flat array of tree row
     * @param separator separator in name (default: '.')
     * @returns Tree array
     * @deprecated Use TreeHelper.buildTreeRow
     */
    static init<T extends TreeRow>(rows: T[], separator?: string): T[];
}
