import { TreeRow } from "./treeRow";
import { AreaState } from "./areaState";
export declare class AreaRow extends TreeRow {
    Icon: string;
    Parameters: string;
    Extension: string;
    Url: string;
    CustomExtension: string;
    CustomField1: string;
    CustomField2: string;
    CustomField3: string;
    CustomField4: string;
    CustomField5: string;
    Synoptic: string;
    Sound: string;
    SiteInfo: string;
    ColorInfo: string;
    FullSynoptic: string;
    FullParameters: string;
    FullSound: string;
    State: AreaState;
    constructor(row: Partial<AreaRow>);
    /**
     * Get Extension field as AreaExtension object
     * @returns AreaExtension
     */
    getExtension(): AreaExtension;
    /**
     * Save the given area extension into Extension field
     * @param ext AreaExtension
     */
    setExtension(ext: AreaExtension): void;
}
export declare class AreaExtension {
    ServerName: string;
    UserId: number;
    UserName: string;
    NotifyAndOrValue: boolean;
    constructor(row: Partial<AreaExtension>);
}
