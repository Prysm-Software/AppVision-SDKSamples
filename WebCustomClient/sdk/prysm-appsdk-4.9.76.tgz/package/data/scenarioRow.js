"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScenarioRow = void 0;
const scenarioState_1 = require("./scenarioState");
class ScenarioRow {
    constructor(row) {
        var _a;
        Object.assign(this, row);
        if (((_a = row.Instances) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            this.Instances = row.Instances.map(i => new scenarioState_1.ScenarioState(i));
        }
        else {
            this.Instances = [];
        }
    }
}
exports.ScenarioRow = ScenarioRow;
