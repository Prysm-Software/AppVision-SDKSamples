export declare enum UserMessageCategoryType {
    Text = "Text",
    TextMultiline = "TextMultiline",
    ComboBox = "ComboBox",
    Numeric = "Numeric",
    CheckBox = "CheckBox",
    Date = "Date",
    DateTime = "DateTime"
}
export declare class UserMessageCategory {
    Id: number;
    Description: string;
    Icon: string;
    Severity: number;
    Properties: UserMessageCategoryProperty[];
    constructor(obj: Partial<UserMessageCategory>);
}
export declare class UserMessageCategoryProperty {
    Id: number;
    Name: string;
    Description: string;
    CategoryType: UserMessageCategoryType;
    IsRequired: boolean;
    Values: string;
    constructor(obj: Partial<UserMessageCategoryProperty>);
}
