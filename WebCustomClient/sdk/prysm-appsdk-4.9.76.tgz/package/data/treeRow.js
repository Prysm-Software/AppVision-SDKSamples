"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeRow = void 0;
const treeHelper_1 = require("../common/treeHelper");
class TreeRow {
    constructor(row) {
        this.Id = row.Id;
        this.Name = row.Name;
        this.Description = row.Description;
        this.FullDescription = row.FullDescription;
        this.items = row.items;
        this.parent = row.parent;
    }
    /**
     * Return the name of the parent
     */
    get parentName() {
        const parts = this.Name.split('.');
        if (/^\$.\./.test(this.Name))
            parts.shift();
        return parts.slice(0, -1).join('.');
    }
    /**
     * Return true if id is a child of this
     * @param id
     * @returns bool
     */
    hasChild(id) {
        if (id === this.Id)
            return true;
        for (const child of this.items) {
            if (child.hasChild(id)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Build tree from a flat array of treerow
     * @param rows flat array of tree row
     * @param separator separator in name (default: '.')
     * @returns Tree array
     * @deprecated Use TreeHelper.buildTreeRow
     */
    static init(rows, separator = '.') {
        return treeHelper_1.TreeHelper.buildTreeRow(rows, separator);
    }
}
exports.TreeRow = TreeRow;
