"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserMessageRow = exports.UserMessageProperty = exports.UserMessageComment = exports.UserMessageStatus = void 0;
const dateHelper_1 = require("../common/dateHelper");
const userMessageCategory_1 = require("./userMessageCategory");
const userMessageManager_1 = require("../managers/userMessageManager");
var UserMessageStatus;
(function (UserMessageStatus) {
    UserMessageStatus[UserMessageStatus["InProgress"] = 1] = "InProgress";
    UserMessageStatus[UserMessageStatus["WaitAck"] = 5] = "WaitAck";
    UserMessageStatus[UserMessageStatus["Completed"] = 10] = "Completed";
})(UserMessageStatus = exports.UserMessageStatus || (exports.UserMessageStatus = {}));
class UserMessageComment {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.UserMessageComment = UserMessageComment;
class UserMessageProperty {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.UserMessageProperty = UserMessageProperty;
class UserMessageRow {
    constructor(obj) {
        Object.assign(this, obj);
    }
    get dateCreate() {
        return dateHelper_1.DateHelper.toJSDate(this.DateCreate);
    }
    get dateClose() {
        return dateHelper_1.DateHelper.toJSDate(this.DateClose);
    }
    get dateWrite() {
        return dateHelper_1.DateHelper.strToJSDate(this.DateWrite);
    }
    get attachments() {
        if (!this.Attachments || this.Attachments.length <= 0)
            return [];
        return this.Attachments.split("\n");
    }
    get comments() {
        if (!this.Comment || this.Comment.length <= 0)
            return [];
        const coms = [];
        const lines = this.Comment.split("\n");
        var comment, date, fullComment, user;
        lines.forEach(l => {
            // Test if the line matches the comment header pattern: "{date} {time}{ AM/PM}?, {userName}:"
            const match = l.match("(\\d{1,2}\\/\\d{2}\\/\\d{2,4}) (\\d{1,2}:\\d{2}:\\d{2})( .{1,2})?, (.*):");
            if (match) {
                if (fullComment)
                    coms.push(new UserMessageComment({
                        Comment: comment,
                        Date: dateHelper_1.DateHelper.stringToDate(date),
                        DateString: date,
                        FullComment: fullComment,
                        User: user
                    }));
                comment = undefined;
                date = dateHelper_1.DateHelper.toEcmaDateTimeStringFormat(match[1], match[2], match[3]);
                fullComment = l;
                user = match[4].toString();
            }
            else {
                fullComment += "\n" + l;
                if (comment) {
                    comment += "\n" + l;
                }
                else {
                    comment = l;
                }
            }
        });
        if (fullComment)
            coms.push(new UserMessageComment({
                Comment: comment,
                Date: dateHelper_1.DateHelper.stringToDate(date),
                DateString: date,
                FullComment: fullComment,
                User: user
            }));
        return coms;
    }
    get propertiesCount() {
        var _a;
        if (!this.properties)
            this.InitProperties();
        return this.properties ? (_a = this.properties) === null || _a === void 0 ? void 0 : _a.length : 0;
    }
    /**
     * Initialize a private array of UserMessageProperty based on the value of ContentCategory
     * This step is required after a modification of ContentCategory to update the object correctly
     * @returns Nothing
     */
    InitProperties() {
        var _a, _b, _c, _d;
        this.properties = [];
        if (!this.ContentCategory)
            return;
        var parser = new DOMParser();
        var doc = parser.parseFromString(this.ContentCategory, "application/xml");
        try {
            const root = doc.getElementsByTagName(userMessageManager_1.XmlTags.ArrayOfNameValue)[0];
            const nameValueCollection = root.getElementsByTagName(userMessageManager_1.XmlTags.NameValue);
            for (let i = 0; i < nameValueCollection.length; i++) {
                const nameValueElement = nameValueCollection[i];
                const nameElement = (_a = nameValueElement.getElementsByTagName(userMessageManager_1.XmlTags.Name)) === null || _a === void 0 ? void 0 : _a[0];
                const valueElement = (_b = nameValueElement.getElementsByTagName(userMessageManager_1.XmlTags.Value)) === null || _b === void 0 ? void 0 : _b[0];
                if (!nameElement || !(nameElement === null || nameElement === void 0 ? void 0 : nameElement.hasChildNodes()))
                    continue;
                this.properties.push({
                    Name: (_c = nameElement === null || nameElement === void 0 ? void 0 : nameElement.childNodes[0]) === null || _c === void 0 ? void 0 : _c.nodeValue,
                    Value: (_d = valueElement === null || valueElement === void 0 ? void 0 : valueElement.childNodes[0]) === null || _d === void 0 ? void 0 : _d.nodeValue
                });
            }
        }
        catch (error) {
            // Category with no properties
        }
    }
    /**
     * Get the properties of a user message category and fill its values if this UserMessageRow has any corresponding values
     * @param category UserMessageCategory to retrieve the properties from
     * @returns Array of UserMessageProperty
     */
    getProperties(category) {
        if (!this.properties)
            this.InitProperties();
        if (category) {
            if (!this.ContentCategory) {
                this.properties = [];
                category.Properties.forEach(p => {
                    const property = new UserMessageProperty({
                        Name: p.Name,
                        Description: p.Description,
                        Type: p.CategoryType,
                        IsRequired: p.IsRequired
                    });
                    if (property.Type === userMessageCategory_1.UserMessageCategoryType.ComboBox && p.Values)
                        property.Values = p.Values.split("/");
                    this.properties.push(property);
                });
                return this.properties;
            }
            else {
                if (this.properties.length !== category.Properties.length
                    || this.Category !== category.Description)
                    throw new Error(`Invalid category (props: ${this.properties.length}, cat ${category.Description} [${this.Category}] / ${category.Properties.length})`);
                for (let i = 0; i < this.properties.length; i++) {
                    const catProp = category.Properties[i];
                    if (!catProp)
                        continue;
                    this.properties[i].Type = catProp.CategoryType;
                    this.properties[i].IsRequired = catProp.IsRequired;
                    if (catProp.Description)
                        this.properties[i].Description = catProp.Description;
                    if (this.properties[i].Type === userMessageCategory_1.UserMessageCategoryType.ComboBox)
                        this.properties[i].Values = catProp.Values.split("/");
                    if (this.properties[i].Type === userMessageCategory_1.UserMessageCategoryType.Date && this.properties[i].Value)
                        this.properties[i].Date = dateHelper_1.DateHelper.stringToDate(this.properties[i].Value);
                    if (this.properties[i].Type === userMessageCategory_1.UserMessageCategoryType.DateTime && this.properties[i].Value)
                        this.properties[i].DateTime = dateHelper_1.DateHelper.stringToDate(this.properties[i].Value);
                }
            }
        }
        return this.properties;
    }
}
exports.UserMessageRow = UserMessageRow;
