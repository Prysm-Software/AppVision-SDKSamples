import { PersonRow } from "./personRow";
import { DepartmentRow } from "./departmentRow";
type VisitorStatus = 'AwatingValidation' | 'AwaitingCheckIn' | 'InProgress' | 'Completed';
export declare class VisitorRow {
    Id: number;
    FirstName: string;
    LastName: string;
    Status: VisitorStatus | string;
    PersonId?: number;
    VisitedId?: number;
    BadgeReturn: string;
    Company: string;
    CompanyId: string;
    Address: string;
    Email: string;
    Photo: string;
    Phone: string;
    CategoryId: number;
    Extension: string;
    ExtId1: number;
    ExtId2: number;
    IsEscortRequired: number;
    Info1: string;
    Info2: string;
    Info3: string;
    Info4: string;
    Info5: string;
    Info6: string;
    Info7: string;
    Info8: string;
    Info9: string;
    Notes: string;
    ReceptionNotes: string;
    Person: PersonRow;
    DepartmentId: number;
    Department: DepartmentRow;
    Attachments: string;
    IdNumber: string;
    /**
     * Return attachment as an array
     * No need to use it as a setter, this returns a cloned array. Use addAttachment
     */
    get attachments(): string[];
    DateModification: string;
    get dateModification(): Date;
    DateCreation: string;
    get dateCreation(): Date;
    DateValidation: string;
    get dateValidation(): Date;
    ValidityStart: string;
    get validityStart(): Date;
    ValidityEnd: string;
    get validityEnd(): Date;
    constructor(row: Partial<VisitorRow>);
}
export {};
