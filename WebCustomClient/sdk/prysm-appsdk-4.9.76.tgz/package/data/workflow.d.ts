export declare class WorkFlow {
    items: WorflowItem[];
    constructor();
}
export declare class WorflowItem {
    name: string;
    description: string;
    state: string;
    condition: string;
}
export declare class WorkFlowItemDisplay extends WorflowItem {
    path: string;
}
export declare class WorkflowItemBranch extends WorflowItem {
    items: WorflowItem[];
}
export declare class WorkflowItemAction extends WorflowItem {
    script: string;
}
export declare class WorkflowItemGoTo extends WorflowItem {
    itemName: string;
}
export declare class WorkflowItemClose extends WorflowItem {
    Name: string;
}
