"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailingRow = void 0;
const xmlParser_1 = require("../common/xmlParser");
class MailingRow {
    get conditions() {
        var _a, _b, _c, _d, _e, _f, _g;
        const parser = new xmlParser_1.XmlParser();
        const doc = parser.parseFromString(this.Conditions);
        return {
            SendOnAlarmOn: ((_a = doc.getElementsByTagName("SendOnAlarmOn")[0]) === null || _a === void 0 ? void 0 : _a.value) === "true",
            SendOnAlarmOff: ((_b = doc.getElementsByTagName("SendOnAlarmOff")[0]) === null || _b === void 0 ? void 0 : _b.value) === "true",
            SendOnAlarmAck: ((_c = doc.getElementsByTagName("SendOnAlarmAck")[0]) === null || _c === void 0 ? void 0 : _c.value) === "true",
            SendOnAlarmReport: ((_d = doc.getElementsByTagName("SendOnAlarmReport")[0]) === null || _d === void 0 ? void 0 : _d.value) === "true",
            SendOnVarChanged: ((_e = doc.getElementsByTagName("SendOnVarChanged")[0]) === null || _e === void 0 ? void 0 : _e.value) === "true",
            SendOnGroupChanged: ((_f = doc.getElementsByTagName("SendOnGroupChanged")[0]) === null || _f === void 0 ? void 0 : _f.value) === "true",
            SendOnAreaChanged: ((_g = doc.getElementsByTagName("SendOnAreaChanged")[0]) === null || _g === void 0 ? void 0 : _g.value) === "true",
        };
    }
    set conditions(conditions) {
        this.Conditions =
            '<?xml version="1.0" encoding="utf-16"?>' +
                '<MailingConditions xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
                '<SendOnAlarmOn>' + conditions.SendOnAlarmOn + '</SendOnAlarmOn>';
        '<SendOnAlarmOff>' + conditions.SendOnAlarmOff + '</SendOnAlarmOff>';
        '<SendOnAlarmAck>' + conditions.SendOnAlarmAck + '</SendOnAlarmAck>';
        '<SendOnAlarmReport>' + conditions.SendOnAlarmReport + '</SendOnAlarmReport>' +
            '<SendOnVarChanged>' + conditions.SendOnVarChanged + '</SendOnVarChanged>' +
            '<SendOnGroupChanged>' + conditions.SendOnGroupChanged + '</SendOnGroupChanged>' +
            '<SendOnAreaChanged>' + conditions.SendOnAreaChanged + '</SendOnAreaChanged>' +
            '</MailingConditions>';
    }
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.MailingRow = MailingRow;
