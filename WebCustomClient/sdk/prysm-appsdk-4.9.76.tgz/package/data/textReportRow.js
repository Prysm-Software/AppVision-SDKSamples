"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextReportRow = void 0;
class TextReportRow {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.TextReportRow = TextReportRow;
