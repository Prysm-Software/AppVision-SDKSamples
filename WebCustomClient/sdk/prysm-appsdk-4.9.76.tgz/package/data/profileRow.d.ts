export declare class ProfileRow {
    constructor(user: Partial<ProfileRow>);
    Id: number;
    Name: string;
    Description: string;
    IsAdmin: boolean;
    DbOptions: string;
    DbRoles: string;
    CommandExceptions: string;
    Parameters: string;
    Filters: string;
    FiltersFile: string;
    FiltersWrite: string;
    PriorityLevel: number;
    Url: string;
    Extension: string;
    options: any;
    get filters(): string[];
    get rights(): string[];
    get filterGroups(): string[];
    get filterAreas(): string[];
    checkArea(areaName: string): boolean;
    checkGroup(groupName: string): boolean;
    /**
     * Check if the profile has filter on an area or a group
     * @param filters Area or group name starting with $A. or $G.
     * @returns Boolean
     */
    checkFilter(filter: string): boolean;
    checkRight(right: string): boolean;
    checkCommandException(command: string): boolean;
    addRight(rightName: string): void;
    removeRight(rightName: string): void;
    addFilter(filter: string): void;
    removeFilter(filter: string): void;
    getFilterValue(filter: string): string;
    /**
     * Get Extension field as ProfileExtension object
     * @returns ProfileExtension
     */
    getExtension(): ProfileExtension;
    /**
     * Save the given profile extension into Extension field
     * @param ext ProfileExtension
     */
    setExtension(ext: ProfileExtension): void;
    private checkFilterByName;
}
export declare class ProfileExtension {
    ServerName: string;
    UserId: number;
    UserName: string;
    CommandExceptions: string;
    constructor(row: Partial<ProfileExtension>);
}
