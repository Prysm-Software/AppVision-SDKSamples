import { VariableRow } from "./variableRow";
import { HttpService } from "../services/httpService";
export declare enum CameraMode {
    Live = 0,
    Playback = 1
}
export interface CameraStreamInfo {
    timestamp: string;
    status: number;
    sourceStatus: number;
}
interface StreamOptions {
    /**
     * Protocol used for data transmission : Http or websocket
     */
    protocol?: "Http" | "WebSocket";
    /**
     * Only if streamType=http_multipart.
     * Http multipart type
     */
    httpMultipartType?: "mixed" | "x-mixed-replace";
    /**
     * Only if protocol=WebSocket
     * Tell the server to send or not extra frame data like timestamp...
     * Frame will look like this FRAME_EXTRADA\r\n{timestamp: "20230110T000000Z"}\r\n\r\nBUFFER
     * Default is false
     */
    sendFrameExtraData?: boolean;
}
export interface CameraPtzCapabilities {
    canPresets: boolean;
    canPatterns: Boolean;
    canContinuousMove: Boolean;
    presets: string[];
    patterns: string[];
}
export interface CameraPlaybackCapabilities {
    canPlayback: boolean;
}
export interface CameraVideoConfiguration {
    format: CameraFormat;
    width: number;
    height: number;
}
export interface CameraSourceInfos {
    videoConfiguration: CameraVideoConfiguration;
    ptz: CameraPtzCapabilities;
    playback: CameraPlaybackCapabilities;
    streams: string[];
}
export type CameraFormat = "MJpeg" | "NALu_h264" | "NALu_h265";
export type StreamQuality = "High" | "Low";
interface CameraOptions {
    row: VariableRow;
    /**
     * Defines if camera is live or playback
     */
    start?: Date;
    /**
     * Only for playback cameras
     */
    speed?: number;
    /**
     * Only for live cameras
     */
    stream?: StreamQuality;
}
export declare class Camera {
    private http;
    private streamerHttp;
    private dateStart;
    private stream;
    sessionId: string;
    row: VariableRow;
    mode: CameraMode;
    playbackSpeed: number;
    /**
     * videoFormat, ptz capabilities, playback capabilities and other infos on this camera.
     * Method connect must be called first.
     */
    sourceInfos: CameraSourceInfos;
    /**
     * Uri of the camera streamer
     */
    get streamerUri(): string;
    /**
     * Current stream quality. Can be Low or High.
     */
    get streamQuality(): StreamQuality;
    constructor(http: HttpService, options: CameraOptions);
    /**
     * Connect to the video gateway and get the source infos: (videoFormat, protocols supported for video streaming, ptz caps, playback caps) on this camera
     * @returns CameraSourceInfos
     */
    connect(): Promise<CameraSourceInfos>;
    /**
     * Build stream uri and returns it
     * @param options Options of the uri
     * @returns Uri
     */
    getStreamingUri(options?: StreamOptions): string;
    /**
     * Get current info of the stream (current time, status...)
     * @returns CameraStreamInfo
     */
    getStreamInfo(): Promise<CameraStreamInfo>;
    continuousMove(x: number, y: number): Promise<void>;
    continuousZoom(z: number): Promise<void>;
    getPresets(): Promise<string[]>;
    getPatterns(): Promise<string[]>;
    gotoPreset(preset: string): Promise<void>;
    runPattern(pattern: string): Promise<void>;
    goToHome(): Promise<void>;
    setPlaybackPosition(date: Date): Promise<void>;
    setPlaybackSpeed(speed: number): Promise<void>;
    resume(): Promise<void>;
    pause(): Promise<void>;
    stepBackward(): Promise<void>;
    stepForward(): Promise<void>;
    snapshot(): Promise<Blob>;
}
export {};
