"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkflowItemClose = exports.WorkflowItemGoTo = exports.WorkflowItemAction = exports.WorkflowItemBranch = exports.WorkFlowItemDisplay = exports.WorflowItem = exports.WorkFlow = void 0;
class WorkFlow {
    constructor() { }
}
exports.WorkFlow = WorkFlow;
class WorflowItem {
}
exports.WorflowItem = WorflowItem;
class WorkFlowItemDisplay extends WorflowItem {
}
exports.WorkFlowItemDisplay = WorkFlowItemDisplay;
class WorkflowItemBranch extends WorflowItem {
}
exports.WorkflowItemBranch = WorkflowItemBranch;
class WorkflowItemAction extends WorflowItem {
}
exports.WorkflowItemAction = WorkflowItemAction;
class WorkflowItemGoTo extends WorflowItem {
}
exports.WorkflowItemGoTo = WorkflowItemGoTo;
class WorkflowItemClose extends WorflowItem {
}
exports.WorkflowItemClose = WorkflowItemClose;
