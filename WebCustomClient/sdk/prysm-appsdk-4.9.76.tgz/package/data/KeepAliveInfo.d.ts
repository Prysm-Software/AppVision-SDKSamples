export interface KeepAliveInfo {
    date: Date;
    count: number;
}
