export interface RowNotif<T> {
    row: T;
    type: "ADD" | "UPDATE" | "DELETE";
}
