"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AreaState = void 0;
class AreaState {
    constructor(state) {
        this.Id = state.Id;
        this.Name = state.Name;
        this.OrValue = state.OrValue;
        this.AndValue = state.AndValue;
        this.LockedCount = state.LockedCount;
        this.MaskedCount = state.MaskedCount;
        this.AlarmCount = state.AlarmCount;
        this.AlarmAcknowledgeWaitingCount = state.AlarmAcknowledgeWaitingCount;
        this.AlarmProcessingCount = state.AlarmProcessingCount;
        this.AlarmProcessWaitingCount = state.AlarmProcessWaitingCount;
        this.AlarmClosedCount = state.AlarmClosedCount;
        this.MaxSeverity = state.MaxSeverity;
        this.WaitEndCount = state.WaitEndCount;
        this.WaitReportCount = state.WaitReportCount;
    }
    get isAlarm() {
        return this.AlarmCount > 0;
    }
    get isAlarmAcknowledgeWaiting() {
        return this.AlarmAcknowledgeWaitingCount > 0;
    }
    get isAlarmProcessing() {
        return this.AlarmProcessingCount > 0;
    }
    get isAlarmProcessWaiting() {
        return this.AlarmProcessWaitingCount > 0;
    }
    get isAlarmClosed() {
        return this.AlarmClosedCount > 0;
    }
}
exports.AreaState = AreaState;
