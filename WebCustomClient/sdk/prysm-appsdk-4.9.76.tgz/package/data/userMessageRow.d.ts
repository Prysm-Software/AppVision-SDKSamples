import { DateTimeOffset } from "./dateTimeOffset";
import { UserMessageCategory, UserMessageCategoryType } from "./userMessageCategory";
export declare enum UserMessageStatus {
    InProgress = 1,
    WaitAck = 5,
    Completed = 10
}
export declare class UserMessageComment {
    Comment?: string;
    Date: Date;
    DateString: string;
    FullComment: string;
    User: string;
    constructor(obj: Partial<UserMessageComment>);
}
export declare class UserMessageProperty {
    Name: string;
    Description?: string;
    Value?: string;
    Date?: Date;
    DateTime?: Date;
    Type?: UserMessageCategoryType;
    Values?: string[];
    IsRequired?: boolean;
    constructor(obj: Partial<UserMessageProperty>);
}
export declare class UserMessageRow {
    AlarmId?: number;
    AreaDesc: string;
    AreaId?: number;
    Attachments: string;
    Category: string;
    Comment: string;
    Content: string;
    ContentCategory: string;
    ContentReference: string;
    CustomExtension: string;
    DateCreate: DateTimeOffset;
    DateClose?: DateTimeOffset;
    DateWrite: string;
    Description: string;
    Extension: string;
    GroupDesc: string;
    GroupNames: string;
    Guid: string;
    Id: number;
    IsIncident: boolean;
    Photo: string;
    ServerName: string;
    Severity: number;
    Status: UserMessageStatus;
    To: string;
    UserIdClose?: number;
    UserIdCreate: number;
    UserNameClose: string;
    UserNameCreate: string;
    Video: string;
    private properties;
    constructor(obj: Partial<UserMessageRow>);
    get dateCreate(): Date;
    get dateClose(): Date;
    get dateWrite(): Date;
    get attachments(): string[];
    get comments(): UserMessageComment[];
    get propertiesCount(): number;
    /**
     * Initialize a private array of UserMessageProperty based on the value of ContentCategory
     * This step is required after a modification of ContentCategory to update the object correctly
     * @returns Nothing
     */
    InitProperties(): void;
    /**
     * Get the properties of a user message category and fill its values if this UserMessageRow has any corresponding values
     * @param category UserMessageCategory to retrieve the properties from
     * @returns Array of UserMessageProperty
     */
    getProperties(category: UserMessageCategory): UserMessageProperty[];
}
