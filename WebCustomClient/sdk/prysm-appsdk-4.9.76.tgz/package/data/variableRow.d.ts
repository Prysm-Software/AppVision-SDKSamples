import { TreeRow } from "./treeRow";
import { VariableState } from "./variableState";
export declare enum VariableType {
    Node = 0,
    Bool = 1,
    Int = 2,
    String = 3,
    Enum = 4,
    Double = 5,
    Timetable = 6,
    Buffer = 7,
    Calendar = 8,
    Reader = 10,
    Video = 11,
    Audio = 12
}
export declare enum VariableBufferType {
    Byte = 0,
    SByte = 1,
    UInt16 = 2,
    Int16 = 3,
    UInt32 = 4,
    Int32 = 5,
    UInt64 = 6,
    Int64 = 7,
    Double = 9,
    Bit = 10
}
export declare class VariableRow extends TreeRow {
    AreaId: number;
    AreaDescription: string;
    CustomField1: string;
    CustomField2: string;
    CustomField3: string;
    CustomField4: string;
    CustomField5: string;
    FullAddress: string;
    FullAreaId: number;
    FullGroupDescriptions: string;
    FullGroupNames: string[];
    FullGroupIds: number[];
    FullParameters: string;
    FullVideoLink: string;
    FullSound: string;
    FullSynoptic: string;
    GroupNames: string[];
    Expression: string;
    IsAlarm: boolean;
    IsExclude: boolean;
    Sound: string;
    Type: number;
    TypeInt: number;
    State: VariableState;
    StateDescs: string;
    StateType: number;
    StoreValue: boolean;
    StoreEvent: boolean;
    StoreTempo: number;
    StoreDeltaMin: number;
    StoreDeltaMax: number;
    Parameters: string;
    Address: string;
    AlarmInstructions: string;
    IsAlarmMultiple: boolean;
    AlarmNeedAcknowledge: boolean;
    AlarmResetOnAcknowledge: boolean;
    AlarmNeedReport: boolean;
    AlarmSeverity: number;
    AlarmSeverity2: number;
    AlarmTempo: number;
    AlarmMinValue: number;
    AlarmMaxValue: number;
    AlarmMinValue2: number;
    AlarmMaxValue2: number;
    Synoptic: string;
    GraphMin: number;
    GraphMax: number;
    GraphScale: number;
    VideoLink: string;
    Symbol: string;
    Icon: string;
    NoVisible: boolean;
    Script: string;
    Position: string;
    Notes: string;
    BufferLength: string;
    BufferTypeInt: number;
    BufferType: number;
    Extension: string;
    Url: string;
    CustomExtension: string;
    SendMailing: boolean;
    constructor(row: Partial<VariableRow>);
    /**
     * Type of TypeInt can be null sometimes.
     * This guaranty to get the type of the VariableRow
     */
    get type(): VariableType;
    /**
     * Set Type and TypeInt
     * This guaranty to set the  type of the VariableRow
     */
    set type(val: VariableType | number);
    /**
     * BufferTypeInt or BufferType can be null sometimes.
     * This guaranty to get the type of the VariableRow
     */
    get bufferType(): VariableBufferType;
    /**
     * Set BufferTypeInt and BufferType
     * This guaranty to set the buffer type of the VariableRow
     */
    set bufferType(val: VariableBufferType | number);
    /**
     * Get Extension field as AreaExtension object
     * @returns AreaExtension
     */
    getExtension(): VariableExtension;
    /**
     * Save the given variable extension into Extension field
     * @param ext VariableExtension
     */
    setExtension(ext: VariableExtension): void;
    private hasLeaf;
}
export declare class VariableExtension {
    ServerName: string;
    UserId: number;
    AlarmEscalationSeverity: number;
    AlarmEscalationMultipleCount: number;
    AlarmEscalationCount: number;
    AlarmEscalationTempoOnEnd: number;
    AlarmEscalationTempoOnAck: number;
    AlarmEscalationTempoOnReport: number;
    AlarmAcknowledgeOnReset: boolean;
    AlarmTempoOnReset: number;
    constructor(row: Partial<VariableExtension>);
}
