"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.VariableExtension = exports.VariableRow = exports.VariableBufferType = exports.VariableType = void 0;
const helper_1 = require("../common/helper");
const xmlParser_1 = require("../common/xmlParser");
const treeRow_1 = require("./treeRow");
var VariableType;
(function (VariableType) {
    VariableType[VariableType["Node"] = 0] = "Node";
    VariableType[VariableType["Bool"] = 1] = "Bool";
    VariableType[VariableType["Int"] = 2] = "Int";
    VariableType[VariableType["String"] = 3] = "String";
    VariableType[VariableType["Enum"] = 4] = "Enum";
    VariableType[VariableType["Double"] = 5] = "Double";
    VariableType[VariableType["Timetable"] = 6] = "Timetable";
    VariableType[VariableType["Buffer"] = 7] = "Buffer";
    VariableType[VariableType["Calendar"] = 8] = "Calendar";
    VariableType[VariableType["Reader"] = 10] = "Reader";
    VariableType[VariableType["Video"] = 11] = "Video";
    VariableType[VariableType["Audio"] = 12] = "Audio";
})(VariableType = exports.VariableType || (exports.VariableType = {}));
var VariableBufferType;
(function (VariableBufferType) {
    VariableBufferType[VariableBufferType["Byte"] = 0] = "Byte";
    VariableBufferType[VariableBufferType["SByte"] = 1] = "SByte";
    VariableBufferType[VariableBufferType["UInt16"] = 2] = "UInt16";
    VariableBufferType[VariableBufferType["Int16"] = 3] = "Int16";
    VariableBufferType[VariableBufferType["UInt32"] = 4] = "UInt32";
    VariableBufferType[VariableBufferType["Int32"] = 5] = "Int32";
    VariableBufferType[VariableBufferType["UInt64"] = 6] = "UInt64";
    VariableBufferType[VariableBufferType["Int64"] = 7] = "Int64";
    VariableBufferType[VariableBufferType["Double"] = 9] = "Double";
    VariableBufferType[VariableBufferType["Bit"] = 10] = "Bit";
})(VariableBufferType = exports.VariableBufferType || (exports.VariableBufferType = {}));
class VariableRow extends treeRow_1.TreeRow {
    constructor(row) {
        super(row);
        this.FullAddress = row.FullAddress;
        this.FullParameters = row.FullParameters;
        this.FullVideoLink = row.FullVideoLink;
        this.Type = row.Type;
        this.TypeInt = row.TypeInt;
        this.StateDescs = row.StateDescs;
        this.StateType = row.StateType;
        this.IsExclude = row.IsExclude;
        this.AreaId = row.AreaId;
        this.FullAreaId = row.FullAreaId;
        this.AreaDescription = row.AreaDescription;
        this.GroupNames = row.GroupNames;
        this.FullGroupDescriptions = row.FullGroupDescriptions;
        this.FullGroupNames = row.FullGroupNames;
        this.FullGroupIds = row.FullGroupIds;
        this.Expression = row.Expression;
        this.CustomField1 = row.CustomField1;
        this.CustomField2 = row.CustomField2;
        this.CustomField3 = row.CustomField3;
        this.CustomField4 = row.CustomField4;
        this.CustomField5 = row.CustomField5;
        this.Sound = row.Sound;
        this.FullSound = row.FullSound;
        this.FullSynoptic = row.FullSynoptic;
        this.IsAlarm = row.IsAlarm;
        this.StoreValue = row.StoreValue;
        this.StoreEvent = row.StoreEvent;
        this.StoreTempo = row.StoreTempo;
        this.StoreDeltaMin = row.StoreDeltaMin;
        this.StoreDeltaMax = row.StoreDeltaMax;
        this.Parameters = row.Parameters;
        this.Address = row.Address;
        this.AlarmInstructions = row.AlarmInstructions;
        this.IsAlarmMultiple = row.IsAlarmMultiple;
        this.AlarmNeedAcknowledge = row.AlarmNeedAcknowledge;
        this.AlarmResetOnAcknowledge = row.AlarmResetOnAcknowledge;
        this.AlarmNeedReport = row.AlarmNeedReport;
        this.AlarmSeverity = row.AlarmSeverity;
        this.AlarmSeverity2 = row.AlarmSeverity2;
        this.AlarmTempo = row.AlarmTempo;
        this.AlarmMinValue = row.AlarmMinValue;
        this.AlarmMaxValue = row.AlarmMaxValue;
        this.AlarmMinValue2 = row.AlarmMinValue2;
        this.AlarmMaxValue2 = row.AlarmMaxValue2;
        this.Synoptic = row.Synoptic;
        this.GraphMin = row.GraphMin;
        this.GraphMax = row.GraphMax;
        this.GraphScale = row.GraphScale;
        this.VideoLink = row.VideoLink;
        this.Symbol = row.Symbol;
        this.Icon = row.Icon;
        this.NoVisible = row.NoVisible;
        this.Script = row.Script;
        this.Position = row.Position;
        this.Notes = row.Notes;
        this.BufferLength = row.BufferLength;
        this.BufferTypeInt = row.BufferTypeInt;
        this.BufferType = row.BufferType;
        this.Extension = row.Extension;
        this.Url = row.Url;
        this.CustomExtension = row.CustomExtension;
        this.SendMailing = row.SendMailing;
        this.State = row.State;
        // this.State = row.State || new VariableState({ Id: this.Id });
    }
    /**
     * Type of TypeInt can be null sometimes.
     * This guaranty to get the type of the VariableRow
     */
    get type() {
        if (this.TypeInt != null) {
            return this.TypeInt;
        }
        else {
            return this.Type;
        }
    }
    /**
     * Set Type and TypeInt
     * This guaranty to set the  type of the VariableRow
     */
    set type(val) {
        this.TypeInt = val;
        this.Type = val;
    }
    /**
     * BufferTypeInt or BufferType can be null sometimes.
     * This guaranty to get the type of the VariableRow
     */
    get bufferType() {
        if (this.BufferType != null) {
            return this.BufferType;
        }
        else {
            return this.BufferTypeInt;
        }
    }
    /**
     * Set BufferTypeInt and BufferType
     * This guaranty to set the buffer type of the VariableRow
     */
    set bufferType(val) {
        this.BufferTypeInt = val;
        this.BufferType = val;
    }
    /**
     * Get Extension field as AreaExtension object
     * @returns AreaExtension
     */
    getExtension() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        if (!this.Extension)
            return new VariableExtension({});
        const parser = new xmlParser_1.XmlParser();
        const xml = parser.parseFromString(this.Extension);
        return new VariableExtension({
            ServerName: (_a = xml.getElementsByTagName("ServerName")[0]) === null || _a === void 0 ? void 0 : _a.value,
            UserId: helper_1.Helper.parseInt((_b = xml.getElementsByTagName('UserId')[0]) === null || _b === void 0 ? void 0 : _b.value),
            AlarmAcknowledgeOnReset: helper_1.Helper.parseBool((_c = xml.getElementsByTagName('AlarmAcknowledgeOnReset')[0]) === null || _c === void 0 ? void 0 : _c.value),
            AlarmEscalationCount: helper_1.Helper.parseInt((_d = xml.getElementsByTagName('AlarmEscalationCount')[0]) === null || _d === void 0 ? void 0 : _d.value),
            AlarmEscalationMultipleCount: helper_1.Helper.parseInt((_e = xml.getElementsByTagName('AlarmEscalationMultipleCount')[0]) === null || _e === void 0 ? void 0 : _e.value),
            AlarmEscalationSeverity: helper_1.Helper.parseInt((_f = xml.getElementsByTagName('AlarmEscalationSeverity')[0]) === null || _f === void 0 ? void 0 : _f.value),
            AlarmEscalationTempoOnAck: helper_1.Helper.parseInt((_g = xml.getElementsByTagName('AlarmEscalationTempoOnAck')[0]) === null || _g === void 0 ? void 0 : _g.value),
            AlarmEscalationTempoOnEnd: helper_1.Helper.parseInt((_h = xml.getElementsByTagName('AlarmEscalationTempoOnEnd')[0]) === null || _h === void 0 ? void 0 : _h.value),
            AlarmEscalationTempoOnReport: helper_1.Helper.parseInt((_j = xml.getElementsByTagName('AlarmEscalationTempoOnReport')[0]) === null || _j === void 0 ? void 0 : _j.value),
            AlarmTempoOnReset: helper_1.Helper.parseInt((_k = xml.getElementsByTagName('AlarmTempoOnReset')[0]) === null || _k === void 0 ? void 0 : _k.value),
        });
    }
    /**
     * Save the given variable extension into Extension field
     * @param ext VariableExtension
     */
    setExtension(ext) {
        const xml = '<VariableExtension xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
            '<ServerName>' + (ext.ServerName || '') + '</ServerName>' +
            '<UserId>' + (ext.UserId || '') + '</UserId>' +
            '<AlarmEscalationSeverity>' + (ext.AlarmEscalationSeverity || 0) + '</AlarmEscalationSeverity>' +
            '<AlarmEscalationMultipleCount>' + (ext.AlarmEscalationMultipleCount || 0) + '</AlarmEscalationMultipleCount>' +
            '<AlarmEscalationCount>' + (ext.AlarmEscalationCount || 0) + '</AlarmEscalationCount>' +
            '<AlarmEscalationTempoOnEnd>' + (ext.AlarmEscalationTempoOnEnd || 0) + '</AlarmEscalationTempoOnEnd>' +
            '<AlarmEscalationTempoOnAck>' + (ext.AlarmEscalationTempoOnAck || 0) + '</AlarmEscalationTempoOnAck>' +
            '<AlarmEscalationTempoOnReport>' + (ext.AlarmEscalationTempoOnReport || 0) + '</AlarmEscalationTempoOnReport>' +
            '<AlarmAcknowledgeOnReset>' + (ext.AlarmAcknowledgeOnReset || false) + '</AlarmAcknowledgeOnReset>' +
            '<AlarmTempoOnReset>' + (ext.AlarmTempoOnReset || 0) + '</AlarmTempoOnReset>' +
            '</VariableExtension>';
        this.Extension = xml;
    }
    hasLeaf() {
        if (this.Type === 0)
            return this.items.some(i => i.hasLeaf());
        return true;
    }
}
exports.VariableRow = VariableRow;
class VariableExtension {
    constructor(row) {
        this.ServerName = row.ServerName;
        this.UserId = row.UserId;
        this.AlarmEscalationSeverity = row.AlarmEscalationSeverity;
        this.AlarmEscalationMultipleCount = row.AlarmEscalationMultipleCount;
        this.AlarmEscalationCount = row.AlarmEscalationCount;
        this.AlarmEscalationTempoOnEnd = row.AlarmEscalationTempoOnEnd;
        this.AlarmEscalationTempoOnReport = row.AlarmEscalationTempoOnReport;
        this.AlarmEscalationTempoOnAck = row.AlarmEscalationTempoOnAck;
        this.AlarmAcknowledgeOnReset = row.AlarmAcknowledgeOnReset;
        this.AlarmTempoOnReset = row.AlarmTempoOnReset;
    }
}
exports.VariableExtension = VariableExtension;
