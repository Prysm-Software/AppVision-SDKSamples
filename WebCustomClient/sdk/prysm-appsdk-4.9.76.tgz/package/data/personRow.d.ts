import { BadgeRow } from "./badgeRow";
import { CategoryRow } from "./categoryRow";
import { DepartmentRow } from "./departmentRow";
import { PersonRightRow } from "./personRightRow";
export declare class PersonRow {
    Id: number;
    CategoryId: number;
    DepartmentId: number;
    FirstName: string;
    LastName: string;
    CompanyId: string;
    Address: string;
    Phone: string;
    Email: string;
    Photo: string;
    Notes: string;
    PinCode: string;
    Info1: string;
    Info2: string;
    Info3: string;
    Info4: string;
    Info5: string;
    Info6: string;
    Info7: string;
    Info8: string;
    Info9: string;
    BadgeDesign: '';
    IsAlarm: boolean;
    IsActive: boolean;
    IsAntipassback: boolean;
    Badges: BadgeRow[];
    PersonRights: PersonRightRow[];
    Category: CategoryRow;
    Department: DepartmentRow;
    Attachments: string;
    Company: string;
    IdNumber: string;
    /**
     * Return attachment as an array
     * No need to use it as a setter, this returns a cloned array. Use addAttachment
     */
    get attachments(): string[];
    ValidityStart: string;
    get validityStart(): Date;
    ValidityEnd: string;
    get validityEnd(): Date;
    get FullName(): string;
    constructor(p: Partial<PersonRow>);
}
