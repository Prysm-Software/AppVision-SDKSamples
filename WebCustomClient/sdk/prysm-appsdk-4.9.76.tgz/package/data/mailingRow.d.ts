export declare class MailingRow {
    Id: number;
    Name: string;
    Description: string;
    Guid: string;
    Type: number;
    IsActive: boolean;
    MaxRetry: number;
    TempoRetry: number;
    Parameters: string;
    Extension: string;
    Url: string;
    CustomExtension: string;
    To: string;
    FilterSeverity: number;
    FilterTimetableId: number;
    Filters: string;
    Grouping: string;
    ModelEmail: string;
    ModelSMS: string;
    Conditions: string;
    get conditions(): MailingRowConditions;
    set conditions(conditions: MailingRowConditions);
    constructor(obj: Partial<MailingRow>);
}
export interface MailingRowConditions {
    SendOnAlarmOn: boolean;
    SendOnAlarmOff: boolean;
    SendOnAlarmAck: boolean;
    SendOnAlarmReport: boolean;
    SendOnVarChanged: boolean;
    SendOnGroupChanged: boolean;
    SendOnAreaChanged: boolean;
}
