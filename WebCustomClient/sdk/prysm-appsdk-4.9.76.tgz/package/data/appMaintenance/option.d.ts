export type Option = {
    Name: string;
    InstallationId: number;
    Value: string;
    Type: number;
    Extension1: string;
    Extension2: string;
    Extension3: string;
};
