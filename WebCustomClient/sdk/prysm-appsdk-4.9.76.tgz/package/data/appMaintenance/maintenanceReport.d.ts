import { InstallationTemplate } from "./installationTemplate";
import { MaintenanceReportRow } from "./maintenanceReportRow";
export declare class MaintenanceReport {
    Id: number;
    InstallationTemplateId: number;
    InstallationTemplate: InstallationTemplate;
    User: string;
    ContractorId: number | null;
    PreviousReportInfo: string;
    MaintenanceReportRows: MaintenanceReportRow[];
    StartDate: string;
    EndDate: string;
    CompleteDate: string;
    DateNotification: string;
    IsActive: boolean;
    Document1: string;
    Document2: string;
    Document3: string;
    Extension1: string;
    Extension2: string;
    constructor();
}
