import { Installation } from "./installation";
export type AppEntity = {
    Id: number;
    InstallationId: number;
    Type: number;
    Extension1: string;
    Extension2: string;
    Extension3: string;
    Installation: Installation;
};
