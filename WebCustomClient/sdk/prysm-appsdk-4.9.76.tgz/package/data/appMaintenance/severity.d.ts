export declare class Severity {
    Id: number;
    Description: string;
    Level: number;
    Timer: number;
    Reminder: number;
    Color: string;
    NotifyContractor: boolean;
    Effect1: number;
    NotifyAdmin: boolean;
    Effect2: number;
    IsPlannedDate: boolean;
    UserModification: string;
    DateModification: Date;
    Extension1: string;
    Extension2: string;
    constructor(p?: Partial<Severity>);
}
