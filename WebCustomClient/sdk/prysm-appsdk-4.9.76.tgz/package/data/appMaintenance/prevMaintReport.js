"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrevMaintReport = void 0;
class PrevMaintReport {
    constructor() {
    }
}
exports.PrevMaintReport = PrevMaintReport;
