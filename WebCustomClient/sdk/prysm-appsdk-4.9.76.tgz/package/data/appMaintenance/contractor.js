"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Contractor = void 0;
const dateHelper_1 = require("../../common/dateHelper");
class Contractor {
    get dateModification() {
        return dateHelper_1.DateHelper.stringToDate(this.DateModification);
    }
    /* constructor(p: Partial<Contractor> = null) {
       this.Id = 0;
       this.Name = '';
       this.Contact = '';
       this.Email = '';
       this.Phone = '';
       this.SupportPhone = '';
       this.SMS = '';
       this.Extension = '';
       this.Installations = [];
       this.UserModification = '';
       this.Extension1 = '';
       this.Extension2 = '';
   
       Object.assign(this, p);
     }*/
    constructor(row) {
        Object.assign(this, row);
    }
}
exports.Contractor = Contractor;
