import { Installation } from "./installation";
export declare class Contractor {
    Id: number;
    Name: string;
    Contact: string;
    Email: string;
    Phone: string;
    SupportPhone: string;
    SMS: string;
    Extension: string;
    Installations: Installation[];
    UserModification: string;
    DateModification: string;
    get dateModification(): Date;
    Extension1: string;
    Extension2: string;
    constructor(row: Partial<Contractor>);
}
