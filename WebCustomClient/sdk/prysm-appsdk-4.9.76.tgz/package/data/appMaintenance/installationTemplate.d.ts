import { Installation } from "./installation";
import { MaintenanceTemplate } from "./maintenanceTemplate";
import { MaintenanceReport } from "./maintenanceReport";
export type InstallationTemplate = {
    Id: number;
    InstallationId: number;
    Installation: Installation;
    TemplateId: number;
    Template: MaintenanceTemplate;
    Description: string;
    StartDate: Date;
    IntervalMonths: number;
    MaintenanceReports: MaintenanceReport[];
};
