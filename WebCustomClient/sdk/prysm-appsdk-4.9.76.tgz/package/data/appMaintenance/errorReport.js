"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorReport = void 0;
class ErrorReport {
    constructor() { }
}
exports.ErrorReport = ErrorReport;
