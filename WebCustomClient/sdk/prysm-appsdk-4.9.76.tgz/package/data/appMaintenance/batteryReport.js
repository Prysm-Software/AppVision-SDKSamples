"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatteryReport = void 0;
class BatteryReport {
    constructor() {
    }
}
exports.BatteryReport = BatteryReport;
