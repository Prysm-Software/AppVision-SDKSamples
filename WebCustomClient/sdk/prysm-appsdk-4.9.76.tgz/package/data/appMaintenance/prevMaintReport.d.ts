export declare class PrevMaintReport {
    Id: number;
    InstallationId: number;
    PartDateMarking: boolean;
    TakeOldPart: boolean;
    ResetFault: boolean;
    ControlJournal: boolean;
    DateCreation: string;
    SeverityId: number;
    DateResponse: string;
    User: string;
    ContractorId: number;
    ContractorExecutorId: number;
    UserComplete: string;
    Duration: string;
    DateComplete: string;
    Finished: boolean;
    DateNotification: string;
    NbReminder: number;
    Document1: string;
    Document2: string;
    Document3: string;
    Extension1: string;
    Extension2: string;
    constructor();
}
