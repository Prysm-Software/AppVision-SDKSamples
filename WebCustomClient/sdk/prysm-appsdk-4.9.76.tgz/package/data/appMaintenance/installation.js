"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Installation = void 0;
const contractor_1 = require("./contractor");
class Installation {
    constructor(p) {
        Object.assign(this, p);
        if (p.Contractor) {
            this.Contractor = new contractor_1.Contractor(p.Contractor);
        }
    }
}
exports.Installation = Installation;
