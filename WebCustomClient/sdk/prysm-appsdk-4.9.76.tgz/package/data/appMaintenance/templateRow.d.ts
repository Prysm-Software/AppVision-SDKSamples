export type TemplateRow = {
    RowId: number;
    MaintenanceTemplateId: number;
    pRowIndex: number;
    Description: string;
    AdditionalText: string;
    Notes: string;
    Type: number;
    SaveToNextReport: boolean;
    CopyToError: boolean;
    Mandatory: boolean;
    Extension1: string;
    Extension2: string;
};
