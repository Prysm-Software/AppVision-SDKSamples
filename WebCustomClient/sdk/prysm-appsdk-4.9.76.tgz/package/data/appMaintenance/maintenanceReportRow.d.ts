export type MaintenanceReportRow = {
    Id?: number;
    MaintenanceReportId: number;
    RowIndex: number;
    Description: string;
    AdditionalText: string;
    Notes: string;
    Type: number;
    SaveToNextReport: boolean;
    CopyToError: boolean;
    Mandatory: boolean;
    RowValue: string;
    Extension1: string;
    Extension2: string;
};
