"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Severity = void 0;
class Severity {
    constructor(p = null) {
        Object.assign(this, p);
    }
}
exports.Severity = Severity;
