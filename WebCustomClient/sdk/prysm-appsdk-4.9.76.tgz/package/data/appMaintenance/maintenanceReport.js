"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaintenanceReport = void 0;
class MaintenanceReport {
    constructor() {
    }
}
exports.MaintenanceReport = MaintenanceReport;
