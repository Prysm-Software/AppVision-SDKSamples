import { SecurityType } from "./securityType";
import { TemplateRow } from "./templateRow";
export type MaintenanceTemplate = {
    Id: number;
    Description: string;
    SecurityTypeId: number | null;
    SecurityType: SecurityType | null;
    TemplateRows: TemplateRow[] | null;
    UserModification: string;
    DateModification: Date;
    Extension1: string;
    Extension2: string;
};
