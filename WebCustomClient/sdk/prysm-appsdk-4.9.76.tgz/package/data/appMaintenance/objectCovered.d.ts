import { Installation } from "./installation";
export type ObjectCovered = {
    Id: number;
    InstallationId: number;
    Installation: Installation;
};
