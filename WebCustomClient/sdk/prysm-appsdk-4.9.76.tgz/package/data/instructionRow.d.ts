export declare class InstructionRow {
    Id: number;
    Name: string;
    Guid: string;
    Value: string;
    Type: number;
    NeedValidation: number;
    Parameters: string;
    Extension: string;
    CustomExtension: string;
    Url: string;
    constructor(obj: Partial<InstructionRow>);
}
