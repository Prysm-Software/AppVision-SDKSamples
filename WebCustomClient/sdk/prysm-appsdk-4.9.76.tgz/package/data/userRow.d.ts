import { ProfileRow } from "./profileRow";
import { UserState } from "./userState";
export declare class UserRow {
    constructor(user: Partial<UserRow>);
    Guid: string;
    Name: string;
    FirstName: string;
    LastName: string;
    DbOptions: string;
    DbRoles: string;
    Language: string;
    ProfileId: number;
    Parameters: string;
    CreateDate: string;
    ValidityStart: string;
    ValidityEnd: string;
    PasswordDate: string;
    Id: number;
    Picture: string;
    State: UserState;
    Email: string;
    Culture: string;
    Extension: string;
    CustomExtension: string;
    IsLocked: boolean;
    FilterTimetableId?: number;
    FilterClients: string;
    Phone: string;
    Security: string;
    Url: string;
    Notes: string;
    options: any;
    profile: ProfileRow;
    get rights(): string[];
    get fullName(): string;
    set passwordDate(d: Date);
    get passwordDate(): Date;
    get createDate(): Date;
    get validityStart(): Date;
    set validityStart(d: Date);
    get validityEnd(): Date;
    set validityEnd(d: Date);
    getParameter(paramName: string): string;
    checkRight(right: string, commandException?: string): boolean;
    /**
     * Get Extension field as UserExtension object
     * @returns UserExtension
     */
    getExtension(): UserExtension;
    /**
     * Save the given profile extension into Extension field
     * @param ext UserExtension
     */
    setExtension(ext: UserExtension): void;
}
export declare class UserExtension {
    ServerName: string;
    UserId: number;
    UserName: string;
    UserType: number;
    constructor(row: Partial<UserExtension>);
}
