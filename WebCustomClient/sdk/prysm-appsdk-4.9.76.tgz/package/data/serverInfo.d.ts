import { ServerStatus } from "./serverState";
export declare class ServerInfo {
    Hostname: string;
    IP: string;
    Port: number;
    PortTLS: number;
    ServerState: ServerStatus;
    Authentification: string;
    Name: string;
    Version: string;
    Description: string;
    Company: string;
    SiteName: string;
    ServerName: string;
    constructor(obj: Partial<ServerInfo>);
}
