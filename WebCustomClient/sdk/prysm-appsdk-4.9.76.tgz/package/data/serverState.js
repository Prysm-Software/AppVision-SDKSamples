"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServerState = exports.ServerStatus = void 0;
var ServerStatus;
(function (ServerStatus) {
    ServerStatus[ServerStatus["None"] = 0] = "None";
    ServerStatus[ServerStatus["Initializing"] = 1] = "Initializing";
    ServerStatus[ServerStatus["Activated"] = 2] = "Activated";
    ServerStatus[ServerStatus["Deactivated"] = 3] = "Deactivated";
    ServerStatus[ServerStatus["Closed"] = 4] = "Closed";
    ServerStatus[ServerStatus["RedundantChecking"] = 5] = "RedundantChecking";
    ServerStatus[ServerStatus["RedundantSynchronizing"] = 6] = "RedundantSynchronizing";
    ServerStatus[ServerStatus["RedundantReconnecting"] = 7] = "RedundantReconnecting";
    ServerStatus[ServerStatus["Error"] = 8] = "Error";
})(ServerStatus = exports.ServerStatus || (exports.ServerStatus = {}));
class ServerState {
    constructor(obj) {
        Object.assign(this, obj);
    }
    get cpuPercent() {
        return +(this.CpuCounter * 100).toFixed(1);
    }
}
exports.ServerState = ServerState;
