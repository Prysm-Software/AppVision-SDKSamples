export declare class GroupState {
    Id: number;
    Name: string;
    AlarmAcknowledgeWaitingCount: number;
    AlarmClosedCount: number;
    AlarmCount: number;
    AlarmProcessingCount: number;
    AlarmProcessWaitingCount: number;
    AndValue: number;
    LockedCount: number;
    MaskedCount: number;
    MaxSeverity: number;
    OrValue: number;
    WaitEndCount: number;
    WaitReportCount: number;
    constructor(state: Partial<GroupState>);
    get isAlarm(): boolean;
    get isAlarmAcknowledgeWaiting(): boolean;
    get isAlarmProcessing(): boolean;
    get isAlarmProcessWaiting(): boolean;
    get isAlarmClosed(): boolean;
}
