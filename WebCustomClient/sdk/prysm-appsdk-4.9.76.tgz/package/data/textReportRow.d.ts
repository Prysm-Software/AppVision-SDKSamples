export declare class TextReportRow {
    Id: number;
    Name: string;
    Guid: string;
    Value: string;
    Type: number;
    Extension: string;
    CustomExtension: string;
    Url: string;
    constructor(obj: Partial<TextReportRow>);
}
