"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserMessageCategoryProperty = exports.UserMessageCategory = exports.UserMessageCategoryType = void 0;
var UserMessageCategoryType;
(function (UserMessageCategoryType) {
    UserMessageCategoryType["Text"] = "Text";
    UserMessageCategoryType["TextMultiline"] = "TextMultiline";
    UserMessageCategoryType["ComboBox"] = "ComboBox";
    UserMessageCategoryType["Numeric"] = "Numeric";
    UserMessageCategoryType["CheckBox"] = "CheckBox";
    UserMessageCategoryType["Date"] = "Date";
    UserMessageCategoryType["DateTime"] = "DateTime";
})(UserMessageCategoryType = exports.UserMessageCategoryType || (exports.UserMessageCategoryType = {}));
class UserMessageCategory {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.UserMessageCategory = UserMessageCategory;
class UserMessageCategoryProperty {
    constructor(obj) {
        Object.assign(this, obj);
    }
}
exports.UserMessageCategoryProperty = UserMessageCategoryProperty;
