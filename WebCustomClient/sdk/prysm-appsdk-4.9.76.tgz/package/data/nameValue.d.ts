export interface NameValue {
    Name: string;
    Value: string;
}
