import { Command } from "./command";
export declare class CloseCommand implements Command {
}
