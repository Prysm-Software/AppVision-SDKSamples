"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CloseCommand = void 0;
class CloseCommand {
}
exports.CloseCommand = CloseCommand;
