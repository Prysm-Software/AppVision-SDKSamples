import { TreeRow } from "./treeRow";
import { GroupState } from "./groupState";
export declare class GroupRow extends TreeRow {
    Icon: string;
    Parameters: string;
    Extension: string;
    Url: string;
    CustomExtension: string;
    CustomField1: string;
    CustomField2: string;
    CustomField3: string;
    CustomField4: string;
    CustomField5: string;
    Synoptic: string;
    Sound: string;
    ColorInfo: string;
    FullSynoptic: string;
    FullParameters: string;
    FullSound: string;
    State: GroupState;
    constructor(row: Partial<GroupRow>);
    /**
     * Get Extension field as GroupExtension object
     * @returns GroupExtension
     */
    getExtension(): GroupExtension;
    /**
     * Save the given group extension into Extension field
     * @param ext GroupExtension
     */
    setExtension(ext: GroupExtension): void;
}
export declare class GroupExtension {
    ServerName: string;
    UserId: number;
    UserName: string;
    NotifyAndOrValue: boolean;
    constructor(row: Partial<GroupExtension>);
}
