export declare enum ServerStatus {
    None = 0,
    Initializing = 1,
    Activated = 2,
    Deactivated = 3,
    Closed = 4,
    RedundantChecking = 5,
    RedundantSynchronizing = 6,
    RedundantReconnecting = 7,
    Error = 8
}
export declare class ServerState {
    CpuCounter: number;
    ServerName: string;
    RamAvailable: number;
    RamInstalled: number;
    SiteId: number;
    SiteInfo: string;
    State: ServerStatus;
    SystemStateError: string;
    Version: string;
    DebugLevel: number;
    RedundantId: number;
    IsMirror: boolean;
    constructor(obj: Partial<ServerState>);
    get cpuPercent(): number;
}
