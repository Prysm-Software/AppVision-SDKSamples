"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValueRow = void 0;
const dateHelper_1 = require("../common/dateHelper");
class ValueRow {
    get date() {
        return dateHelper_1.DateHelper.toJSDate(this.Date);
    }
    constructor(value) {
        Object.assign(this, value);
    }
}
exports.ValueRow = ValueRow;
