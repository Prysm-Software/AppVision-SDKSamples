"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RTService = void 0;
class RTService {
    /**
     * Ctr
     * @param fileLoader Callback to load rt files. Default is fetch with Utf16 textdecoder
     */
    constructor(fileLoader = null) {
        this.files = new Map(); // Fichiers chargés
        this.labels = new Map(); // libellés dans la langue choisie
        this.fileLoader = fileLoader || defaultUtf16FileParser;
    }
    /**
     * Get the current lang
     * @returns
     */
    getLang() {
        return this.currentLang;
    }
    /**
     * Get RT label value with the current language
     * @param key
     * @returns
     */
    get(key) {
        return this.labels.get(key) || key;
    }
    /**
     * Download file and load it
     * @param file Filename to load (ex: applab.txt)
     * @param language Two char language key (ex: fr, en ...)
     */
    loadFile(file, language = "en") {
        return __awaiter(this, void 0, void 0, function* () {
            if (language.length > 2) {
                language = language.substring(0, 2);
            }
            yield this.downloadFile(file);
            this.setLang(language);
        });
    }
    /**
     * Set lang
     * @param lang lang 2 char locale
     */
    setLang(lang) {
        this.currentLang = null;
        let nb = 0;
        this.files.forEach((lines, key) => {
            let langidx = -1;
            const fileLang = new Map();
            let usedLang = null;
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i].split('\t');
                if (!line[0].match(/^\w/)) // ligne de commentaires
                    continue;
                // 1ère ligne = id lang
                if (langidx < 0) {
                    const langDesc = lines[++i].split('\t');
                    line.forEach((langId, j) => fileLang.set(langId, langDesc[j]));
                    langidx = line.indexOf(lang.toLowerCase());
                    if (langidx < 0) // langue demandée n'existe pas
                        langidx = 1;
                    usedLang = line[langidx];
                }
                // ajoute les libéllés
                this.labels.set(line[0].toLowerCase(), line[langidx] || line[1]); // en anglais si pas de traduction
                nb++;
            }
            console.log(`[RTService] ${key} loaded, Language: ${usedLang}, ${nb} labels`);
        });
    }
    downloadFile(fileUri) {
        return __awaiter(this, void 0, void 0, function* () {
            let lines;
            try {
                const file = yield this.fileLoader(fileUri);
                lines = file.split(/\r\n|\n/);
                this.files.set(fileUri, lines);
            }
            catch (e) {
                console.error("[RTService] - Cannot download languages file : '" + fileUri + "'.", e);
            }
        });
    }
}
exports.RTService = RTService;
function defaultUtf16FileParser(fileUri) {
    return __awaiter(this, void 0, void 0, function* () {
        const resp = yield fetch(fileUri);
        const data = yield resp.arrayBuffer();
        return new TextDecoder('utf-16').decode(data);
    });
}
