export declare class HttpService {
    private headers;
    private _host;
    constructor(host: string, headers?: any);
    get host(): string;
    addGlobalHeaders(headerKey: string, headerValue: string): void;
    getHeaders(): {
        Accept: string;
        'Content-Type': string;
    };
    get(url: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<Response>;
    getAsJson(url: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<any>;
    getAsText(url: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<string>;
    post(url: string, body: any, method?: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<Response>;
    postAsJson(url: string, body: any, method?: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<any>;
    postAsText(url: string, body: any, method?: string, headers?: HeadersInit, throwIfError?: boolean, timeoutMs?: number): Promise<string>;
}
