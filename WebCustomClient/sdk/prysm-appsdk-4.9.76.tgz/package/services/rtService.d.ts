type FileLoaderHandler = (fileUri: string) => Promise<string>;
export declare class RTService {
    private currentLang;
    private fileLoader;
    private files;
    private labels;
    /**
     * Ctr
     * @param fileLoader Callback to load rt files. Default is fetch with Utf16 textdecoder
     */
    constructor(fileLoader?: FileLoaderHandler);
    /**
     * Get the current lang
     * @returns
     */
    getLang(): string;
    /**
     * Get RT label value with the current language
     * @param key
     * @returns
     */
    get(key: string): string;
    /**
     * Download file and load it
     * @param file Filename to load (ex: applab.txt)
     * @param language Two char language key (ex: fr, en ...)
     */
    loadFile(file: string, language?: string): Promise<void>;
    /**
     * Set lang
     * @param lang lang 2 char locale
     */
    setLang(lang: string): void;
    private downloadFile;
}
export {};
