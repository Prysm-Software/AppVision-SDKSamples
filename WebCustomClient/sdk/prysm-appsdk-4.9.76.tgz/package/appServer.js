"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppServer = void 0;
const variableManager_1 = require("./managers/variableManager");
const groupManager_1 = require("./managers/groupManager");
const optionManager_1 = require("./managers/optionManager");
const userManager_1 = require("./managers/userManager");
const fileManager_1 = require("./managers/fileManager");
const eventManager_1 = require("./managers/eventManager");
const alarmManager_1 = require("./managers/alarmManager");
const operandManager_1 = require("./managers/operandManager");
const rtManager_1 = require("./managers/rtManager");
const protocolManager_1 = require("./managers/protocolManager");
const rxjs_1 = require("rxjs");
const scenarioManager_1 = require("./managers/scenarioManager");
const areaManager_1 = require("./managers/areaManager");
const eventRow_1 = require("./data/eventRow");
const alarmInfo_1 = require("./data/alarmInfo");
const variableState_1 = require("./data/variableState");
const variableRow_1 = require("./data/variableRow");
const areaRow_1 = require("./data/areaRow");
const areaState_1 = require("./data/areaState");
const groupRow_1 = require("./data/groupRow");
const groupState_1 = require("./data/groupState");
const protocolState_1 = require("./data/protocolState");
const scenarioState_1 = require("./data/scenarioState");
const fileInfoRow_1 = require("./data/fileInfoRow");
const commandManager_1 = require("./managers/commandManager");
const videoManager_1 = require("./managers/videoManager");
const httpService_1 = require("./services/httpService");
const environmentManager_1 = require("./managers/environmentManager");
const base64Helper_1 = require("./common/base64Helper");
const categoryManager_1 = require("./managers/categoryManager");
const peopleManager_1 = require("./managers/peopleManager");
const departmentManager_1 = require("./managers/departmentManager");
const accessProfileManager_1 = require("./managers/accessProfileManager");
const badgeManager_1 = require("./managers/badgeManager");
const rightManager_1 = require("./managers/rightManager");
const badgeTypeManager_1 = require("./managers/badgeTypeManager");
const zoneManager_1 = require("./managers/zoneManager");
const optionRow_1 = require("./data/optionRow");
const personZoneManager_1 = require("./managers/personZoneManager");
const serverState_1 = require("./data/serverState");
const holidayManager_1 = require("./managers/holidayManager");
const userMessageManager_1 = require("./managers/userMessageManager");
const visitorManager_1 = require("./managers/visitorManager");
const licenseManager_1 = require("./managers/licenseManager");
const chatManager_1 = require("./managers/chatManager");
const chat_1 = require("./data/chat");
const userState_1 = require("./data/userState");
const userRow_1 = require("./data/userRow");
const rowCustomColorManager_1 = require("./managers/rowCustomColorManager");
const overlayManager_1 = require("./managers/overlayManager");
const overlayItem_1 = require("./data/overlayItem");
const mailingManager_1 = require("./managers/mailingManager");
const workflowManager_1 = require("./managers/workflowManager");
const userProfileManager_1 = require("./managers/userProfileManager");
const profileRow_1 = require("./data/profileRow");
const controllerManager_1 = require("./managers/controllerManager");
const instructionManager_1 = require("./managers/instructionManager");
const textReportManager_1 = require("./managers/textReportManager");
const helper_1 = require("./common/helper");
class UnknownSessionError extends Error {
}
const getNotifCount = 300;
/**
 * Object to connect to an appvision server
 */
class AppServer {
    constructor() {
        this.keepAliveId = -1;
        this.handleKeepAlive = false;
        this.error = new rxjs_1.Subject();
        this.connectionLost = new rxjs_1.Subject();
        this.newState = new rxjs_1.Subject();
        this.keepAliveSucceed = new rxjs_1.Subject();
    }
    /**
     * Current state of the server
     */
    get state() { return this.lastState; }
    ;
    /**
     * Tell if the appServer object is connected or not
     */
    get isConnected() { return this.connected; }
    ;
    /**
     * Last keepalive info received
     */
    get keepAliveInfo() { return this.lastKeepAliveInfo; }
    ;
    /**
     * Update the number of retry when keep alive fails before being disconnected
     * @param val Number of retry
     */
    setKeepAliveRetryNb(val) { this.keepAliveFailRetryNb = val; }
    /**
     * Update the tempo between each keep alive fails before being disconnected
     * @param val Tempo in ms
     */
    setKeepAliveRetryTempo(val) { this.keepAliveFailRetryTempo = val; }
    /**
     * Get information about the server. This request does not require authentification.
     * @param host Server url.
     * @returns A ServerInfo object.
     */
    hello(host) {
        return __awaiter(this, void 0, void 0, function* () {
            const resp = yield new httpService_1.HttpService(host).get('AppVisionService.svc/Hello');
            return yield resp.json();
        });
    }
    /**
     * Change pasword of an user
     * @param username Username
     * @param oldPassword Old password
     * @param newPassword New password
     */
    changeUserPassword(username, oldPassword, newPassword) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.http.post('AppVisionService.svc/ChangePassword', JSON.stringify([
                { Name: "username", Value: username },
                { Name: "oldpassword", Value: oldPassword },
                { Name: "newpassword", Value: newPassword },
            ]), "POST", null);
        });
    }
    /**
     * Login informations
     * @param options
     */
    login(options) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            // Clear old use
            this.dispose();
            let username = options.username.toUpperCase();
            this.http = new httpService_1.HttpService(options.host);
            this.keepAliveFailRetryNb = options.keepAliveFailRetryNb || 3;
            this.keepAliveFailRetryTempo = options.keepAliveFailRetryTempo || 5000;
            this.notifFilter = options.notifFilter || "All";
            const openExt = [
                { Name: "clientproductname", Value: options.productName },
                { Name: "clientproductdescription", Value: options.productDescription },
                { Name: "clientproductcompany", Value: options.productCompany },
                { Name: "clientproductversion", Value: options.applicationVersion },
                { Name: "clientproductprocess", Value: options.productProcess || navigator.userAgent },
                { Name: "clientexecutingmodule", Value: options.clientExecutingModule },
                { Name: "hostname", Value: options.clientHostname },
                { Name: "deviceId", Value: options.deviceId },
                { Name: "noCookie", Value: options.noCookie || false },
            ];
            if (options.datas)
                for (const key of Object.getOwnPropertyNames(options.datas))
                    openExt.push({ Name: key, Value: (_a = options.datas[key]) === null || _a === void 0 ? void 0 : _a.toString() });
            // if (clientContext) {
            //     openExt.push({ Name: "clientContext", Value: clientContext });
            // }
            let resp = yield this.http.post("AppVisionService.svc/OpenExt", JSON.stringify(openExt));
            const sessionId = yield resp.json();
            this.http.addGlobalHeaders("SessionID", sessionId);
            let headers = { 'Authorization': 'Basic ' + base64Helper_1.Base64Helper.encode(username + ':' + options.password) };
            // SSO "Authorization: Negotiate" handled by browser
            if (username === "@SINGLESIGNON") {
                headers = null;
            }
            resp = yield this.http.post(`AppVisionService.svc/Login`, JSON.stringify([{ Name: "username", Value: username }, { Name: "password", Value: options.password }]), "POST", headers);
            // register for all server events (filter = All)
            yield this.http.post('AppVisionService.svc/AddFilterNotifications', '"' + this.notifFilter + '"');
            yield this.http.get('AppVisionService.svc/StartNotifications?send=false');
            // Charge le server state au démarage
            resp = yield this.http.get("AppVisionService.svc/GetServerState");
            const json = yield resp.json();
            this.lastState = new serverState_1.ServerState(json);
            this.userManager = new userManager_1.UserManager(this.http, this.httpOData);
            yield this.userManager.loadInternal();
            // Odata http
            this.httpOData = new httpService_1.HttpService(options.host);
            let password = options.password;
            if (username === "@SINGLESIGNON") {
                username = this.userManager.currentUser.Name;
                password = "@SingleSignOn";
            }
            this.httpOData.addGlobalHeaders("Authorization", "Basic " + base64Helper_1.Base64Helper.encode(username + ':' + password));
            this.areaManager = new areaManager_1.AreaManager(this.http, this.httpOData);
            yield this.areaManager.loadInternal();
            this.groupManager = new groupManager_1.GroupManager(this.http, this.httpOData);
            yield this.groupManager.loadInternal();
            this.variableManager = new variableManager_1.VariableManager(this.http, this.httpOData);
            yield this.variableManager.loadInternal();
            this.userProfileManager = new userProfileManager_1.UserProfileManager(this.http, this.httpOData);
            yield this.userProfileManager.loadInternal();
            this.optionManager = new optionManager_1.OptionManager(this.http);
            yield this.optionManager.loadInternal(this.userManager);
            this.fileManager = new fileManager_1.FileManager(this.http);
            yield this.fileManager.loadInternal();
            this.alarmManager = new alarmManager_1.AlarmManager(this.http);
            yield this.alarmManager.loadInternal();
            this.protocolManager = new protocolManager_1.ProtocolManager(this.http, this.httpOData);
            yield this.protocolManager.loadInternal();
            this.scenarioManager = new scenarioManager_1.ScenarioManager(this.http);
            yield this.scenarioManager.loadInternal();
            this.licenseManager = new licenseManager_1.LicenseManager(this.http);
            yield this.licenseManager.loadInternal();
            this.overlayManager = new overlayManager_1.OverlayManager(this.http);
            yield this.overlayManager.loadInternal();
            this.eventManager = new eventManager_1.EventManager(this.http);
            this.environmentManager = new environmentManager_1.EnvironmentManager(this.fileManager);
            this.controllerManager = new controllerManager_1.ControllerManager(this.http, this.httpOData, this.fileManager);
            this.instructionManager = new instructionManager_1.InstructionManager(this.http, this.httpOData);
            this.textReportManager = new textReportManager_1.TextReportManager(this.http);
            this.operandManager = new operandManager_1.OperandManager(this.variableManager, this.areaManager, this.alarmManager, this.groupManager, this.userManager, this.protocolManager, this, this.optionManager);
            this.commandManager = new commandManager_1.CommandManager();
            this.videoManager = new videoManager_1.VideoManager(this.http, this.variableManager);
            this.holidayManager = new holidayManager_1.HolidayManager(this.http);
            this.userMessageManager = new userMessageManager_1.UserMessageManager(this.http, this.optionManager);
            this.rtManager = new rtManager_1.RTManager(this.http);
            this.chatManager = new chatManager_1.ChatManager(this.http, this.fileManager);
            this.customColorManager = new rowCustomColorManager_1.RowCustomColorManager(this.optionManager, this.areaManager, this.alarmManager);
            this.mailingManager = new mailingManager_1.MailingManager(this.httpOData);
            this.workflowManager = new workflowManager_1.WorkFlowManager(this.http, this.fileManager);
            // AppControl services
            this.visitorManager = new visitorManager_1.VisitorManager(this.http, this.httpOData);
            this.categoryManager = new categoryManager_1.CategoryManager(this.httpOData);
            this.departmentManager = new departmentManager_1.DepartmentManager(this.httpOData);
            this.rightManager = new rightManager_1.RightManager(this.httpOData);
            this.badgesManager = new badgeManager_1.BadgeManager(this.httpOData);
            this.accessProfileManager = new accessProfileManager_1.AccessProfileManager(this.httpOData, this.rightManager);
            this.badgeTypeManager = new badgeTypeManager_1.BadgeTypeManager(this.httpOData, this.rightManager);
            this.zoneManager = new zoneManager_1.ZoneManager(this.httpOData);
            this.personZoneManager = new personZoneManager_1.PersonZoneManager(this.httpOData);
            this.peopleManager = new peopleManager_1.PeopleManager(this.httpOData);
            this.connected = true;
        });
    }
    /**
     * Logout
     */
    logout() {
        return __awaiter(this, void 0, void 0, function* () {
            this.connected = false;
            const copyHttp = this.http;
            this.dispose();
            try {
                yield copyHttp.get("AppVisionService.svc/Close");
            }
            catch (_a) {
            }
        });
    }
    /**
     * Start loop to send keepalive
     * @param tempo Tempo in ms (Default: 2000)
     */
    startKeepAlive(tempo = 2000) {
        this.keepAliveTempo = tempo;
        this.handleKeepAlive = true;
        this.keepAliveId = setTimeout(() => this.keepAliveLoop(), this.keepAliveTempo);
    }
    /**
     * Send keepalive to the server.
     * Warning: Use this method yourself only if you have set the handleKeepAliveManually parameter to true in the login method.
     * @returns Promise
     */
    sendKeepAlive() {
        return __awaiter(this, void 0, void 0, function* () {
            let tryNb = 0;
            do {
                try {
                    const resp = yield this.http.get('AppVisionService.svc/KeepAlive');
                    let notifCount = yield resp.json();
                    if (!this.connected || notifCount === 0)
                        return [];
                    if (notifCount < 0)
                        throw new UnknownSessionError("Unknown session ID.");
                    // On va chercher les events tant qu'il en reste
                    const jsonPackets = [];
                    while (notifCount > 0) {
                        const notifsResp = yield this.http.get('AppVisionService.svc/GetNotifications?count=' + getNotifCount);
                        const json = yield notifsResp.json();
                        if (!this.connected)
                            return [];
                        notifCount -= getNotifCount;
                        jsonPackets.push(json);
                    }
                    try {
                        const events = [];
                        for (const packet of jsonPackets) {
                            for (const n of packet) {
                                if (!Array.isArray(n.Data)) {
                                    events.push(n.Data);
                                }
                                else {
                                    for (const d of n.Data) {
                                        events.push(d);
                                    }
                                }
                            }
                        }
                        let eventsHandled = [];
                        if (events.length > 0) {
                            eventsHandled = this.handleNewEvents(events);
                        }
                        this.lastKeepAliveInfo = { count: eventsHandled.length, date: new Date() };
                        this.keepAliveSucceed.next(this.lastKeepAliveInfo);
                        return eventsHandled;
                    }
                    catch (error) {
                        console.error("[AppServer] - Failed parse notifications.", error);
                        this.error.next("Error parse notif resp : " + error.toString());
                    }
                }
                catch (err) {
                    if (!this.connected)
                        return [];
                    // Si ce n'est pas une erreur de session id on retente
                    if (!(err instanceof UnknownSessionError)) {
                        tryNb++;
                        console.warn("[AppServer] - Keepalive failed, retry " + tryNb);
                        if (tryNb < this.keepAliveFailRetryNb) {
                            this.error.next("Keepalive failed retry " + tryNb + ". Retry in " + this.keepAliveFailRetryTempo + "ms. " + err);
                            yield helper_1.Helper.delay(this.keepAliveFailRetryTempo);
                            continue;
                        }
                    }
                    const errorMessage = "Connection lost with appServer, keepalive failed after " + tryNb + " tries. ErrorDetails: " + err;
                    console.error("[AppServer] - ", errorMessage);
                    this.connected = false;
                    this.connectionLost.next(errorMessage);
                    throw new Error(errorMessage);
                }
                return [];
            } while (true);
        });
    }
    keepAliveLoop() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.sendKeepAlive();
            }
            catch (err) {
                if (!this.connected)
                    return;
            }
            if (this.handleKeepAlive)
                this.keepAliveId = setTimeout(() => this.keepAliveLoop(), this.keepAliveTempo);
        });
    }
    handleNewEvents(events) {
        const eventsRows = [];
        const alarmInfos = [];
        const variableStates = [];
        const variableRows = [];
        const areaRows = [];
        const areaStates = [];
        const groupRows = [];
        const groupStates = [];
        const protocolStates = [];
        const scenarioStates = [];
        const fileInfos = [];
        const options = [];
        const chatMessages = [];
        const talks = [];
        const userRows = [];
        const profileRows = [];
        const overlays = [];
        let userState = null;
        let state = null;
        events.forEach(event => {
            try {
                if (event.__type !== undefined) {
                    switch (event.__type) {
                        case 'ServerState:#Prysm.AppVision.Data':
                            state = new serverState_1.ServerState(event);
                            break;
                        case 'AlarmInfo:#Prysm.AppVision.Data':
                            alarmInfos.push(new alarmInfo_1.AlarmInfo(event));
                            break;
                        case 'EventRow:#Prysm.AppVision.Data':
                            eventsRows.push(new eventRow_1.EventRow(event));
                            break;
                        case 'VariableState:#Prysm.AppVision.Data':
                            variableStates.push(new variableState_1.VariableState(event));
                            break;
                        case 'VariableRow:#Prysm.AppVision.Data':
                            variableRows.push(new variableRow_1.VariableRow(event));
                            break;
                        case 'AreaRow:#Prysm.AppVision.Data':
                            areaRows.push(new areaRow_1.AreaRow(event));
                            break;
                        case 'AreaState:#Prysm.AppVision.Data':
                            areaStates.push(new areaState_1.AreaState(event));
                            break;
                        case 'GroupRow:#Prysm.AppVision.Data':
                            groupRows.push(new groupRow_1.GroupRow(event));
                            break;
                        case 'GroupState:#Prysm.AppVision.Data':
                            groupStates.push(new groupState_1.GroupState(event));
                            break;
                        case 'ProtocolState:#Prysm.AppVision.Data':
                            protocolStates.push(new protocolState_1.ProtocolState(event));
                            break;
                        case 'ScenarioState:#Prysm.AppVision.Data':
                            scenarioStates.push(new scenarioState_1.ScenarioState(event));
                            break;
                        case 'FileInfoRow:#Prysm.AppVision.Data':
                            fileInfos.push(new fileInfoRow_1.FileInfoRow(event));
                            break;
                        case 'OptionRow:#Prysm.AppVision.Data':
                            options.push(new optionRow_1.OptionRow(event));
                            break;
                        case 'ChatMessageRow:#Prysm.AppVision.Data':
                            chatMessages.push(new chat_1.ChatMessage(event));
                            break;
                        case 'Talk:#Prysm.AppVision.Data':
                            talks.push(new chat_1.Talk(event));
                            break;
                        case 'UserState:#Prysm.AppVision.Data':
                            userState = new userState_1.UserState(event);
                            break;
                        case 'UserRow:#Prysm.AppVision.Data':
                            userRows.push(new userRow_1.UserRow(event));
                            break;
                        case 'OverlayItem:#Prysm.AppVision.Data':
                            overlays.push(new overlayItem_1.OverlayItem(event));
                            break;
                        case 'ProfileRow:#Prysm.AppVision.Data':
                            profileRows.push(new profileRow_1.ProfileRow(event));
                            break;
                    }
                }
                else if (typeof event === "string" && this.commandManager.isCommand(event)) {
                    console.log("[AppServer] - Command receive : " + event);
                    this.commandManager.updateCommand(event);
                }
            }
            catch (err) {
                console.error("[AppServer] - Error reading event : " + err.toString());
                this.error.next("Error reading event : " + err.toString());
            }
        });
        if (variableRows.length > 0) {
            this.variableManager.updateRowsInternal(variableRows);
        }
        if (variableStates.length > 0) {
            this.variableManager.updateStatesInternal(variableStates);
            variableStates.forEach(vs => eventsRows.push(eventRow_1.EventRow.parseFromVarState(vs)));
        }
        if (eventsRows.length > 0) {
            this.eventManager.updateEventsInternal(eventsRows);
        }
        if (alarmInfos.length > 0) {
            this.alarmManager.updateAlarmsInternal(alarmInfos);
        }
        if (areaRows.length > 0) {
            this.areaManager.updateRowsInternal(areaRows);
        }
        if (areaStates.length > 0) {
            this.areaManager.updateStatesInternal(areaStates);
        }
        if (groupRows.length > 0) {
            this.groupManager.updateRowsInternal(groupRows);
        }
        if (groupStates.length > 0) {
            this.groupManager.updateStatesInternal(groupStates);
        }
        if (protocolStates.length > 0) {
            this.protocolManager.updateStatesInternal(protocolStates);
        }
        if (scenarioStates.length > 0) {
            this.scenarioManager.updateStatesInternal(scenarioStates);
        }
        if (fileInfos.length > 0) {
            this.fileManager.updateRowsInternal(fileInfos);
        }
        if (options.length > 0) {
            this.optionManager.updateRowsInternal(options);
        }
        if (chatMessages.length > 0) {
            this.chatManager.updateMessagesInternal(chatMessages);
        }
        if (talks.length > 0) {
            this.chatManager.updateTalksInternal(talks);
        }
        if (userRows.length > 0) {
            this.userManager.updateRowsInternal(userRows);
        }
        if (overlays.length > 0) {
            this.overlayManager.updateInternal(overlays);
        }
        if (profileRows.length > 0) {
            this.userProfileManager.updateRowsInternal(profileRows);
        }
        if (state) {
            this.lastState = state;
            this.newState.next(state);
        }
        if (userState) {
            this.userManager.updateStateInternal(userState);
        }
        const resp = [
            ...eventsRows,
            ...alarmInfos,
            ...variableStates,
            ...variableRows,
            ...areaRows,
            ...areaStates,
            ...groupRows,
            ...groupStates,
            ...protocolStates,
            ...scenarioStates,
            ...fileInfos,
            ...options,
            ...chatMessages,
            ...talks,
            ...userRows,
            ...overlays,
            ...profileRows
        ];
        if (userState)
            resp.push(userState);
        if (state)
            resp.push(state);
        return resp;
    }
    dispose() {
        if (this.connected)
            this.connected = false;
        if (this.keepAliveId > -1)
            clearTimeout(this.keepAliveId);
        this.alarmManager = null;
        this.optionManager = null;
        this.userManager = null;
        this.variableManager = null;
        this.groupManager = null;
        this.areaManager = null;
        this.fileManager = null;
        this.eventManager = null;
        this.rtManager = null;
        this.operandManager = null;
        this.protocolManager = null;
        this.scenarioManager = null;
        this.commandManager = null;
        this.videoManager = null;
        this.environmentManager = null;
        this.peopleManager = null;
        this.categoryManager = null;
        this.departmentManager = null;
        this.accessProfileManager = null;
        this.badgesManager = null;
        this.rightManager = null;
        this.badgeTypeManager = null;
        this.chatManager = null;
        this.mailingManager = null;
        this.userProfileManager = null;
        this.licenseManager = null;
        this.textReportManager = null;
        this.instructionManager = null;
        this.http = null;
        this.httpOData = null;
        this.lastState = null;
        this.keepAliveId = -1;
        this.handleKeepAlive = false;
        this.lastKeepAliveInfo = null;
        this.error = new rxjs_1.Subject();
        this.connectionLost = new rxjs_1.Subject();
        this.newState = new rxjs_1.Subject();
        this.keepAliveSucceed = new rxjs_1.Subject();
    }
}
exports.AppServer = AppServer;
